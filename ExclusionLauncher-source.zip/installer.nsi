﻿; NSIS-установщик Exclusion Launcher — тот же движок, что у ULauncher.
; ставит сборку app-stage в <INSTDIR>\app, ярлыки, деинсталлятор, запуск.

Unicode true
Name "Exclusion Launcher"
!define APPNAME "Exclusion Launcher"
!define APPEXE  "ExclusionLauncher.exe"
!define COMPANY "Exclusion"
!define APPVER  "0.2.6"

!include "MUI2.nsh"

OutFile "..\dist\ExclusionInstaller.exe"
RequestExecutionLevel user
InstallDir "$LOCALAPPDATA\ExclusionLauncher"
SetCompressor /SOLID lzma

!define MUI_ICON "..\data\icon.ico"
!define MUI_UNICON "..\data\icon.ico"
!define MUI_FINISHPAGE_RUN "$INSTDIR\app\${APPEXE}"
!define MUI_FINISHPAGE_RUN_TEXT "Запустить Exclusion Launcher"

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "Russian"

VIProductVersion "0.2.6.0"
VIAddVersionKey /LANG=${LANG_RUSSIAN} "ProductName"     "${APPNAME}"
VIAddVersionKey /LANG=${LANG_RUSSIAN} "CompanyName"     "${COMPANY}"
VIAddVersionKey /LANG=${LANG_RUSSIAN} "FileDescription" "${APPNAME} Setup"
VIAddVersionKey /LANG=${LANG_RUSSIAN} "FileVersion"     "${APPVER}"
VIAddVersionKey /LANG=${LANG_RUSSIAN} "ProductVersion"  "${APPVER}"

Section "Install"
  SetOverwrite on
  ExecWait '"$SYSDIR\taskkill.exe" /F /IM ${APPEXE}'
  RMDir /r "$INSTDIR\app"

  SetOutPath "$INSTDIR\app"
  File /r "..\build\app-stage\*"

  FileOpen $0 "$INSTDIR\.version" w
  FileWrite $0 "${APPVER}"
  FileClose $0

  CreateShortCut "$SMPROGRAMS\${APPNAME}.lnk" "$INSTDIR\app\${APPEXE}" "" "$INSTDIR\app\icon.ico"
  CreateShortCut "$DESKTOP\${APPNAME}.lnk"    "$INSTDIR\app\${APPEXE}" "" "$INSTDIR\app\icon.ico"

  WriteUninstaller "$INSTDIR\uninstall.exe"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\ExclusionLauncher" "DisplayName"     "${APPNAME}"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\ExclusionLauncher" "UninstallString" '"$INSTDIR\uninstall.exe"'
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\ExclusionLauncher" "DisplayIcon"     "$INSTDIR\app\${APPEXE}"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\ExclusionLauncher" "DisplayVersion"  "${APPVER}"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\ExclusionLauncher" "Publisher"       "${COMPANY}"
SectionEnd

Section "Uninstall"
  Delete "$DESKTOP\${APPNAME}.lnk"
  Delete "$SMPROGRAMS\${APPNAME}.lnk"
  RMDir /r "$INSTDIR\app"
  RMDir /r "$INSTDIR\app-new"
  Delete "$INSTDIR\uninstall.exe"
  RMDir "$INSTDIR"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\ExclusionLauncher"
SectionEnd
