#include "core/ClientVerifier.hpp"
#include "core/ClientInstall.hpp"
#include "core/ConfigInstall.hpp"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QTemporaryDir>
#include <QtTest/QtTest>

namespace {

bool writeFile(const QString& path, const QByteArray& bytes)
{
    QDir().mkpath(QFileInfo(path).absolutePath());
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate))
        return false;
    file.write(bytes);
    return true;
}

}

class ClientVerifierTests : public QObject
{
    Q_OBJECT

private slots:
    void extraUserJarInModsDoesNotCorruptClient()
    {
        QTemporaryDir dir;
        QVERIFY(dir.isValid());

        QVERIFY(writeFile(QDir(dir.path()).filePath(QStringLiteral("mods/launcher-owned.jar")),
                          QByteArrayLiteral("package jar")));
        QVERIFY(ClientVerifier::writeManifest(dir.path()));

        QVERIFY(writeFile(QDir(dir.path()).filePath(QStringLiteral("mods/user-extra.jar")),
                          QByteArrayLiteral("user mod")));

        QCOMPARE(ClientVerifier::checkClient(dir.path()), QString());
    }

    void directJsonConfigInstallsIntoTargetFolder()
    {
        QTemporaryDir dir;
        QVERIFY(dir.isValid());

        const QString downloaded = QDir(dir.path()).filePath(QStringLiteral("wild__bro9i.json"));
        const QString target = QDir(dir.path()).filePath(QStringLiteral("WildClient"));
        QVERIFY(writeFile(downloaded, QByteArrayLiteral("{\"ok\":true}")));

        QString error;
        QVERIFY2(ConfigInstall::installDownloaded(downloaded,
                                                  QDir(dir.path()).filePath(QStringLiteral("staging")),
                                                  target,
                                                  QString(),
                                                  QStringLiteral("Bro9i"),
                                                  &error),
                 qPrintable(error));

        QFile installed(QDir(target).filePath(QStringLiteral("Bro9i.json")));
        QVERIFY(installed.open(QIODevice::ReadOnly));
        QCOMPARE(installed.readAll(), QByteArrayLiteral("{\"ok\":true}"));
    }

    void directWexConfigKeepsCustomExtension()
    {
        QTemporaryDir dir;
        QVERIFY(dir.isValid());

        const QString downloaded = QDir(dir.path()).filePath(QStringLiteral("preset.wex"));
        const QString target = QDir(dir.path()).filePath(QStringLiteral("WildClient"));
        QVERIFY(writeFile(downloaded, QByteArrayLiteral("wex-data")));

        QString error;
        QVERIFY2(ConfigInstall::installDownloaded(downloaded,
                                                  QDir(dir.path()).filePath(QStringLiteral("staging")),
                                                  target,
                                                  QString(),
                                                  QStringLiteral("My Wild Preset"),
                                                  &error),
                 qPrintable(error));

        QFile installed(QDir(target).filePath(QStringLiteral("My Wild Preset.wex")));
        QVERIFY(installed.open(QIODevice::ReadOnly));
        QCOMPARE(installed.readAll(), QByteArrayLiteral("wex-data"));
    }

    void installingExtractedClientReplacesReadonlyOldFiles()
    {
        QTemporaryDir dir;
        QVERIFY(dir.isValid());

        const QString finalDir = QDir(dir.path()).filePath(QStringLiteral("skycore"));
        const QString staging = QDir(dir.path()).filePath(QStringLiteral("staging-skycore"));
        const QString oldFile = QDir(finalDir).filePath(QStringLiteral("mods/old.jar"));
        const QString newFile = QDir(staging).filePath(QStringLiteral("mods/new.jar"));

        QVERIFY(writeFile(oldFile, QByteArrayLiteral("old")));
        QVERIFY(QFile::setPermissions(oldFile, QFileDevice::ReadOwner));
        QVERIFY(writeFile(newFile, QByteArrayLiteral("new")));

        const QString error = ClientInstall::installExtractedClient(finalDir, staging);
        QVERIFY2(error.isEmpty(), qPrintable(error));
        QVERIFY(!QFileInfo::exists(oldFile));

        QFile installed(QDir(finalDir).filePath(QStringLiteral("mods/new.jar")));
        QVERIFY(installed.open(QIODevice::ReadOnly));
        QCOMPARE(installed.readAll(), QByteArrayLiteral("new"));
    }
};

QTEST_MAIN(ClientVerifierTests)

#include "client_verifier_tests.moc"
