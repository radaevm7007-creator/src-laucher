# Client Verifier User Mods Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Stop false client corruption errors when users add mod jars or installed config contents.

**Architecture:** Keep manifest-owned jar validation intact, but remove the "extra jar in known directory" rejection branch. Add a small Qt test target around `ClientVerifier` to lock the behavior.

**Tech Stack:** C++20, Qt 6 Core/Concurrent/Test, CMake, PowerShell packaging.

**Spec:** `docs/superpowers/specs/2026-08-23-client-verifier-user-mods.md`

## Global Constraints

- Do not revert unrelated dirty worktree changes.
- Use TDD: add failing test first, run it, then implement the verifier change.
- Inspect the update archive before server upload.

---

### Task 1: Client Verifier Regression Test

**Files:**
- Modify: `CMakeLists.txt`
- Create: `tests/client_verifier_tests.cpp`

**Interfaces:**
- Consumes: `ClientVerifier::writeManifest(const QString&)`, `ClientVerifier::checkClient(const QString&)`
- Produces: CTest test executable `ClientVerifierTests`

- [ ] Add a test that writes a package manifest, then creates `mods/user-extra.jar`, and expects `checkClient()` to return an empty error string.
- [ ] Run only `ClientVerifierTests` and verify it fails with `лишний файл`.

### Task 2: Verifier Behavior

**Files:**
- Modify: `src/core/ClientVerifier.cpp`

**Interfaces:**
- Keeps: package jar presence/size/SHA validation.
- Changes: extra jar files not present in the manifest are ignored.

- [ ] Remove only the extra-jar rejection loop.
- [ ] Run `ClientVerifierTests` and verify it passes.
- [ ] Run Release build.

### Task 3: Package And Deploy

**Files:**
- Read/produce: Release build output and update archive.

**Interfaces:**
- Consumes: existing update/package files and deployment path.
- Produces: uploaded launcher update package and updated server manifest.

- [ ] Locate existing update/package files and current deployment path.
- [ ] Build/update package.
- [ ] List archive contents before upload.
- [ ] Upload to server and verify update download URL returns the uploaded package.
