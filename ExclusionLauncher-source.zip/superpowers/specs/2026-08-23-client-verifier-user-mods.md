# Client Verifier User Mods Spec

## Goal

Allow players to add their own `.jar` mods and downloaded config contents without the launcher marking the client as corrupted, while keeping protection for the launcher-owned package jars.

## Requirements

- Extra `.jar` files placed by the user under existing client directories must not fail client verification.
- Package `.jar` files recorded in `.exclusion-files.json` must still be checked for presence, size, and SHA-256.
- Downloaded config files must not cause a false "extra file" integrity failure.
- The launcher must still build in Release after the change.
- The update archive must be inspected before uploading so it only contains launcher update files.

## Non-Goals

- Do not remove integrity checking for launcher-owned jars.
- Do not change the full Telegram bot/config-admin feature set in this hotfix.
- Do not execute attached third-party client archives as part of this hotfix.
