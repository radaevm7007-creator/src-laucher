#include <QGuiApplication>
#include <QIcon>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickStyle>
#include <QDebug>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QDateTime>
#include <QEventLoop>
#include <QMutex>
#include <QTextStream>
#include <QTimer>
#include <QQmlNetworkAccessManagerFactory>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkDiskCache>
#include <QLocalServer>
#include <QLocalSocket>
#include <QCryptographicHash>
#include <QQuickWindow>

#include "core/AppConfig.hpp"
#include "core/AppPaths.hpp"
#include "core/SettingsManager.hpp"
#include "core/InstalledStore.hpp"
#include "core/ManifestManager.hpp"
#include "core/AssetCache.hpp"
#include "core/PhotoStore.hpp"
#include "core/ConfigManager.hpp"
#include "core/ClientVerifier.hpp"
#include <QQuickImageProvider>
#include "core/DiscordRPC.hpp"
#include "core/DownloadManager.hpp"
#include "core/GameLauncher.hpp"
#include "core/I18n.hpp"
#include "core/IntegrityChecker.hpp"
#include "core/NewsModel.hpp"
#include "core/RuntimeManager.hpp"
#include "core/ServerSync.hpp"
#include "core/AdSessionTracker.hpp"
#include "core/DesktopShortcut.hpp"
#include "core/AppUpdater.hpp"
#include "core/SegmentedDownloader.hpp"
#include "core/McAssets.hpp"
#include <QElapsedTimer>
#include <QFileInfo>

#ifdef Q_OS_WIN
#include <string>
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <shlobj.h>
#include <shobjidl.h>
#endif

namespace {
QMutex logMutex;

void messageHandler(QtMsgType type, const QMessageLogContext&, const QString& msg)
{
    QMutexLocker locker(&logMutex);
    QFile file(AppPaths::logsRoot() + QStringLiteral("/launcher.log"));
    if (!file.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text))
        return;

    const char* level = "INFO";
    if (type == QtWarningMsg) level = "WARN";
    else if (type == QtCriticalMsg || type == QtFatalMsg) level = "ERROR";
    else if (type == QtDebugMsg) level = "DEBUG";

    QTextStream out(&file);
    out << '[' << QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss") << "] ["
        << level << "] " << msg << '\n';
}

// ---------- Сторожевой маркер старта ---------------------------------------
// Если прошлый запуск не дошёл до первого отрисованного кадра (краш при
// инициализации, битый драйвер D3D/GL, повреждённый кэш QML — типичные
// причины «процесс в диспетчере есть, а окна нет» и 0xc000012d), следующий
// старт принудительно идёт в software-рендере: медленнее, зато окно
// гарантированно появляется. Маркер снимается после первого кадра.
QString watchdogFilePath()
{
    return AppPaths::root() + QStringLiteral("/startup-watchdog");
}

bool envFlagTrue(const char* name)
{
    const QByteArray v = qgetenv(name);
    return v == "1" || v.compare("true", Qt::CaseInsensitive) == 0;
}

void applyStartupWatchdog()
{
    const bool crashedLastTime = QFileInfo::exists(watchdogFilePath());
    if (crashedLastTime || envFlagTrue("EXCLUSION_FORCE_SOFTWARE")) {
        qWarning() << "[start] прошлый запуск не дошёл до первого кадра —"
                      " включаю software-рендер и отключаю кэш QML";
        qputenv("QT_QUICK_BACKEND", "software");
        qputenv("QML_DISABLE_DISK_CACHE", "1");
    }
    QFile f(watchdogFilePath());
    if (f.open(QIODevice::WriteOnly | QIODevice::Truncate))
        f.write(QString::number(QCoreApplication::applicationPid()).toUtf8());
}

void clearStartupWatchdog()
{
    QFile::remove(watchdogFilePath());
}

// ---------- Один экземпляр лаунчера ----------------------------------------
// Повторный запуск не плодит процессы (стопка «висящих» копий на слабых ПК
// выедает виртуальную память системы вплоть до STATUS_COMMITMENT_LIMIT /
// 0xc000012d у следующих попыток), а просит уже открытое окно подняться.
QString instanceKeyName()
{
    const QByteArray user = qEnvironmentVariable("USERNAME").toUtf8();
    return QStringLiteral("ExclusionLauncher.%1").arg(
        QString::fromLatin1(QCryptographicHash::hash(user, QCryptographicHash::Sha1)
                                .toHex().left(12)));
}






class GatedNam : public QNetworkAccessManager
{
public:
    explicit GatedNam(QObject* parent = nullptr) : QNetworkAccessManager(parent) {







        auto* cache = new QNetworkDiskCache(this);
        cache->setCacheDirectory(AppPaths::subdir(QStringLiteral("imgcache")));
        cache->setMaximumCacheSize(qint64(300) * 1024 * 1024);
        setCache(cache);
    }
protected:
    QNetworkReply* createRequest(Operation op, const QNetworkRequest& req,
                                 QIODevice* outgoingData) override
    {
        QNetworkRequest r(req);
        r.setRawHeader(QByteArrayLiteral("X-Exclusion-Key"),
                       QByteArrayLiteral("EXC_9fK2mQ7pX4nR8vL3wT6yB1sH5cD0jZ"));



        if (op == GetOperation)
            r.setAttribute(QNetworkRequest::CacheLoadControlAttribute,
                           QNetworkRequest::PreferCache);
        return QNetworkAccessManager::createRequest(op, r, outgoingData);
    }
};

class GatedNamFactory : public QQmlNetworkAccessManagerFactory
{
public:
    QNetworkAccessManager* create(QObject* parent) override { return new GatedNam(parent); }
};

#ifdef Q_OS_WIN





void ensureDesktopShortcut()
{




    {
        wchar_t* lad = nullptr;
        if (FAILED(SHGetKnownFolderPath(FOLDERID_LocalAppData, 0, nullptr, &lad)) || !lad)
            return;
        const QString installApp = QDir::cleanPath(
            QString::fromWCharArray(lad) + QStringLiteral("/ExclusionLauncher/app"));
        CoTaskMemFree(lad);
        const QString here = QDir::cleanPath(QCoreApplication::applicationDirPath());
        if (here.compare(installApp, Qt::CaseInsensitive) != 0)
            return;
    }

    const std::wstring exe = QDir::toNativeSeparators(
        QCoreApplication::applicationFilePath()).toStdWString();
    const std::wstring dir = QDir::toNativeSeparators(
        QCoreApplication::applicationDirPath()).toStdWString();

    wchar_t* desk = nullptr;
    if (FAILED(SHGetKnownFolderPath(FOLDERID_Desktop, 0, nullptr, &desk)) || !desk)
        return;
    const std::wstring lnk = std::wstring(desk) + L"\\Exclusion Launcher.lnk";
    CoTaskMemFree(desk);

    const bool coInit = SUCCEEDED(CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED));
    IShellLinkW* link = nullptr;
    if (SUCCEEDED(CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER,
                                   IID_IShellLinkW, reinterpret_cast<void**>(&link))) && link) {
        link->SetPath(exe.c_str());
        link->SetWorkingDirectory(dir.c_str());
        const std::wstring ico = dir + L"\\icon.ico";
        if (GetFileAttributesW(ico.c_str()) != INVALID_FILE_ATTRIBUTES)
            link->SetIconLocation(ico.c_str(), 0);
        else
            link->SetIconLocation(exe.c_str(), 0);
        link->SetDescription(L"Exclusion Launcher");






        IShellLinkDataList* dl = nullptr;
        if (SUCCEEDED(link->QueryInterface(IID_IShellLinkDataList,
                                           reinterpret_cast<void**>(&dl))) && dl) {
            DWORD flags = 0;
            dl->GetFlags(&flags);
            dl->SetFlags(flags | SLDF_FORCE_NO_LINKINFO);
            dl->Release();
        }

        IPersistFile* pf = nullptr;
        if (SUCCEEDED(link->QueryInterface(IID_IPersistFile, reinterpret_cast<void**>(&pf))) && pf) {
            pf->Save(lnk.c_str(), TRUE);
            pf->Release();
            SHChangeNotify(SHCNE_UPDATEITEM, SHCNF_PATHW, lnk.c_str(), nullptr);
        }
        link->Release();
    }
    if (coInit) CoUninitialize();
}
#else
void ensureDesktopShortcut() {}
#endif
}

int main(int argc, char* argv[])
{
    QQuickStyle::setStyle(QStringLiteral("Basic"));
    QGuiApplication app(argc, argv);
    app.setOrganizationName(QStringLiteral("Exclusion"));
    app.setApplicationName(QStringLiteral("ExclusionLauncher"));



    qInstallMessageHandler(messageHandler);




    {
        const QStringList args = app.arguments();
        const int idx = args.indexOf(QStringLiteral("--sync-servers"));
        if (idx >= 0 && idx + 1 < args.size()) {
            ServerSync sync;


            QEventLoop wait;
            QTimer::singleShot(4000, &wait, &QEventLoop::quit);
            QObject::connect(&sync, &ServerSync::promotedChanged, &wait, &QEventLoop::quit);
            wait.exec();

            QString err;
            const bool ok = sync.syncForClient(args.at(idx + 1), QString(), &err);
            if (!ok) qWarning() << "[servers] ошибка:" << err;
            return ok ? 0 : 1;
        }
    }



    {
        const QStringList args = app.arguments();
        const int idx = args.indexOf(QStringLiteral("--fetch"));
        if (idx >= 0 && idx + 2 < args.size()) {
            SegmentedDownloader dl;
            const int segs = (idx + 3 < args.size()) ? args.at(idx + 3).toInt() : 4;
            QElapsedTimer t; t.start();
            int rc = 2;
            QEventLoop loop;
            QObject::connect(&dl, &SegmentedDownloader::progress, &loop,
                [&](qint64 got, qint64 total) {
                    static qint64 last = 0;
                    if (got - last > 8 * 1024 * 1024 || got >= total) {
                        last = got;
                        fprintf(stderr, "  progress got=%lld total=%lld = %.1f%%\n",
                                (long long)got, (long long)total,
                                total > 0 ? 100.0 * got / total : -1.0);
                    }
                });
            QObject::connect(&dl, &SegmentedDownloader::finished, &loop,
                [&](bool ok, const QString& err) {
                    const double s = t.elapsed() / 1000.0;
                    const qint64 sz = QFileInfo(args.at(idx + 2)).size();
                    fprintf(stderr, "fetch: ok=%d err=%s | %.1f МБ за %.1fс = %.2f МБ/с\n",
                            ok, err.toUtf8().constData(), sz / 1e6, s, sz / 1e6 / s);
                    rc = ok ? 0 : 1;
                    loop.quit();
                });
            dl.start(args.at(idx + 1), args.at(idx + 2), segs);
            loop.exec();
            return rc;
        }
    }



    {
        const QStringList args = app.arguments();
        const int idx = args.indexOf(QStringLiteral("--mcassets"));
        if (idx >= 0 && idx + 2 < args.size()) {
            McAssets ma;
            QElapsedTimer t; t.start();
            int rc = 2;
            QEventLoop loop;
            QObject::connect(&ma, &McAssets::progress, &loop, [](int d, int tot, const QString&) {
                if (d % 512 == 0) fprintf(stderr, "  %d/%d\n", d, tot);
            });
            QObject::connect(&ma, &McAssets::finished, &loop, [&](bool ok, const QString& err) {
                fprintf(stderr, "mcassets: ok=%d err=%s за %.1fс\n", ok, err.toUtf8().constData(),
                        t.elapsed() / 1000.0);
                rc = ok ? 0 : 1; loop.quit();
            });
            ma.ensure(args.at(idx + 1), args.at(idx + 2));
            loop.exec();
            return rc;
        }
    }




    {
        const QStringList args = app.arguments();
        const int idx = args.indexOf(QStringLiteral("--launch"));
        if (idx >= 0 && idx + 1 < args.size()) {
            const QString wantId = args.at(idx + 1);

            SettingsManager settings;
            InstalledStore installed;
            ManifestManager manifest(&installed);
            RuntimeManager runtimes;
            GameLauncher launcher(&settings, &installed, &runtimes);
            ServerSync sync;
            launcher.setServerSync(&sync);



            ClientVerifier verifier;
            DownloadManager cliDownload(&settings, &installed);
            launcher.setVerifier(&verifier);

            auto* cliPending = new QVariantMap;
            QObject::connect(&launcher, &GameLauncher::reinstallRequired, &cliDownload,
                             [&cliDownload, cliPending](const QVariantMap& client) {
                qInfo() << "[launch] требуется переустановка:"
                        << client.value(QStringLiteral("id")).toString();
                *cliPending = client;
                cliDownload.installClient(client);
            });
            QObject::connect(&cliDownload, &DownloadManager::installFinished, &launcher,
                             [&launcher, cliPending](const QString& id) {
                if (cliPending->value(QStringLiteral("id")).toString() != id) return;
                const QVariantMap client = *cliPending;
                cliPending->clear();
                launcher.launch(client);
            });

            QEventLoop loop;
            int rc = 1;

            QObject::connect(&launcher, &GameLauncher::gameStarted, &loop, [&](const QString& id) {
                qInfo() << "[launch] игра запущена:" << id;
                rc = 0;


                QTimer::singleShot(60000, &loop, &QEventLoop::quit);
            });
            QObject::connect(&launcher, &GameLauncher::gameFinished, &loop,
                             [&](const QString& id, int code) {
                qInfo() << "[launch] игра завершилась:" << id << "код" << code;
                rc = code == 0 ? 0 : 2;
                loop.quit();
            });
            QObject::connect(&launcher, &GameLauncher::errorChanged, &loop, [&] {
                if (launcher.lastError().isEmpty()) return;
                qWarning() << "[launch] ошибка:" << launcher.lastError();
                rc = 1;
                loop.quit();
            });





            auto* launched = new bool(false);
            QObject::connect(&manifest, &ManifestManager::loadingChanged, &loop, [&, launched] {
                if (manifest.loading() || *launched) return;
                *launched = true;
                for (const QVariant& v : manifest.clients()) {
                    const QVariantMap c = v.toMap();
                    if (c.value(QStringLiteral("id")).toString() == wantId) {
                        qInfo() << "[launch] запускаю" << wantId;
                        launcher.launch(c);
                        return;
                    }
                }
                qWarning() << "[launch] клиента нет в каталоге:" << wantId;
                loop.quit();
            });


            QTimer::singleShot(30 * 60 * 1000, &loop, &QEventLoop::quit);
            loop.exec();
            return rc;
        }
    }


    // ---------- Один экземпляр: второй запуск поднимает открытое окно -------
    const QString instanceKey = instanceKeyName();
    {
        QLocalSocket probe;
        probe.connectToServer(instanceKey);
        if (probe.waitForConnected(400)) {
            probe.write("raise\n");
            probe.waitForBytesWritten(400);
            probe.disconnectFromServer();
            qInfo() << "[start] лаунчер уже запущен — поднимаю существующее окно";
            return 0;
        }
    }
    QLocalServer::removeServer(instanceKey);
    QLocalServer instanceServer;
    if (!instanceServer.listen(instanceKey))
        qWarning() << "[start] single-instance сервер недоступен:"
                   << instanceServer.errorString();

    // Сторожевой маркер: включаем software-фолбэк, если прошлый старт упал.
    applyStartupWatchdog();

    app.setWindowIcon(QIcon(QStringLiteral(":/icons/data/icon_rounded.png")));
    app.setApplicationVersion(QString::fromLatin1(AppConfig::LauncherVersion));

    qInfo() << AppConfig::LauncherName << AppConfig::LauncherVersion << "started";

    SettingsManager settings;
    InstalledStore installed;
    ManifestManager manifest(&installed);
    DownloadManager download(&settings, &installed);
    RuntimeManager runtimes;
    GameLauncher gameLauncher(&settings, &installed, &runtimes);
    NewsModel news;
    AssetCache assets;
    PhotoStore photos;
    ConfigManager configs(&settings);
    I18n i18n(&settings);
    DiscordRPC discord(&settings);


    ServerSync serverSync;
    gameLauncher.setServerSync(&serverSync);






    AppUpdater updater;
    if (updater.applyStagedOnStartup()) {
        clearStartupWatchdog();
        return 0;
    }



    ensureDesktopShortcut();


    updater.checkForUpdate();

    auto tryApplyLauncherUpdate = [&updater, &gameLauncher] {
        if (!updater.updateReady() || gameLauncher.running() || gameLauncher.preparing())
            return;

        QTimer::singleShot(1200, &updater, [&updater, &gameLauncher] {
            if (updater.updateReady() && !gameLauncher.running() && !gameLauncher.preparing())
                updater.applyAndRestart();
        });
    };
    QObject::connect(&updater, &AppUpdater::updateReadyChanged, &updater, tryApplyLauncherUpdate);
    QObject::connect(&gameLauncher, &GameLauncher::stateChanged, &updater, tryApplyLauncherUpdate);
    QObject::connect(&gameLauncher, &GameLauncher::progressChanged, &updater, tryApplyLauncherUpdate);



    QObject::connect(&gameLauncher, &GameLauncher::stateChanged, &discord, [&] {
        const QString id = gameLauncher.runningClientId();
        if (id.isEmpty()) { discord.setIdle(); return; }


        QString name = id;
        for (const QVariant& v : manifest.clients()) {
            const QVariantMap c = v.toMap();
            if (c.value(QStringLiteral("id")).toString() == id) {
                const QString n = c.value(QStringLiteral("name")).toString();
                if (!n.isEmpty()) name = n;
                break;
            }
        }
        discord.setPlaying(name);
    });



    ClientVerifier verifier;
    gameLauncher.setVerifier(&verifier);

    auto* pendingLaunch = new QVariantMap;
    QObject::connect(&gameLauncher, &GameLauncher::reinstallRequired, &download,
                     [&download, pendingLaunch](const QVariantMap& client) {
        *pendingLaunch = client;
        download.installClient(client);
    });
    QObject::connect(&download, &DownloadManager::installFinished, &gameLauncher,
                     [&gameLauncher, pendingLaunch](const QString& id) {
        if (pendingLaunch->value(QStringLiteral("id")).toString() != id) return;
        const QVariantMap client = *pendingLaunch;
        pendingLaunch->clear();
        gameLauncher.launch(client);
    });

    IntegrityChecker integrity(&settings, &installed);



    download.setBlocker(&integrity);
    gameLauncher.setBlocker(&integrity);

    download.setGameLauncher(&gameLauncher);




    auto* repairQueue = new QStringList;
    auto repairNext = [&download, &installed, &settings, &manifest, repairQueue] {
        while (!repairQueue->isEmpty()) {
            const QString id = repairQueue->takeFirst();
            QDir(QDir(settings.installDir()).filePath(id)).removeRecursively();
            installed.remove(id);


            QVariantMap client;
            for (const QVariant& v : manifest.clients()) {
                const QVariantMap c = v.toMap();
                if (c.value(QStringLiteral("id")).toString() == id) { client = c; break; }
            }
            if (client.isEmpty()) {
                qWarning() << "[integrity] клиента нет в каталоге, переустановить нельзя:" << id;
                continue;
            }
            download.installClient(client);
            return;
        }
    };
    QObject::connect(&integrity, &IntegrityChecker::repairRequired, &download,
                     [repairQueue, repairNext](const QStringList& ids) {
        *repairQueue = ids;
        repairNext();
    });
    QObject::connect(&download, &DownloadManager::installFinished, &download,
                     [repairNext](const QString&) { repairNext(); });

    QQmlApplicationEngine engine;



    static GatedNamFactory gatedNamFactory;
    engine.setNetworkAccessManagerFactory(&gatedNamFactory);
    engine.rootContext()->setContextProperty(QStringLiteral("AppSettings"), &settings);
    engine.rootContext()->setContextProperty(QStringLiteral("InstalledStore"), &installed);
    engine.rootContext()->setContextProperty(QStringLiteral("ManifestManager"), &manifest);
    engine.rootContext()->setContextProperty(QStringLiteral("DownloadManager"), &download);
    engine.rootContext()->setContextProperty(QStringLiteral("GameLauncher"), &gameLauncher);
    engine.rootContext()->setContextProperty(QStringLiteral("RuntimeManager"), &runtimes);
    engine.rootContext()->setContextProperty(QStringLiteral("NewsModel"), &news);
    engine.rootContext()->setContextProperty(QStringLiteral("AssetCache"), &assets);
    engine.rootContext()->setContextProperty(QStringLiteral("PhotoStore"), &photos);
    engine.rootContext()->setContextProperty(QStringLiteral("ConfigManager"), &configs);
    engine.rootContext()->setContextProperty(QStringLiteral("AppI18n"), &i18n);
    engine.rootContext()->setContextProperty(QStringLiteral("DiscordRPC"), &discord);
    engine.rootContext()->setContextProperty(QStringLiteral("ServerSync"), &serverSync);
    engine.rootContext()->setContextProperty(QStringLiteral("IntegrityChecker"), &integrity);

    auto* adTracker = new AdSessionTracker(&app);
    QObject::connect(&gameLauncher, &GameLauncher::gameProcessStarted,
                     adTracker, &AdSessionTracker::attachProcess);
    QObject::connect(&gameLauncher, &GameLauncher::gameProcessEnded,
                     adTracker, &AdSessionTracker::detachProcess);
    adTracker->setHosts(serverSync.promotedHosts());
    QObject::connect(&serverSync, &ServerSync::promotedChanged,
                     adTracker, [adTracker, &serverSync] {
                         adTracker->setHosts(serverSync.promotedHosts());
                     });

    engine.rootContext()->setContextProperty(QStringLiteral("AppUpdater"), &updater);


    engine.addImageProvider(QStringLiteral("assets"), assets.createImageProvider());
    engine.rootContext()->setContextProperty(QStringLiteral("LauncherVersion"), QString::fromLatin1(AppConfig::LauncherVersion));

    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed,
                     &app, [] { clearStartupWatchdog(); QCoreApplication::exit(-1); },
                     Qt::QueuedConnection);

    engine.rootContext()->setContextProperty(
        QStringLiteral("SoftwareRender"),
        qEnvironmentVariable("QT_QUICK_BACKEND").compare(QStringLiteral("software"),
                                                         Qt::CaseInsensitive) == 0);

    engine.rootContext()->setContextProperty(
        QStringLiteral("SoftwareRender"),
        qEnvironmentVariable("QT_QUICK_BACKEND").compare(QStringLiteral("software"),
                                                         Qt::CaseInsensitive) == 0);

    // Маркер снимаем только когда окно реально отрисовало первый кадр;
    // страховочный таймер — на случай, если кадры не идут, но процесс жив.
    auto clearWatchdogOnce = [] { clearStartupWatchdog(); };

    engine.loadFromModule("ExclusionLauncher", "Main");

    if (!engine.rootObjects().isEmpty()) {
        if (auto* win = qobject_cast<QQuickWindow*>(engine.rootObjects().constFirst())) {
            QObject::connect(win, &QQuickWindow::frameSwapped, &app, clearWatchdogOnce);

            // Второй экземпляр постучался — поднимаем окно.
            QObject::connect(&instanceServer, &QLocalServer::newConnection, &app,
                             [win, &instanceServer] {
                while (QLocalSocket* c = instanceServer.nextPendingConnection()) {
                    QObject::connect(c, &QLocalSocket::disconnected,
                                     c, &QLocalSocket::deleteLater);
                    c->readAll();
                }
                win->setWindowStates(win->windowStates() & ~Qt::WindowMinimized);
                win->show();
                win->raise();
                win->requestActivate();
            });
        }
    }
    QTimer::singleShot(30000, &app, clearWatchdogOnce);

    return app.exec();
}
