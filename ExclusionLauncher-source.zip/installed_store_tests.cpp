#include <QtTest/QtTest>

#include "core/InstalledStore.hpp"

class InstalledStoreTests final : public QObject
{
    Q_OBJECT

private slots:
    void legacyEntryWithoutPackageUrlDoesNotNeedUpdateWhenShaMatches()
    {
        InstalledStore store;
        const QString id = QStringLiteral("test-legacy-package-url");
        const QString sha = QStringLiteral("bbab9dba3281539ef52c0fc0aa28ac38478b769fd359ef68af3a5de5ee7908c3");

        store.remove(id);
        store.markInstalled(id, QStringLiteral("1.0.0"), sha, QString());

        QVERIFY(!store.needsUpdate(id, sha, QStringLiteral("https://pulsardev.tech/launcher/clients/skycore.tar.xz")));

        store.remove(id);
    }
};

QTEST_MAIN(InstalledStoreTests)
#include "installed_store_tests.moc"
