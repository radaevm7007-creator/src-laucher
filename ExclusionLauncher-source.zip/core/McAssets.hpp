#pragma once

#include <QObject>
#include <QString>
#include <QVector>
#include <QNetworkAccessManager>
#include <QPointer>









class McAssets final : public QObject
{
    Q_OBJECT
public:
    explicit McAssets(QObject* parent = nullptr);




    void ensure(const QString& indexPath, const QString& sharedDir);
    void cancel();

    bool isRunning() const { return m_running; }

signals:

    void progress(int done, int total, const QString& text);
    void finished(bool ok, const QString& error);

private:
    struct Job { QString hash; qint64 size; };

    void pump();
    void startJob(const Job& j);
    void onJobFinished(QNetworkReply* rep, const Job& j);

    QNetworkAccessManager m_nam;
    QString m_sharedDir;
    QVector<Job> m_queue;
    int m_next = 0;
    int m_inFlight = 0;
    int m_total = 0;
    int m_done = 0;
    int m_concurrency = 32;
    bool m_running = false;
    bool m_canceled = false;
    bool m_failed = false;
    QString m_error;
};
