#pragma once

#include <QObject>
#include <QProcess>
#include <QString>









class ArchiveManager final : public QObject
{
    Q_OBJECT
public:
    explicit ArchiveManager(QObject* parent = nullptr);


    void extractArchive(const QString& archivePath, const QString& destination);


    void extractZip(const QString& zipPath, const QString& destination) {
        extractArchive(zipPath, destination);
    }


    void cancel();

    bool busy() const { return m_process.state() != QProcess::NotRunning
                            || m_pipeConsumer != nullptr || m_pipeProducer != nullptr; }


    static QString systemTarPath();

    static QString bundled7zaPath();


    static bool extractSync(const QString& archivePath, const QString& destination,
                            QString* err = nullptr);

signals:
    void finished(bool ok, const QString& error);

private:
    void runProcess(const QString& program, const QStringList& args);
    void emitDone(bool ok, const QString& error);

    QProcess m_process;
    QProcess* m_pipeConsumer = nullptr;
    QProcess* m_pipeProducer = nullptr;
    bool      m_canceling = false;


    QString m_pendingTar;
    QString m_pendingDest;
    QString m_secondStepTar;



    QString m_fallbackArc;
    QString m_fallbackDest;
    bool    m_usingFallback = false;


    bool startFallbackExtract();
    bool startTwoStep7za();
    bool startPipeExtract(const QString& za, const QString& arc, const QString& dst);
    void onPipeFinished(int exitCode, QProcess::ExitStatus status);
    void destroyPipe();
};
