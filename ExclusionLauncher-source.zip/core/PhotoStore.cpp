#include "PhotoStore.hpp"

#include "AppConfig.hpp"
#include "AppPaths.hpp"
#include "NetworkFallback.hpp"

#include <QCryptographicHash>
#include <QDir>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QUrl>

PhotoStore::PhotoStore(QObject* parent) : QObject(parent)
{
    m_dir = AppPaths::subdir(QStringLiteral("photos"));
    QDir().mkpath(m_dir);
    loadIndex();
}

QString PhotoStore::nameOf(const QString& url)
{
    QString n = url;
    const int slash = n.lastIndexOf(QLatin1Char('/'));
    if (slash >= 0) n = n.mid(slash + 1);
    const int q = n.indexOf(QLatin1Char('?'));
    if (q >= 0) n.truncate(q);
    return n;
}

QString PhotoStore::pathOf(const QString& name) const
{
    return QDir(m_dir).filePath(name);
}

void PhotoStore::loadIndex()
{
    QFile f(QDir(m_dir).filePath(QStringLiteral("index.json")));
    if (!f.open(QIODevice::ReadOnly)) return;
    const auto obj = QJsonDocument::fromJson(f.readAll()).object();
    for (auto it = obj.begin(); it != obj.end(); ++it)
        m_index.insert(it.key(), it.value().toString());
}

void PhotoStore::saveIndex() const
{
    QJsonObject obj;
    for (auto it = m_index.begin(); it != m_index.end(); ++it)
        obj.insert(it.key(), it.value());
    QFile f(QDir(m_dir).filePath(QStringLiteral("index.json")));
    if (f.open(QIODevice::WriteOnly | QIODevice::Truncate))
        f.write(QJsonDocument(obj).toJson(QJsonDocument::Compact));
}

QString PhotoStore::fileFor(const QString& url) const
{
    if (url.isEmpty()) return {};
    const QString name = nameOf(url);
    const QString path = pathOf(name);
    if (QFile::exists(path))
        return QUrl::fromLocalFile(path).toString();
    return {};
}

QString PhotoStore::fallbackUrlFor(const QString& url) const
{
    return NetworkFallback::fallbackUrlForPrimary(url);
}

void PhotoStore::sync()
{
    if (m_checking) return;
    m_checking = true;
    emit changed();

    NetworkFallback::get(&m_net,
                         NetworkFallback::request(AppConfig::ServerBaseUrl + QStringLiteral("/photos.json")),
                         this,
                         [this](QNetworkReply* r) {
        r->deleteLater();
        m_checking = false;
        if (r->error() == QNetworkReply::NoError)
            onPhotosManifest(r->readAll());
        else
            qWarning() << "[photos] /photos.json не пришёл:" << r->errorString();
        emit changed();
    });
}

void PhotoStore::onPhotosManifest(const QByteArray& body)
{
    const auto obj = QJsonDocument::fromJson(body).object().value("photos").toObject();
    m_want.clear();
    for (auto it = obj.begin(); it != obj.end(); ++it)
        m_want.insert(it.key(), it.value().toString());


    for (const QString& have : m_index.keys()) {
        if (!m_want.contains(have)) {
            QFile::remove(pathOf(have));
            m_index.remove(have);
        }
    }


    for (auto it = m_want.begin(); it != m_want.end(); ++it) {
        const QString& name = it.key();
        const QString& sha = it.value();
        if (m_index.value(name) == sha && QFile::exists(pathOf(name)))
            continue;
        if (m_active.contains(name)) continue;
        m_queue.enqueue(name);
    }
    m_total = m_queue.size();
    m_pending = m_queue.size();
    saveIndex();
    pump();
}

void PhotoStore::pump()
{
    while (m_active.size() < kConcurrency && !m_queue.isEmpty())
        beginDownload(m_queue.dequeue());
    emit changed();
}

void PhotoStore::beginDownload(const QString& name)
{
    m_active.insert(name);
    const QString url = AppConfig::ServerBaseUrl
                        + QStringLiteral("/assets/uploads/") + name;
    NetworkFallback::get(&m_net, NetworkFallback::request(url), this, [this, name](QNetworkReply* r) {
        r->deleteLater();
        m_active.remove(name);
        if (m_pending > 0) --m_pending;

        if (r->error() == QNetworkReply::NoError) {
            const QByteArray bytes = r->readAll();
            const QString sha =
                QString::fromLatin1(QCryptographicHash::hash(bytes, QCryptographicHash::Sha256).toHex());
            QFile f(pathOf(name));
            if (f.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
                f.write(bytes);
                f.close();
                m_index.insert(name, sha);
                saveIndex();
                ++m_rev;
            }
        } else {
            qWarning() << "[photos] не скачалось" << name << ":" << r->errorString();
        }
        pump();
    });
}
