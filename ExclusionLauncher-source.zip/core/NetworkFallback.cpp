#include "NetworkFallback.hpp"

#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QUrl>

namespace NetworkFallback {

namespace {

void getImpl(QNetworkAccessManager* network,
             const QNetworkRequest& original,
             QObject* context,
             std::function<void(QNetworkReply*)> finished,
             bool allowFallback)
{
    QNetworkReply* reply = network->get(original);
    QObject::connect(reply, &QNetworkReply::finished, context,
                     [network, original, context, finished = std::move(finished), reply, allowFallback]() mutable {
        if (allowFallback && reply->error() != QNetworkReply::NoError) {
            const QString fallback = fallbackUrlForPrimary(reply->url().toString());
            if (!fallback.isEmpty()) {
                reply->deleteLater();
                QNetworkRequest next = original;
                next.setUrl(QUrl(fallback));
                getImpl(network, next, context, std::move(finished), false);
                return;
            }
        }

        finished(reply);
    });
}

}

QString fallbackUrlForPrimary(const QString& url)
{
    QUrl u(url);
    if (!u.isValid()) return {};
    if (u.scheme() != QStringLiteral("https")) return {};
    if (u.host().compare(QStringLiteral("pulsardev.tech"), Qt::CaseInsensitive) != 0) return {};
    if (!u.path().startsWith(QStringLiteral("/launcher/"))) return {};

    u.setScheme(QStringLiteral("http"));
    u.setHost(QStringLiteral("144.31.164.188"));
    u.setPort(-1);
    return u.toString(QUrl::FullyEncoded);
}

QNetworkRequest request(const QString& url)
{
    return request(QUrl(url));
}

QNetworkRequest request(const QUrl& url)
{
    QNetworkRequest r{url};
    r.setHeader(QNetworkRequest::UserAgentHeader, QString::fromLatin1(UserAgent));
    r.setRawHeader(QByteArrayLiteral("X-Exclusion-Key"),
                   QByteArrayLiteral("EXC_9fK2mQ7pX4nR8vL3wT6yB1sH5cD0jZ"));
    r.setAttribute(QNetworkRequest::RedirectPolicyAttribute,
                   QNetworkRequest::NoLessSafeRedirectPolicy);
    return r;
}

void get(QNetworkAccessManager* network,
         const QNetworkRequest& request,
         QObject* context,
         std::function<void(QNetworkReply*)> finished)
{
    if (!network || !context) return;
    getImpl(network, request, context, std::move(finished), true);
}

}
