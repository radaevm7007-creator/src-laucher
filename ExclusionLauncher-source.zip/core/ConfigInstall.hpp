#pragma once

#include <QString>

namespace ConfigInstall {

bool installDownloaded(const QString& downloadedPath,
                       const QString& stagingDir,
                       const QString& targetPath,
                       const QString& expectedSha,
                       const QString& displayName,
                       QString* error = nullptr);

}
