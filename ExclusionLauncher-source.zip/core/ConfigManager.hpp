#pragma once

#include <QFutureWatcher>
#include <QHash>
#include <QNetworkAccessManager>
#include <QPointer>
#include <QTimer>
#include <QVariantList>
#include <QObject>

class SettingsManager;
class QNetworkReply;

class ConfigManager final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QVariantList clients READ clients NOTIFY clientsChanged)
    Q_PROPERTY(bool loading READ loading NOTIFY loadingChanged)
    Q_PROPERTY(bool usingFallback READ usingFallback NOTIFY usingFallbackChanged)
    Q_PROPERTY(QString statusText READ statusText NOTIFY statusTextChanged)
    Q_PROPERTY(QString source READ source NOTIFY statusTextChanged)
    Q_PROPERTY(bool busy READ busy NOTIFY busyChanged)

public:
    explicit ConfigManager(SettingsManager* settings, QObject* parent = nullptr);

    QVariantList clients() const { return m_clients; }
    bool loading() const { return m_loading; }
    bool usingFallback() const { return m_usingFallback; }
    QString statusText() const { return m_statusText; }
    QString source() const { return m_source; }
    bool busy() const { return m_busy; }

    Q_INVOKABLE void refresh();
    Q_INVOKABLE void downloadConfig(const QString& clientId, const QString& configId);
    Q_INVOKABLE void rateConfig(const QString& clientId, const QString& configId, int stars);

signals:
    void clientsChanged();
    void loadingChanged();
    void usingFallbackChanged();
    void statusTextChanged();
    void busyChanged();

private:
    bool parseCatalog(const QByteArray& data, const QUrl& baseUrl);
    void loadCache();
    void writeCache(const QByteArray& body);
    void loadInstalled();
    void saveInstalled() const;
    void rebuildClients();
    void setStatus(const QString& text);
    QString keyFor(const QString& clientId, const QString& configId) const;
    QVariantMap findConfig(const QString& clientId, const QString& configId) const;
    QVariantMap installedEntry(const QString& key) const;
    void setInstalledEntry(const QString& key, const QVariantMap& value);
    QString resolveInstallPath(const QString& clientId, const QString& relativePath) const;
    void setKeyProgress(const QString& key, double value, const QString& state = QString());
    void clearKeyProgress(const QString& key);
    void finishDownloadWithError(const QString& key, const QString& message);
    void reportDownload(const QString& clientId, const QString& configId, const QString& version);
    void applyRatingResponse(const QString& clientId, const QString& configId, const QByteArray& body);
    void updateCatalogConfigFields(const QString& clientId, const QString& configId, const QVariantMap& fields);

    SettingsManager* m_settings = nullptr;
    QNetworkAccessManager m_network;
    QTimer m_pollTimer;
    QVariantList m_catalog;
    QVariantList m_clients;
    QHash<QString, QVariantMap> m_installed;
    QHash<QString, double> m_progressByKey;
    QHash<QString, QString> m_stateByKey;
    bool m_loading = false;
    bool m_usingFallback = true;
    QString m_statusText;
    QString m_source;
    bool m_busy = false;

    QString m_activeKey;
    QString m_activeClientId;
    QString m_activeConfigId;
    QString m_activeVersion;
    QString m_activeArchive;
    QString m_activeStagingDir;
    QPointer<QNetworkReply> m_reply;
    QFutureWatcher<QString> m_installWatcher;
};
