#include "ConfigInstall.hpp"

#include "ArchiveManager.hpp"
#include "HashVerifier.hpp"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QRegularExpression>

namespace {

bool isArchive(const QString& path)
{
    const QString lower = path.toLower();
    return lower.endsWith(QStringLiteral(".zip"))
        || lower.endsWith(QStringLiteral(".tar"))
        || lower.endsWith(QStringLiteral(".tar.xz"))
        || lower.endsWith(QStringLiteral(".txz"))
        || lower.endsWith(QStringLiteral(".tar.gz"))
        || lower.endsWith(QStringLiteral(".tgz"));
}

bool copyRecursively(const QString& sourcePath, const QString& destinationPath, QString* error)
{
    QFileInfo sourceInfo(sourcePath);
    if (!sourceInfo.exists()) {
        if (error) *error = QStringLiteral("Источник конфига не найден.");
        return false;
    }

    if (sourceInfo.isDir()) {
        QDir sourceDir(sourcePath);
        if (!QDir().mkpath(destinationPath)) {
            if (error) *error = QStringLiteral("Не удалось создать папку назначения.");
            return false;
        }
        const QFileInfoList entries = sourceDir.entryInfoList(QDir::NoDotAndDotDot | QDir::AllEntries);
        for (const QFileInfo& entry : entries) {
            const QString nextDst = QDir(destinationPath).filePath(entry.fileName());
            if (!copyRecursively(entry.absoluteFilePath(), nextDst, error))
                return false;
        }
        return true;
    }

    QFile::remove(destinationPath);
    QDir().mkpath(QFileInfo(destinationPath).absolutePath());
    if (!QFile::copy(sourcePath, destinationPath)) {
        if (error) *error = QStringLiteral("Не удалось скопировать файл конфига.");
        return false;
    }
    return true;
}

QString effectiveSourceRoot(const QString& stagingDir)
{
    QDir dir(stagingDir);
    const QFileInfoList entries = dir.entryInfoList(QDir::NoDotAndDotDot | QDir::AllEntries);
    if (entries.size() == 1 && entries.first().isDir())
        return entries.first().absoluteFilePath();
    return stagingDir;
}

QString safeBaseName(QString value, const QString& fallback)
{
    value = value.trimmed();
    if (value.isEmpty()) value = fallback;
    value.replace(QRegularExpression(QStringLiteral(R"([\\/:*?"<>|])")), QStringLiteral("_"));
    value.replace(QRegularExpression(QStringLiteral(R"(\s+)")), QStringLiteral(" "));
    value = value.trimmed();
    return value.isEmpty() ? QStringLiteral("config") : value;
}

QString directFileDestination(const QString& downloadedPath,
                              const QString& targetPath,
                              const QString& displayName)
{
    QFileInfo targetInfo(targetPath);
    if (!targetInfo.suffix().isEmpty())
        return targetPath;

    const QFileInfo sourceInfo(downloadedPath);
    const QString suffix = sourceInfo.suffix();
    QString base = safeBaseName(displayName, sourceInfo.completeBaseName());
    if (!suffix.isEmpty() && QFileInfo(base).suffix().compare(suffix, Qt::CaseInsensitive) != 0)
        base += QLatin1Char('.') + suffix;
    return QDir(targetPath).filePath(base);
}

}

bool ConfigInstall::installDownloaded(const QString& downloadedPath,
                                      const QString& stagingDir,
                                      const QString& targetPath,
                                      const QString& expectedSha,
                                      const QString& displayName,
                                      QString* error)
{
    if (!expectedSha.isEmpty() && !HashVerifier::matchesSha256(downloadedPath, expectedSha)) {
        if (error) *error = QStringLiteral("Хэш конфига не совпал");
        return false;
    }

    if (!isArchive(downloadedPath)) {
        const QString destination = directFileDestination(downloadedPath, targetPath, displayName);
        return copyRecursively(downloadedPath, destination, error);
    }

    QDir(stagingDir).removeRecursively();
    QString extractError;
    if (!ArchiveManager::extractSync(downloadedPath, stagingDir, &extractError)) {
        if (error) *error = extractError.isEmpty()
                                ? QStringLiteral("Не удалось распаковать конфиг")
                                : extractError;
        return false;
    }

    const QString sourceRoot = effectiveSourceRoot(stagingDir);
    if (!copyRecursively(sourceRoot, targetPath, error)) {
        if (error && error->isEmpty()) *error = QStringLiteral("Не удалось установить конфиг");
        return false;
    }
    return true;
}
