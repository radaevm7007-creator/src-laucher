#pragma once

#include <QString>






namespace DesktopShortcut {



void ensure();

}
