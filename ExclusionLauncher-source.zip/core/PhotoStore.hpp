#pragma once

#include <QHash>
#include <QNetworkAccessManager>
#include <QObject>
#include <QQueue>
#include <QSet>
#include <QString>

class QNetworkReply;











class PhotoStore final : public QObject
{
    Q_OBJECT

    Q_PROPERTY(bool checking READ checking NOTIFY changed)

    Q_PROPERTY(bool ready READ ready NOTIFY changed)
    Q_PROPERTY(int rev READ rev NOTIFY changed)
    Q_PROPERTY(int total READ total NOTIFY changed)
    Q_PROPERTY(int done READ done NOTIFY changed)

public:
    explicit PhotoStore(QObject* parent = nullptr);

    bool checking() const { return m_checking; }
    bool ready() const { return !m_checking && m_pending == 0; }
    int rev() const { return m_rev; }
    int total() const { return m_total; }
    int done() const { return m_total - m_pending; }

    Q_INVOKABLE void sync();
    Q_INVOKABLE QString fileFor(const QString& url) const;
    Q_INVOKABLE QString fallbackUrlFor(const QString& url) const;

signals:
    void changed();

private:
    static QString nameOf(const QString& url);
    QString pathOf(const QString& name) const;
    void loadIndex();
    void saveIndex() const;
    void onPhotosManifest(const QByteArray& body);
    void pump();
    void beginDownload(const QString& name);

    QNetworkAccessManager m_net;
    QString m_dir;
    QHash<QString, QString> m_index;
    QHash<QString, QString> m_want;
    QQueue<QString> m_queue;
    QSet<QString> m_active;

    int m_pending = 0;
    int m_total = 0;
    int m_rev = 0;
    bool m_checking = false;

    static constexpr int kConcurrency = 6;
};
