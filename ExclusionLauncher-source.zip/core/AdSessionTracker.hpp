#pragma once

#include <QHash>
#include <QNetworkAccessManager>
#include <QObject>
#include <QSet>
#include <QStringList>
#include <QTimer>

/**
 * Учёт посещений рекламных серверов.
 *
 * Вшивать счётчик в каждый клиент нельзя, поэтому лаунчер смотрит за
 * сетевыми соединениями процесса игры: раз в несколько секунд опрашивается
 * TCP-таблица Windows (GetExtendedTcpTable по PID), ESTABLISHED-соединения
 * сверяются с IP рекламных серверов. Домены резолвятся заранее.
 *
 * Накопленное время уезжает на /stats/ad-session. В боте по этим данным
 * считаются заходы, уникальные игроки и среднее удержание.
 */
class AdSessionTracker final : public QObject
{
    Q_OBJECT
public:
    explicit AdSessionTracker(QObject* parent = nullptr);

    void setHosts(const QStringList& hosts);   // адреса из servers.json
    void attachProcess(quint64 pid);
    void detachProcess(quint64 pid);

private slots:
    void poll();

private:
    struct Session {
        QString label;        // метка для отчёта (домен или ip)
        qint64 accMs = 0;     // накоплено с последней отправки
        qint64 lastSeen = 0;  // когда последний раз видели соединение
    };

    void resolvePending();
    void finalize(quint64 pid, bool sendRemainder);
    void send(const QString& serverLabel, qint64 durationSec);
    static QString ipv4ToString(quint32 v);

    QTimer m_timer;
    QTimer m_resolveTimer;
    QNetworkAccessManager m_net;

    QStringList m_hosts;
    QSet<QString> m_unresolved;
    QSet<QString> m_trackedIps;                 // все известные ip рекламы
    QHash<QString, QString> m_ipToHost;         // ip -> метка отчёта

    QHash<quint64, QHash<QString, Session>> m_active;

    qint64 m_lastPollMs = 0;
};
