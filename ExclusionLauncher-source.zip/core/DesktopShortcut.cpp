#include "DesktopShortcut.hpp"

#include <QCoreApplication>
#include <QDir>

#ifdef Q_OS_WIN
#include <windows.h>
#include <shlobj.h>
#include <shobjidl.h>
#include <objbase.h>
#endif

namespace DesktopShortcut {

void ensure()
{
#ifdef Q_OS_WIN
    const QString exe = QDir::toNativeSeparators(QCoreApplication::applicationFilePath());
    const QString workdir = QDir::toNativeSeparators(QCoreApplication::applicationDirPath());



    const HRESULT init = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);




    const QString icoPath = QDir(QCoreApplication::applicationDirPath())
                            .filePath(QStringLiteral("icon.ico"));
    const QString icoNative = QDir::toNativeSeparators(icoPath);
    const bool haveIco = GetFileAttributesW(reinterpret_cast<const wchar_t*>(icoNative.utf16()))
                         != INVALID_FILE_ATTRIBUTES;

    wchar_t* desktopPath = nullptr;
    if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_Desktop, 0, nullptr, &desktopPath))) {
        IShellLinkW* link = nullptr;
        if (SUCCEEDED(CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER,
                                       IID_IShellLinkW, (void**)&link))) {
            link->SetPath(reinterpret_cast<const wchar_t*>(exe.utf16()));
            link->SetWorkingDirectory(reinterpret_cast<const wchar_t*>(workdir.utf16()));
            if (haveIco)
                link->SetIconLocation(reinterpret_cast<const wchar_t*>(icoNative.utf16()), 0);
            else
                link->SetIconLocation(reinterpret_cast<const wchar_t*>(exe.utf16()), 0);
            link->SetDescription(L"Exclusion Launcher");

            IPersistFile* pf = nullptr;
            if (SUCCEEDED(link->QueryInterface(IID_IPersistFile, (void**)&pf))) {
                const QString lnk = QString::fromWCharArray(desktopPath)
                                    + QStringLiteral("\\Exclusion Launcher.lnk");
                pf->Save(reinterpret_cast<const wchar_t*>(lnk.utf16()), TRUE);
                pf->Release();



                SHChangeNotify(SHCNE_UPDATEITEM, SHCNF_PATHW,
                               reinterpret_cast<const wchar_t*>(lnk.utf16()), nullptr);
                SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST, nullptr, nullptr);
            }
            link->Release();
        }
        CoTaskMemFree(desktopPath);
    }

    if (SUCCEEDED(init)) CoUninitialize();
#endif
}

}
