#include "ClientInstall.hpp"

#include "ClientVerifier.hpp"

#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QThread>
#include <QDebug>

namespace {

void makeWritable(const QString& path)
{
    QFileInfo info(path);
    if (!info.exists()) return;

    if (info.isDir()) {
        QDir dir(path);
        const QFileInfoList entries = dir.entryInfoList(QDir::Dirs | QDir::Files | QDir::Hidden | QDir::System | QDir::NoDotAndDotDot);
        for (const QFileInfo& entry : entries)
            makeWritable(entry.absoluteFilePath());
    }

    QFile::setPermissions(path,
                          QFileDevice::ReadOwner | QFileDevice::WriteOwner | QFileDevice::ExeOwner
                          | QFileDevice::ReadUser | QFileDevice::WriteUser | QFileDevice::ExeUser
                          | QFileDevice::ReadGroup | QFileDevice::WriteGroup | QFileDevice::ExeGroup
                          | QFileDevice::ReadOther | QFileDevice::WriteOther | QFileDevice::ExeOther);
}

bool removeTree(QString path)
{
    QDir dir(path);
    if (!dir.exists()) return true;

    for (int attempt = 0; attempt < 3; ++attempt) {
        makeWritable(path);
        if (QDir(path).removeRecursively()) return true;
        QThread::msleep(150);
    }
    return !QDir(path).exists();
}

QString uniqueBackupPath(const QString& finalDir)
{
    const QString stamp = QDateTime::currentDateTimeUtc().toString(QStringLiteral("yyyyMMddHHmmsszzz"));
    return finalDir + QStringLiteral(".old-") + stamp;
}

QString extractedSourceDir(const QString& stagingDir, const QString& finalDir)
{
    QDir staging(stagingDir);
    const auto entries = staging.entryList(QDir::Dirs | QDir::Files | QDir::Hidden | QDir::System | QDir::NoDotAndDotDot);
    if (entries.size() == 1) {
        const QString onlyPath = staging.filePath(entries.first());
        const QString finalName = QFileInfo(finalDir).fileName();
        if (QFileInfo(onlyPath).isDir() && entries.first().compare(finalName, Qt::CaseInsensitive) == 0)
            return onlyPath;
    }
    return stagingDir;
}

bool moveDir(const QString& from, const QString& to)
{
    return QDir().rename(from, to);
}

}

QString ClientInstall::installExtractedClient(const QString& finalDir, const QString& stagingDir)
{
    QString backupDir;
    if (QFileInfo::exists(finalDir)) {
        backupDir = uniqueBackupPath(finalDir);
        if (!moveDir(finalDir, backupDir)) {
            if (!removeTree(finalDir))
                return QStringLiteral("Не удалось заменить старую версию клиента. Закройте клиент и попробуйте снова.");
            backupDir.clear();
        }
    }

    const QString sourceDir = extractedSourceDir(stagingDir, finalDir);
    if (!moveDir(sourceDir, finalDir)) {
        if (!backupDir.isEmpty())
            moveDir(backupDir, finalDir);
        return QStringLiteral("Не удалось переместить распакованный клиент.");
    }

    QDir(stagingDir).removeRecursively();

    if (!backupDir.isEmpty() && !removeTree(backupDir))
        qWarning() << "[install] old client backup was left on disk:" << backupDir;

    if (!ClientVerifier::writeManifest(finalDir))
        qWarning() << "[install] не удалось записать манифест файлов";

    return QString();
}
