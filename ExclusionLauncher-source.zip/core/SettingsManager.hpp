#pragma once

#include <QObject>
#include <QString>
#include <QStringList>

class SettingsManager final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString nickname READ nickname WRITE setNickname NOTIFY nicknameChanged)
    Q_PROPERTY(QString installDir READ installDir WRITE setInstallDir NOTIFY installDirChanged)
    Q_PROPERTY(QString accentColor READ accentColor WRITE setAccentColor NOTIFY accentColorChanged)
    Q_PROPERTY(bool snowEnabled READ snowEnabled WRITE setSnowEnabled NOTIFY snowEnabledChanged)
    Q_PROPERTY(bool autoUpdates READ autoUpdates WRITE setAutoUpdates NOTIFY autoUpdatesChanged)
    Q_PROPERTY(bool clearTemp READ clearTemp WRITE setClearTemp NOTIFY clearTempChanged)
    Q_PROPERTY(int parallelDownloads READ parallelDownloads WRITE setParallelDownloads NOTIFY parallelDownloadsChanged)
    Q_PROPERTY(QString language READ language WRITE setLanguage NOTIFY languageChanged)
    Q_PROPERTY(bool minimizeToTray READ minimizeToTray WRITE setMinimizeToTray NOTIFY minimizeToTrayChanged)
    Q_PROPERTY(bool checkUpdatesOnStart READ checkUpdatesOnStart WRITE setCheckUpdatesOnStart NOTIFY checkUpdatesOnStartChanged)
    Q_PROPERTY(QString selectedClientId READ selectedClientId WRITE setSelectedClientId NOTIFY selectedClientIdChanged)
    Q_PROPERTY(int memoryMB READ memoryMB WRITE setMemoryMB NOTIFY memoryMBChanged)
    Q_PROPERTY(bool fullscreen READ fullscreen WRITE setFullscreen NOTIFY fullscreenChanged)
    Q_PROPERTY(bool hideOnStart READ hideOnStart WRITE setHideOnStart NOTIFY hideOnStartChanged)
    Q_PROPERTY(bool verifyIntegrity READ verifyIntegrity WRITE setVerifyIntegrity NOTIFY verifyIntegrityChanged)
    Q_PROPERTY(bool discordRichPresence READ discordRichPresence WRITE setDiscordRichPresence NOTIFY discordRichPresenceChanged)
    Q_PROPERTY(QStringList favouriteClientIds READ favouriteClientIds NOTIFY favouriteClientIdsChanged)
    Q_PROPERTY(QString runtimePath READ runtimePath WRITE setRuntimePath NOTIFY runtimePathChanged)
    Q_PROPERTY(QString backgroundFile READ backgroundFile WRITE setBackgroundFile NOTIFY backgroundFileChanged)
    Q_PROPERTY(int bgBlur READ bgBlur WRITE setBgBlur NOTIFY bgBlurChanged)

    Q_PROPERTY(bool disclaimerAccepted READ disclaimerAccepted WRITE setDisclaimerAccepted NOTIFY disclaimerAcceptedChanged)

public:
    explicit SettingsManager(QObject* parent = nullptr);

    QString nickname() const { return m_nickname; }
    QString installDir() const { return m_installDir; }
    QString accentColor() const { return m_accentColor; }
    bool snowEnabled() const { return m_snowEnabled; }
    bool autoUpdates() const { return m_autoUpdates; }
    bool clearTemp() const { return m_clearTemp; }
    int parallelDownloads() const { return m_parallelDownloads; }
    QString language() const { return m_language; }
    bool minimizeToTray() const { return m_minimizeToTray; }
    bool checkUpdatesOnStart() const { return m_checkUpdatesOnStart; }
    QString selectedClientId() const { return m_selectedClientId; }
    int memoryMB() const { return m_memoryMB; }
    bool fullscreen() const { return m_fullscreen; }
    bool hideOnStart() const { return m_hideOnStart; }
    bool verifyIntegrity() const { return m_verifyIntegrity; }
    bool discordRichPresence() const { return m_discordRichPresence; }
    bool disclaimerAccepted() const { return m_disclaimerAccepted; }
    void setDisclaimerAccepted(bool value);
    QStringList favouriteClientIds() const { return m_favouriteClientIds; }



    Q_INVOKABLE static QString sanitizeNickname(const QString& value);

    Q_INVOKABLE bool isFavourite(const QString& id) const { return m_favouriteClientIds.contains(id); }
    Q_INVOKABLE void toggleFavourite(const QString& id);

    QString runtimePath() const { return m_runtimePath; }
    void setRuntimePath(const QString& value);

    // Кастомный фон: путь к выбранной картинке (пусто = стандартный фон).
    QString backgroundFile() const { return m_backgroundFile; }
    void setBackgroundFile(const QString& value);
    int bgBlur() const { return m_bgBlur; }
    void setBgBlur(int value);

    void setNickname(const QString& value);
    void setInstallDir(const QString& value);
    void setAccentColor(const QString& value);
    void setSnowEnabled(bool value);
    void setAutoUpdates(bool value);
    void setClearTemp(bool value);
    void setParallelDownloads(int value);
    void setLanguage(const QString& value);
    void setMinimizeToTray(bool value);
    void setCheckUpdatesOnStart(bool value);
    void setSelectedClientId(const QString& value);
    void setMemoryMB(int value);
    void setFullscreen(bool value);
    void setHideOnStart(bool value);
    void setVerifyIntegrity(bool value);
    void setDiscordRichPresence(bool value);

    Q_INVOKABLE void resetInstallDir();
    Q_INVOKABLE void openInstallFolder();

signals:
    void nicknameChanged();
    void installDirChanged();
    void accentColorChanged();
    void snowEnabledChanged();
    void autoUpdatesChanged();
    void clearTempChanged();
    void parallelDownloadsChanged();
    void languageChanged();
    void minimizeToTrayChanged();
    void checkUpdatesOnStartChanged();
    void selectedClientIdChanged();
    void memoryMBChanged();
    void fullscreenChanged();
    void hideOnStartChanged();
    void verifyIntegrityChanged();
    void discordRichPresenceChanged();
    void disclaimerAcceptedChanged();
    void favouriteClientIdsChanged();
    void runtimePathChanged();
    void backgroundFileChanged();
    void bgBlurChanged();

private:
    void load();
    void save() const;

    QString m_nickname = QStringLiteral("Steve");
    QString m_installDir;
    QString m_accentColor = QStringLiteral("#8A63F5");
    bool m_snowEnabled = false;
    bool m_autoUpdates = true;
    bool m_clearTemp = true;
    int m_parallelDownloads = 2;
    QString m_language = QStringLiteral("Русский");
    bool m_minimizeToTray = true;
    bool m_checkUpdatesOnStart = true;
    QString m_selectedClientId;
    int m_memoryMB = 4096;
    bool m_fullscreen = false;

    bool m_hideOnStart = true;
    bool m_verifyIntegrity = true;
    bool m_discordRichPresence = true;
    bool m_disclaimerAccepted = false;
    QStringList m_favouriteClientIds;
    QString m_runtimePath;
    QString m_backgroundFile;
    int m_bgBlur = 55;
};
