#pragma once

#include <QNetworkRequest>
#include <functional>
#include <QString>

class QObject;
class QNetworkAccessManager;
class QNetworkReply;

namespace NetworkFallback {

inline constexpr auto UserAgent = "ExclusionLauncher/0.1";

QString fallbackUrlForPrimary(const QString& url);
QNetworkRequest request(const QString& url);
QNetworkRequest request(const QUrl& url);
void get(QNetworkAccessManager* network,
         const QNetworkRequest& request,
         QObject* context,
         std::function<void(QNetworkReply*)> finished);

}
