#pragma once

#include <QObject>
#include <QUrl>
#include <QElapsedTimer>
#include <QFile>
#include <QFutureWatcher>
#include <QNetworkAccessManager>
#include <QPointer>
#include <QVariantMap>

#include "ArchiveManager.hpp"

class InstalledStore;
class SettingsManager;
class IntegrityChecker;
class GameLauncher;
class QNetworkReply;

class DownloadManager final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool busy READ busy NOTIFY stateChanged)
    Q_PROPERTY(QString currentClientId READ currentClientId NOTIFY stateChanged)
    Q_PROPERTY(double progress READ progress NOTIFY progressChanged)
    Q_PROPERTY(QString statusText READ statusText NOTIFY stateChanged)
    Q_PROPERTY(QString speedText READ speedText NOTIFY progressChanged)
    Q_PROPERTY(QString errorMessage READ errorMessage NOTIFY errorChanged)

public:
    explicit DownloadManager(SettingsManager* settings, InstalledStore* installed, QObject* parent = nullptr);

    bool busy() const { return m_busy; }
    QString currentClientId() const { return m_currentClientId; }
    double progress() const { return m_progress; }
    QString statusText() const { return m_statusText; }
    QString speedText() const { return m_speedText; }
    QString errorMessage() const { return m_errorMessage; }



    void setBlocker(IntegrityChecker* blocker) { m_blocker = blocker; }



    void setGameLauncher(GameLauncher* launcher) { m_game = launcher; }

    Q_INVOKABLE void installClient(const QVariantMap& client);
    Q_INVOKABLE void cancel();
    Q_INVOKABLE void removeClient(const QString& id);
    Q_INVOKABLE void clearError();

signals:
    void stateChanged();
    void progressChanged();
    void errorChanged();
    void installFinished(const QString& id);

private:

    void reportDownload(const QString& clientId, const QString& version);

    void beginHttpDownload(const QUrl& url);
    void beginResourceCopy(const QString& resourcePath);
    void verifyAndExtract();
    void finishWithError(const QString& message);
    void resetTransfer();
    void setState(const QString& text);
    QString humanSpeed(qint64 bytes, qint64 ms) const;

    SettingsManager* m_settings = nullptr;
    InstalledStore* m_installed = nullptr;
    IntegrityChecker* m_blocker = nullptr;
    GameLauncher* m_game = nullptr;
    QNetworkAccessManager m_network;
    QPointer<QNetworkReply> m_reply;
    class SegmentedDownloader* m_seg = nullptr;
    QFile m_file;
    ArchiveManager m_archive;
    QElapsedTimer m_timer;

    QFutureWatcher<bool> m_hashWatcher;



    QFutureWatcher<QString> m_installWatcher;
    QVariantMap m_client;
    QString m_currentClientId;
    QString m_tempZip;
    QString m_stagingDir;
    QString m_statusText;
    QString m_speedText;
    QString m_errorMessage;
    double m_progress = 0.0;
    bool m_busy = false;




    QUrl m_downloadUrl;
    bool m_archiveReused = false;
};
