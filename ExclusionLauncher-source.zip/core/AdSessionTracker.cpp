#include "AdSessionTracker.hpp"

#include "AppConfig.hpp"
#include "HardwareId.hpp"

#include <QDateTime>
#include <QHostAddress>
#include <QHostInfo>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkReply>
#include <QNetworkRequest>

#ifdef Q_OS_WIN
#include <winsock2.h>
#include <iphlpapi.h>
#include <ws2tcpip.h>
#endif

namespace {
constexpr int kPollSecs = 5;      // период опроса TCP-таблицы
constexpr int kFlushSecs = 120;   // промежуточная отправка длинных сессий
constexpr int kGapSecs = 20;      // тишина дольше — игрок вышел с сервера
}

AdSessionTracker::AdSessionTracker(QObject* parent)
    : QObject(parent)
{
    m_timer.setInterval(kPollSecs * 1000);
    connect(&m_timer, &QTimer::timeout, this, &AdSessionTracker::poll);
    m_timer.start();

    // DNS рекламных доменов обновляем: адреса за CDN переезжают
    m_resolveTimer.setInterval(10 * 60 * 1000);
    connect(&m_resolveTimer, &QTimer::timeout, this, &AdSessionTracker::resolvePending);
    m_resolveTimer.start();
}

// dwRemoteAddr лежит в сетевом порядке байт: младший байт — первый октет.
QString AdSessionTracker::ipv4ToString(quint32 v)
{
    return QStringLiteral("%1.%2.%3.%4")
        .arg(v & 0xFFu)
        .arg((v >> 8) & 0xFFu)
        .arg((v >> 16) & 0xFFu)
        .arg((v >> 24) & 0xFFu);
}

void AdSessionTracker::setHosts(const QStringList& hosts)
{
    QStringList clean;
    for (const QString& h : hosts) {
        QString s = h.trimmed();
        if (s.isEmpty()) continue;
        // «1.2.3.4:25565» и «host:port» — порт не нужен
        const int colon = s.indexOf(QLatin1Char(':'));
        if (colon > 0) s.truncate(colon);
        clean << s;
    }
    if (clean == m_hosts) return;
    m_hosts = clean;

    m_trackedIps.clear();
    m_ipToHost.clear();
    m_unresolved.clear();
    for (const QString& h : m_hosts) {
        const QHostAddress lit(h);
        if (!lit.isNull() && lit.protocol() == QAbstractSocket::IPv4Protocol) {
            m_trackedIps.insert(h);
            if (!m_ipToHost.contains(h)) m_ipToHost.insert(h, h);
        } else {
            m_unresolved.insert(h);
        }
    }
    resolvePending();
}

void AdSessionTracker::resolvePending()
{
    for (const QString& host : qAsConst(m_unresolved)) {
        QHostInfo::lookupHost(host, this,
            [this, host](const QHostInfo& info) {
                m_unresolved.remove(host);
                if (info.error() != QHostInfo::NoError) return;
                for (const QHostAddress& a : info.addresses()) {
                    if (a.protocol() != QAbstractSocket::IPv4Protocol) continue;
                    const QString ip = a.toString();
                    m_trackedIps.insert(ip);
                    if (!m_ipToHost.contains(ip))
                        m_ipToHost.insert(ip, host);
                }
            });
    }
}

void AdSessionTracker::attachProcess(quint64 pid)
{
    if (pid) m_active.insert(pid, {});
}

void AdSessionTracker::detachProcess(quint64 pid)
{
    finalize(pid, true);
}

void AdSessionTracker::finalize(quint64 pid, bool sendRemainder)
{
    auto pit = m_active.find(pid);
    if (pit == m_active.end()) return;
    for (auto it = pit->begin(); it != pit->end(); ++it) {
        const qint64 secs = it->accMs / 1000;
        if (sendRemainder && secs >= 5)
            send(it->label, secs);
    }
    m_active.erase(pit);
}

void AdSessionTracker::poll()
{
    const qint64 now = QDateTime::currentMSecsSinceEpoch();
    const qint64 dtMs = m_lastPollMs ? qBound<qint64>(qint64(0), now - m_lastPollMs,
                                                      qint64(kPollSecs) * 1000 * 4)
                                     : kPollSecs * 1000;
    m_lastPollMs = now;

    if (m_active.isEmpty() || m_trackedIps.isEmpty())
        return;

#ifdef Q_OS_WIN
    // снимок ESTABLISHED-соединений процессов игр
    QHash<quint64, QSet<QString>> snapshot;
    DWORD size = 0;
    if (GetExtendedTcpTable(nullptr, &size, FALSE, AF_INET,
                            TCP_TABLE_OWNER_PID_ALL, 0) == NO_ERROR || size > 0) {
        QByteArray buf(int(size), 0);
        if (GetExtendedTcpTable(buf.data(), &size, FALSE, AF_INET,
                                TCP_TABLE_OWNER_PID_ALL, 0) == NO_ERROR) {
            auto* table = reinterpret_cast<MIB_TCPTABLE_OWNER_PID*>(buf.data());
            for (DWORD i = 0; i < table->dwNumEntries; ++i) {
                const MIB_TCPROW_OWNER_PID& r = table->table[i];
                if (r.dwState != MIB_TCP_STATE_ESTAB) continue;
                const quint64 pid = r.dwOwningPid;
                if (!m_active.contains(pid)) continue;

                const QString ip = ipv4ToString(r.dwRemoteAddr);
                if (!m_trackedIps.contains(ip)) continue;
                snapshot[pid].insert(ip);
            }
        }
    }

    for (auto pit = m_active.begin(); pit != m_active.end(); ++pit) {
        const QSet<QString>& present = snapshot.value(pit.key());

        for (auto it = pit->begin(); it != pit->end(); ) {
            Session& s = it.value();
            if (present.contains(it.key())) {
                s.accMs += dtMs;
                s.lastSeen = now;
                ++it;
            } else if (now - s.lastSeen > kGapSecs * 1000) {
                // игрок вышел: отправляем накопленное и закрываем визит
                const qint64 secs = s.accMs / 1000;
                if (secs >= 5) send(s.label, secs);
                it = pit->erase(it);
            } else {
                ++it;   // короткая пауза (лаг/ресинк) — не рвём сессию
            }
        }

        for (const QString& ip : present) {
            if (pit->contains(ip)) continue;
            Session s;
            s.label = m_ipToHost.value(ip, ip);
            s.accMs = dtMs;
            s.lastSeen = now;
            pit->insert(ip, s);
        }

        // длинную сессию отправляем кусками, чтобы не терять при вылете игры
        for (auto it = pit->begin(); it != pit->end(); ++it) {
            if (it->accMs >= kFlushSecs * 1000) {
                send(it->label, it->accMs / 1000);
                it->accMs = 0;
            }
        }
    }
#endif
}

void AdSessionTracker::send(const QString& serverLabel, qint64 durationSec)
{
    if (durationSec <= 0 || serverLabel.isEmpty()) return;

    QNetworkRequest req{QUrl(AppConfig::ServerBaseUrl + QStringLiteral("/stats/ad-session"))};
    req.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/json"));
    req.setRawHeader(QByteArrayLiteral("X-Exclusion-Key"),
                     QByteArrayLiteral("EXC_9fK2mQ7pX4nR8vL3wT6yB1sH5cD0jZ"));

    QJsonObject body{
        {QStringLiteral("hwid"), HardwareId::value()},
        {QStringLiteral("server"), serverLabel.left(128)},
        {QStringLiteral("duration"), double(durationSec)},
    };
    auto* r = m_net.post(req, QJsonDocument(body).toJson(QJsonDocument::Compact));
    connect(r, &QNetworkReply::finished, r, &QNetworkReply::deleteLater);
}
