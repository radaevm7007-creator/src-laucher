#pragma once

#include <QByteArray>
#include <QHash>
#include <QMutex>
#include <QNetworkAccessManager>
#include <QObject>
#include <QSet>

class QQuickImageProvider;







class AssetCache final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool ready READ ready NOTIFY readyChanged)
    Q_PROPERTY(int totalCount READ totalCount CONSTANT)
    Q_PROPERTY(int readyCount READ readyCount NOTIFY readyChanged)

public:
    explicit AssetCache(QObject* parent = nullptr);

    bool ready() const { return m_pendingCount == 0; }
    int  totalCount() const { return m_totalCount; }
    int  readyCount() const { return m_totalCount - m_pendingCount; }


    Q_INVOKABLE bool hasAsset(const QString& name) const;


    Q_INVOKABLE void refresh();


    QByteArray dataFor(const QString& name) const;



    QQuickImageProvider* createImageProvider();

signals:
    void readyChanged();
    void assetReady(const QString& name);

private:
    struct AssetDef {
        QString name;
        QString url;
    };

    void startDownload(const AssetDef& a);

    QNetworkAccessManager m_network;
    QList<AssetDef> m_defs;
    QSet<QString> m_downloading;

    mutable QMutex m_mutex;
    QHash<QString, QByteArray> m_data;

    int m_pendingCount = 0;
    int m_totalCount   = 0;
};
