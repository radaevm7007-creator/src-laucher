#include "ServerSync.hpp"

#include "AppConfig.hpp"
#include "AppPaths.hpp"
#include "NetworkFallback.hpp"

#include <QDir>
#include <QFileInfo>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QSet>

namespace {

QString storePath() { return AppPaths::root() + QStringLiteral("/servers.json"); }

QJsonObject entryToJson(const ServerEntry& e)
{
    QJsonObject o;
    o.insert(QStringLiteral("name"), e.name);
    o.insert(QStringLiteral("ip"), e.ip);
    if (!e.icon.isEmpty()) o.insert(QStringLiteral("icon"), e.icon);
    if (e.hasAcceptTextures) o.insert(QStringLiteral("acceptTextures"), e.acceptTextures);
    return o;
}

ServerEntry entryFromJson(const QJsonObject& o)
{
    ServerEntry e;
    e.name = o.value(QStringLiteral("name")).toString();
    e.ip   = o.value(QStringLiteral("ip")).toString();
    e.icon = o.value(QStringLiteral("icon")).toString();
    if (o.contains(QStringLiteral("acceptTextures"))) {
        e.acceptTextures = o.value(QStringLiteral("acceptTextures")).toBool();
        e.hasAcceptTextures = true;
    }
    return e;
}



QString ipKey(const QString& ip) { return ip.trimmed().toLower(); }


QString hostOf(const QString& ip)
{
    QString h = ipKey(ip);
    const int colon = h.lastIndexOf(u':');


    if (colon > 0 && h.count(u':') == 1) h = h.left(colon);
    return h;
}




const QStringList& builtinBlocked()
{
    static const QStringList list{
        QStringLiteral("funtime.su"),
        QStringLiteral("holyworld.ru"),
        QStringLiteral("aresmine.ru"),
        QStringLiteral("reallyworld.ru"),
        QStringLiteral("spookytime.net"),
        QStringLiteral("pulsesmp.fun"),
        QStringLiteral("bravohvh.fun"),
        QStringLiteral("bravohvh.su"),
        QStringLiteral("catlavan.net"),
        QStringLiteral("furryhvh.ru"),
        QStringLiteral("infinityhvh.com"),
        QStringLiteral("saturn-x.space"),


    };
    return list;
}




bool isBlankedAdHost(const QString& host)
{
    if (host.size() < 6) return false;
    const QChar c0 = host.at(0);
    if (!c0.isLetter()) return false;
    for (const QChar& c : host)
        if (c != c0) return false;
    return true;
}

}

bool ServerSync::isBlocked(const QString& ip) const
{
    const QString host = hostOf(ip);
    if (host.isEmpty()) return false;


    if (isBlankedAdHost(host)) return true;

    for (const QString& rule : m_blocked) {
        const QString r = ipKey(rule);


        if (host == r || host.endsWith(u'.' + r)) return true;
    }
    return false;
}

ServerSync::ServerSync(QObject* parent) : QObject(parent)
{
    m_blocked = builtinBlocked();
    loadStore();
    refresh();


    m_pollTimer.setInterval(60 * 1000);
    connect(&m_pollTimer, &QTimer::timeout, this, &ServerSync::refresh);
    m_pollTimer.start();
}



void ServerSync::loadStore()
{
    QFile f(storePath());
    if (!f.open(QIODevice::ReadOnly)) return;

    const auto doc = QJsonDocument::fromJson(f.readAll());
    if (!doc.isObject()) return;
    const auto root = doc.object();

    m_userServers.clear();
    for (const auto& v : root.value(QStringLiteral("user")).toArray()) {
        const ServerEntry e = entryFromJson(v.toObject());


        if (isBlocked(e.ip)) continue;
        m_userServers.push_back(e);
    }

    m_lastPromotedIps.clear();
    for (const auto& v : root.value(QStringLiteral("lastPromotedIps")).toArray())
        m_lastPromotedIps << v.toString();

    m_everPromoted.clear();
    const QJsonArray ever = root.value(QStringLiteral("everPromotedIps")).toArray();
    if (!ever.isEmpty()) {
        for (const auto& v : ever) m_everPromoted.insert(ipKey(v.toString()));
    } else {
        // Миграция со старого стора: то, что числилось «последней рекламой»,
        // считаем когда-то рекламной. Этого достаточно на практике.
        for (const QString& ip : m_lastPromotedIps) m_everPromoted.insert(ipKey(ip));
    }


    m_clientBaseline.clear();
    const QJsonObject base = root.value(QStringLiteral("clientBaseline")).toObject();
    for (auto it = base.begin(); it != base.end(); ++it) {
        QSet<QString> ips;
        for (const auto& v : it.value().toArray()) ips.insert(ipKey(v.toString()));
        m_clientBaseline.insert(it.key(), ips);
    }
}

void ServerSync::saveStore() const
{
    QJsonArray user;
    for (const ServerEntry& e : m_userServers) user.append(entryToJson(e));

    QJsonArray ips;
    for (const QString& s : m_lastPromotedIps) ips.append(s);

    QJsonArray everArr;
    for (const QString& s : qAsConst(m_everPromoted)) everArr.append(s);

    QJsonObject baseline;
    for (auto it = m_clientBaseline.begin(); it != m_clientBaseline.end(); ++it) {
        QJsonArray ipsArr;
        for (const QString& ip : it.value()) ipsArr.append(ip);
        baseline.insert(it.key(), ipsArr);
    }

    QJsonObject root;
    root.insert(QStringLiteral("user"), user);
    root.insert(QStringLiteral("lastPromotedIps"), ips);
    root.insert(QStringLiteral("everPromotedIps"), everArr);
    root.insert(QStringLiteral("clientBaseline"), baseline);

    QFile f(storePath());
    if (!f.open(QIODevice::WriteOnly | QIODevice::Truncate)) return;
    f.write(QJsonDocument(root).toJson(QJsonDocument::Indented));
}



void ServerSync::refresh()
{
    NetworkFallback::get(&m_network,
                         NetworkFallback::request(AppConfig::ServerBaseUrl + QStringLiteral("/servers.json")),
                         this,
                         [this](QNetworkReply* r) {
        r->deleteLater();
        if (r->error() != QNetworkReply::NoError) return;

        const auto doc = QJsonDocument::fromJson(r->readAll());
        if (!doc.isObject()) return;



        QStringList blocked = builtinBlocked();
        for (const auto& v : doc.object().value(QStringLiteral("blocked")).toArray()) {
            const QString rule = v.toString().trimmed();
            if (!rule.isEmpty() && !blocked.contains(rule)) blocked << rule;
        }
        if (blocked != m_blocked) {
            m_blocked = blocked;

            const qsizetype before = m_userServers.size();
            m_userServers.erase(std::remove_if(m_userServers.begin(), m_userServers.end(),
                                               [this](const ServerEntry& e) { return isBlocked(e.ip); }),
                                m_userServers.end());
            if (m_userServers.size() != before) saveStore();
        }

        QVector<ServerEntry> next;
        for (const auto& v : doc.object().value(QStringLiteral("servers")).toArray()) {
            ServerEntry e = entryFromJson(v.toObject());
            if (e.ip.trimmed().isEmpty()) continue;
            e.promoted = true;
            e.acceptTextures = true;
            e.hasAcceptTextures = true;
            next.push_back(e);
        }


        const QJsonObject links = doc.object().value(QStringLiteral("links")).toObject();
        const QString dc = links.value(QStringLiteral("discord")).toString().trimmed();
        const QString tg = links.value(QStringLiteral("telegram")).toString().trimmed();
        if (dc != m_discordUrl || tg != m_telegramUrl) {
            m_discordUrl = dc;
            m_telegramUrl = tg;
            emit linksChanged();
        }

        if (next == m_promoted) return;
        for (const ServerEntry& e : next) m_everPromoted.insert(ipKey(e.ip));
        saveStore();
        m_promoted = next;
        emit promotedChanged();
    });
}



bool ServerSync::syncForClient(const QString& clientDir,
                               const QString& gameDirOverride, QString* error)
{
    // Детерминированная модель:
    //   * реклама всегда сверху — из свежего m_promoted;
    //   * пользовательские серверы живут в глобальном списке и потому
    //     переживают перезапуск и переносятся во все клиенты;
    //   * добавленное игроком в клиенте распознаётся как новое (не реклама
    //     сейчас и не была ею раньше, не было отдано нами этим клиентом);
    //   * удалённое игроком распознаётся по пропаже из того набора, который
    //     мы этому клиенту в прошлый раз отдали (baseline).
    const QString gameDir = gameDirOverride.isEmpty()
        ? QDir(clientDir).filePath(QStringLiteral("game"))
        : gameDirOverride;
    QDir().mkpath(gameDir);
    const QString datPath = QDir(gameDir).filePath(QStringLiteral("servers.dat"));

    const QString clientId = QFileInfo(clientDir).fileName();
    const bool firstSync = !m_clientBaseline.contains(clientId);
    QSet<QString> baseline = m_clientBaseline.value(clientId);

    QSet<QString> promotedNow;
    for (const ServerEntry& e : m_promoted) promotedNow.insert(ipKey(e.ip));

    bool storeChanged = false;

    QSet<QString> knownUser;
    for (const ServerEntry& e : m_userServers) knownUser.insert(ipKey(e.ip));

    const QVector<ServerEntry> current = ServerList::read(datPath);

    if (QFileInfo::exists(datPath)) {
        QSet<QString> currentIps;
        for (const ServerEntry& e : current) currentIps.insert(ipKey(e.ip));

        // --- добавленное игроком -------------------------------------------
        for (const ServerEntry& e : current) {
            const QString key = ipKey(e.ip);
            if (key.isEmpty()) continue;
            if (promotedNow.contains(key) || m_everPromoted.contains(key)) continue;
            if (knownUser.contains(key)) continue;
            if (isBlocked(e.ip)) continue;
            if (firstSync || baseline.contains(key)) {
                // Сервер уже был у клиента до первого запуска через лаунчер —
                // считаем его локальным и не трогаем.
                baseline.insert(key);
                storeChanged = true;
                continue;
            }
            m_userServers.push_back(e);
            knownUser.insert(key);
            storeChanged = true;
        }

        // --- удалённое игроком ----------------------------------------------
        if (!firstSync) {
            QVector<ServerEntry> kept;
            kept.reserve(m_userServers.size());
            for (const ServerEntry& e : m_userServers) {
                const QString key = ipKey(e.ip);
                const bool weGaveIt = baseline.contains(key);
                const bool gone = !currentIps.contains(key);
                if (weGaveIt && gone && !promotedNow.contains(key)) {
                    storeChanged = true;      // игрок удалил — убираем глобально
                    continue;
                }
                kept.push_back(e);
            }
            m_userServers = kept;
        }

        if (m_clientBaseline.value(clientId) != baseline) {
            m_clientBaseline.insert(clientId, baseline);
        }
    }

    // --- итоговый список ----------------------------------------------------
    QVector<ServerEntry> result = m_promoted;
    result.reserve(m_promoted.size() + m_userServers.size());
    QStringList resultIps;
    for (const ServerEntry& e : m_promoted) resultIps << ipKey(e.ip);
    for (const ServerEntry& e : m_userServers) {
        if (promotedNow.contains(ipKey(e.ip))) continue;
        if (resultIps.contains(ipKey(e.ip))) continue;
        result.push_back(e);
        resultIps << ipKey(e.ip);
    }

    QStringList nowIps;
    nowIps.reserve(m_promoted.size());
    for (const ServerEntry& e : m_promoted) nowIps << e.ip;
    if (nowIps != m_lastPromotedIps) { m_lastPromotedIps = nowIps; storeChanged = true; }

    m_clientBaseline.insert(clientId, [&]{
        QSet<QString> s;
        for (const QString& ip : resultIps) s.insert(ip);
        return s;
    }());

    if (storeChanged) saveStore();

    return ServerList::write(datPath, result, error);
}
