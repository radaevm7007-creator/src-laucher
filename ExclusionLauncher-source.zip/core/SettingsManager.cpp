#include "SettingsManager.hpp"
#include "AppPaths.hpp"

#include <QDesktopServices>
#include <QDir>
#include <QFile>
#include <QImage>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QProcess>
#include <QRegularExpression>
#include <QUrl>

SettingsManager::SettingsManager(QObject* parent) : QObject(parent)
{
    m_installDir = AppPaths::clientsRoot();
    load();
    QDir().mkpath(m_installDir);
}

void SettingsManager::load()
{
    QFile file(AppPaths::settingsFile());
    if (!file.open(QIODevice::ReadOnly))
        return;

    const auto doc = QJsonDocument::fromJson(file.readAll());
    if (!doc.isObject())
        return;

    const auto obj = doc.object();
    m_nickname = obj.value("nickname").toString(m_nickname);
    m_installDir = obj.value("installDir").toString(m_installDir);
    m_accentColor = obj.value("accentColor").toString(m_accentColor);
    m_snowEnabled = obj.value("snowEnabled").toBool(m_snowEnabled);
    m_autoUpdates = obj.value("autoUpdates").toBool(m_autoUpdates);
    m_clearTemp = obj.value("clearTemp").toBool(m_clearTemp);
    m_parallelDownloads = qBound(1, obj.value("parallelDownloads").toInt(m_parallelDownloads), 4);
    m_language = obj.value("language").toString(m_language);
    m_minimizeToTray = obj.value("minimizeToTray").toBool(m_minimizeToTray);
    m_checkUpdatesOnStart = obj.value("checkUpdatesOnStart").toBool(m_checkUpdatesOnStart);
    m_selectedClientId = obj.value("selectedClientId").toString(m_selectedClientId);
    m_memoryMB = qBound(1024, obj.value("memoryMB").toInt(m_memoryMB), 32768);
    m_fullscreen = obj.value("fullscreen").toBool(m_fullscreen);
    m_hideOnStart = obj.value("hideOnStart").toBool(m_hideOnStart);
    m_verifyIntegrity = obj.value("verifyIntegrity").toBool(m_verifyIntegrity);
    m_discordRichPresence = obj.value("discordRichPresence").toBool(m_discordRichPresence);
    m_disclaimerAccepted = obj.value("disclaimerAccepted").toBool(m_disclaimerAccepted);
    m_favouriteClientIds.clear();
    const auto favArr = obj.value("favouriteClientIds").toArray();
    for (const auto& v : favArr) {
        const auto s = v.toString();
        if (!s.isEmpty()) m_favouriteClientIds.append(s);
    }
    m_runtimePath = obj.value("runtimePath").toString(m_runtimePath);
    m_backgroundFile = obj.value("backgroundFile").toString(m_backgroundFile);
    m_bgBlur = qBound(0, obj.value("bgBlur").toInt(m_bgBlur), 100);
}

void SettingsManager::save() const
{
    QDir().mkpath(AppPaths::root());
    QFile file(AppPaths::settingsFile());
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate))
        return;

    QJsonObject obj{
        {"nickname", m_nickname},
        {"installDir", m_installDir},
        {"accentColor", m_accentColor},
        {"snowEnabled", m_snowEnabled},
        {"autoUpdates", m_autoUpdates},
        {"clearTemp", m_clearTemp},
        {"parallelDownloads", m_parallelDownloads},
        {"language", m_language},
        {"minimizeToTray", m_minimizeToTray},
        {"checkUpdatesOnStart", m_checkUpdatesOnStart},
        {"selectedClientId", m_selectedClientId},
        {"memoryMB", m_memoryMB},
        {"fullscreen", m_fullscreen},
        {"hideOnStart", m_hideOnStart},
        {"verifyIntegrity", m_verifyIntegrity},
        {"discordRichPresence", m_discordRichPresence},
        {"disclaimerAccepted", m_disclaimerAccepted},
        {"favouriteClientIds", QJsonArray::fromStringList(m_favouriteClientIds)},
        {"runtimePath", m_runtimePath},
        {"backgroundFile", m_backgroundFile},
        {"bgBlur", m_bgBlur},
            };
    file.write(QJsonDocument(obj).toJson(QJsonDocument::Indented));
}

QString SettingsManager::sanitizeNickname(const QString& value)
{
    // Раньше вырезалось всё, кроме [A-Za-z0-9_], поэтому КИРИЛЛИЧЕСКИЙ ник
    // превращался в пустую строку и не сохранялся — игрок жаловался, что ник
    // не применяется и клиент стартует с дефолтным (Steve). Разрешаем любые
    // буквы Unicode (в т.ч. кириллицу), цифры и подчёркивание — офлайн-клиентам
    // это подходит.
    QString cleaned = value;
    cleaned.remove(QRegularExpression(QStringLiteral("[^\\p{L}\\p{N}_]"),
                                      QRegularExpression::UseUnicodePropertiesOption));
    return cleaned.left(16);
}

void SettingsManager::setNickname(const QString& value)
{
    const QString cleaned = sanitizeNickname(value);
    if (m_nickname == cleaned) return;
    m_nickname = cleaned;
    save();
    emit nicknameChanged();
}

void SettingsManager::setInstallDir(const QString& value)
{
    if (value.trimmed().isEmpty() || m_installDir == value) return;
    m_installDir = QDir::cleanPath(value);
    QDir().mkpath(m_installDir);
    save();
    emit installDirChanged();
}

void SettingsManager::setAccentColor(const QString& value)
{
    if (m_accentColor == value) return;
    m_accentColor = value;
    save();
    emit accentColorChanged();
}

void SettingsManager::setSnowEnabled(bool value)
{
    if (m_snowEnabled == value) return;
    m_snowEnabled = value;
    save();
    emit snowEnabledChanged();
}

void SettingsManager::setAutoUpdates(bool value)
{
    if (m_autoUpdates == value) return;
    m_autoUpdates = value;
    save();
    emit autoUpdatesChanged();
}

void SettingsManager::setClearTemp(bool value)
{
    if (m_clearTemp == value) return;
    m_clearTemp = value;
    save();
    emit clearTempChanged();
}

void SettingsManager::setParallelDownloads(int value)
{
    value = qBound(1, value, 4);
    if (m_parallelDownloads == value) return;
    m_parallelDownloads = value;
    save();
    emit parallelDownloadsChanged();
}

void SettingsManager::setLanguage(const QString& value)
{
    if (m_language == value) return;
    m_language = value;
    save();
    emit languageChanged();
}

void SettingsManager::setMinimizeToTray(bool value)
{
    if (m_minimizeToTray == value) return;
    m_minimizeToTray = value;
    save();
    emit minimizeToTrayChanged();
}

void SettingsManager::setCheckUpdatesOnStart(bool value)
{
    if (m_checkUpdatesOnStart == value) return;
    m_checkUpdatesOnStart = value;
    save();
    emit checkUpdatesOnStartChanged();
}

void SettingsManager::setSelectedClientId(const QString& value)
{
    if (m_selectedClientId == value) return;
    m_selectedClientId = value;
    save();
    emit selectedClientIdChanged();
}

void SettingsManager::setMemoryMB(int value)
{
    value = qBound(1024, value, 32768);
    if (m_memoryMB == value) return;
    m_memoryMB = value;
    save();
    emit memoryMBChanged();
}

void SettingsManager::setFullscreen(bool value)
{
    if (m_fullscreen == value) return;
    m_fullscreen = value;
    save();
    emit fullscreenChanged();
}

void SettingsManager::setHideOnStart(bool value)
{
    if (m_hideOnStart == value) return;
    m_hideOnStart = value;
    save();
    emit hideOnStartChanged();
}

void SettingsManager::setVerifyIntegrity(bool value)
{
    if (m_verifyIntegrity == value) return;
    m_verifyIntegrity = value;
    save();
    emit verifyIntegrityChanged();
}

void SettingsManager::setDiscordRichPresence(bool value)
{
    if (m_discordRichPresence == value) return;
    m_discordRichPresence = value;
    save();
    emit discordRichPresenceChanged();
}

void SettingsManager::setDisclaimerAccepted(bool value)
{
    if (m_disclaimerAccepted == value) return;
    m_disclaimerAccepted = value;
    save();
    emit disclaimerAcceptedChanged();
}

void SettingsManager::setRuntimePath(const QString& value)
{
    if (m_runtimePath == value) return;
    m_runtimePath = value;
    save();
    emit runtimePathChanged();
}

void SettingsManager::toggleFavourite(const QString& id)
{
    if (id.isEmpty()) return;
    if (m_favouriteClientIds.contains(id))
        m_favouriteClientIds.removeAll(id);
    else
        m_favouriteClientIds.prepend(id);
    save();
    emit favouriteClientIdsChanged();
}

void SettingsManager::resetInstallDir()
{
    setInstallDir(AppPaths::clientsRoot());
}

void SettingsManager::openInstallFolder()
{
    QDir().mkpath(m_installDir);

#ifdef Q_OS_WIN


    const QString native = QDir::toNativeSeparators(QDir(m_installDir).absolutePath());
    if (QProcess::startDetached(QStringLiteral("explorer.exe"), {native}))
        return;
#endif
    QDesktopServices::openUrl(QUrl::fromLocalFile(m_installDir));
}

void SettingsManager::setBackgroundFile(const QString& value)
{
    // Никогда не держим путь к пользовательскому файлу напрямую: обои бывают
    // 8K на 20 МБ — такой текстурный блюр вешает отрисовку (у пользователей
    // выглядело как «бесконечная проверка файлов»). Кладём уменьшенную копию
    // в корень данных и ссылаемся только на неё.
    QString stored;
    if (!value.isEmpty()) {
        // Диалог отдаёт «file:///C:/…» (иногда «/C:/…»), имя может быть
        // проценкодированным и кириллическим — разбираем через QUrl.
        QString path = QUrl(value).isLocalFile()
                           ? QUrl(value).toLocalFile()
                           : value;
        if (path.startsWith(QLatin1Char('/'))) {
            static const QRegularExpression leadingDrive(
                QStringLiteral("^/([A-Za-z]:/)"));
            const auto m = leadingDrive.match(path);
            if (m.hasMatch())
                path = m.captured(1) + path.mid(m.capturedLength());
        }
        QImage img(path);
        if (!img.isNull()) {
            constexpr int kMaxW = 1920;
            constexpr int kMaxH = 1080;
            if (img.width() > kMaxW || img.height() > kMaxH)
                img = img.scaled(kMaxW, kMaxH, Qt::KeepAspectRatio,
                                 Qt::SmoothTransformation);
            const QString dst =
                QDir(AppPaths::root()).filePath(QStringLiteral("background.jpg"));
            if (img.save(dst, "JPG", 88)) {
                stored = dst;
            } else {
                qWarning() << "[settings] не удалось сохранить фон:" << path;
            }
        } else {
            qWarning() << "[settings] не удалось открыть картинку фона:" << path;
        }
    }

    if (m_backgroundFile == stored) return;
    m_backgroundFile = stored;
    save();
    emit backgroundFileChanged();
}

void SettingsManager::setBgBlur(int value)
{
    const int v = qBound(0, value, 100);
    if (m_bgBlur == v) return;
    m_bgBlur = v;
    save();
    emit bgBlurChanged();
}
