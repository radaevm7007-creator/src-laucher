#pragma once

#include <QHash>
#include <QNetworkAccessManager>
#include <QObject>
#include <QSet>
#include <QStringList>
#include <QTimer>
#include <QVector>

#include "ServerList.hpp"















class ServerSync final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(int promotedCount READ promotedCount NOTIFY promotedChanged)


    Q_PROPERTY(QString discordUrl READ discordUrl NOTIFY linksChanged)
    Q_PROPERTY(QString telegramUrl READ telegramUrl NOTIFY linksChanged)

public:
    explicit ServerSync(QObject* parent = nullptr);

    int promotedCount() const { return int(m_promoted.size()); }
    QString discordUrl() const { return m_discordUrl; }
    QString telegramUrl() const { return m_telegramUrl; }


    Q_INVOKABLE void refresh();

    // хосты/IP рекламных серверов — для AdSessionTracker
    QStringList promotedHosts() const {
        QStringList out;
        for (const ServerEntry& e : m_promoted) out << e.ip;
        return out;
    }



    bool syncForClient(const QString& clientDir,
                       const QString& gameDirOverride = QString(),
                       QString* error = nullptr);

signals:
    void promotedChanged();
    void linksChanged();

private:
    void loadStore();
    void saveStore() const;


    bool isBlocked(const QString& ip) const;

    QNetworkAccessManager m_network;
    QTimer m_pollTimer;

    QString m_discordUrl;
    QString m_telegramUrl;
    QVector<ServerEntry> m_promoted;
    QVector<ServerEntry> m_userServers;
    QStringList m_lastPromotedIps;
    QStringList m_blocked;
    // Все IP, которые когда-либо были рекламными: истёкшая реклама не
    // должна «воскресать» как пользовательский сервер.
    QSet<QString> m_everPromoted;

    QHash<QString, QSet<QString>> m_clientBaseline;
};
