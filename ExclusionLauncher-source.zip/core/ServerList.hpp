#pragma once

#include <QByteArray>
#include <QString>
#include <QVector>


struct ServerEntry {
    QString name;
    QString ip;
    QString icon;
    bool acceptTextures = false;
    bool hasAcceptTextures = false;
    bool hidden = false;
    bool hasHidden = false;



    bool promoted = false;



    bool operator==(const ServerEntry& o) const {
        return name == o.name && ip == o.ip && icon == o.icon
            && acceptTextures == o.acceptTextures && hasAcceptTextures == o.hasAcceptTextures
            && hidden == o.hidden && hasHidden == o.hasHidden && promoted == o.promoted;
    }
    bool operator!=(const ServerEntry& o) const { return !(*this == o); }
};











namespace ServerList {


QVector<ServerEntry> read(const QString& path, QString* error = nullptr);
bool write(const QString& path, const QVector<ServerEntry>& servers, QString* error = nullptr);



QVector<ServerEntry> parse(const QByteArray& data, QString* error = nullptr);
QByteArray serialize(const QVector<ServerEntry>& servers);

}
