#pragma once

#include <QElapsedTimer>
#include <QFile>
#include <QFutureWatcher>
#include <QNetworkAccessManager>
#include <QObject>
#include <QPointer>
#include <QQueue>
#include <QVariantMap>

#include "ArchiveManager.hpp"

class QNetworkReply;




class RuntimeManager final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool busy READ busy NOTIFY stateChanged)
    Q_PROPERTY(QString statusText READ statusText NOTIFY stateChanged)
    Q_PROPERTY(QString currentId READ currentId NOTIFY stateChanged)
    Q_PROPERTY(double progress READ progress NOTIFY progressChanged)
    Q_PROPERTY(QString speedText READ speedText NOTIFY progressChanged)
    Q_PROPERTY(QString errorMessage READ errorMessage NOTIFY errorChanged)


    Q_PROPERTY(QVariantList javaRuntimes READ javaRuntimes NOTIFY stateChanged)
    Q_PROPERTY(QVariantList gameRuntimes READ gameRuntimes NOTIFY stateChanged)

public:
    explicit RuntimeManager(QObject* parent = nullptr);

    bool busy() const { return m_busy; }
    QString statusText() const { return m_statusText; }
    QString currentId() const { return m_currentId; }
    double progress() const { return m_progress; }
    QString speedText() const { return m_speedText; }
    QString errorMessage() const { return m_errorMessage; }
    QVariantList javaRuntimes() const;
    QVariantList gameRuntimes() const;

    Q_INVOKABLE bool isInstalled(const QString& id) const;
    Q_INVOKABLE QString javaExeFor(const QString& id) const;



    Q_INVOKABLE QString rootFor(const QString& id) const;
    Q_INVOKABLE QVariantMap runtimeSpec(const QString& id) const;



    Q_INVOKABLE void ensure(const QString& id);



    Q_INVOKABLE bool removeRuntime(const QString& id);


    Q_INVOKABLE void cancelCurrent();

    Q_INVOKABLE void refreshManifest();
    Q_INVOKABLE void clearError();

signals:
    void stateChanged();
    void progressChanged();
    void errorChanged();

    void ensured(const QString& id, const QString& javaExe, const QString& error);
    void manifestChanged();

private:
    void loadFallbackManifest();
    void loadCachedManifest();



    QVariantList listRuntimes(bool wantJava) const;

    void abortReply();
    void startNextInQueue();
    void beginDownload(const QVariantMap& spec);
    void onDownloaded();
    void verifyAndExtract();
    void finishOk(const QString& javaExe);
    void finishFail(const QString& msg);

    void setStatus(const QString& t);
    QString humanSpeed(qint64 bytes, qint64 ms) const;

    QNetworkAccessManager m_network;
    QPointer<QNetworkReply> m_reply;
    class SegmentedDownloader* m_seg = nullptr;
    QFile m_file;
    ArchiveManager m_archive;
    QElapsedTimer m_timer;



    QFutureWatcher<bool> m_hashWatcher;


    QFutureWatcher<QString> m_installWatcher;

    QVariantMap m_runtimes;


    QQueue<QString> m_queue;
    QVariantMap m_currentSpec;
    QString m_currentId;
    QString m_currentArchive;
    QString m_currentStaging;


    bool m_archiveReused = false;

    QString m_statusText;
    QString m_speedText;
    QString m_errorMessage;
    double m_progress = 0.0;
    bool m_busy = false;
};
