#pragma once

#include <QObject>
#include <QNetworkAccessManager>
#include <QTimer>
#include <QVariantMap>
#include <QVariantList>

class InstalledStore;

class ManifestManager final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QVariantList clients READ clients NOTIFY clientsChanged)
    Q_PROPERTY(bool loading READ loading NOTIFY loadingChanged)
    Q_PROPERTY(bool usingFallback READ usingFallback NOTIFY usingFallbackChanged)
    Q_PROPERTY(QString statusText READ statusText NOTIFY statusTextChanged)
    Q_PROPERTY(QString source READ source NOTIFY statusTextChanged)

public:
    explicit ManifestManager(InstalledStore* installed = nullptr, QObject* parent = nullptr);

    QVariantList clients() const { return m_clients; }
    bool loading() const { return m_loading; }
    bool usingFallback() const { return m_usingFallback; }
    QString statusText() const { return m_statusText; }
    QString source() const { return m_source; }

    static QVariantMap ratingFieldsFromResponse(const QByteArray& body);

    Q_INVOKABLE void refresh();
    Q_INVOKABLE void rateClient(const QString& clientId, int stars);

signals:
    void clientsChanged();
    void loadingChanged();
    void usingFallbackChanged();
    void statusTextChanged();

private:
    bool parseManifest(const QByteArray& data, const QUrl& baseUrl);
    void loadCache();
    void loadFromInstalled();
    void setStatus(const QString& text);
    void writeCache(const QByteArray& body);
    void updateClientFields(const QString& clientId, const QVariantMap& fields);

    InstalledStore* m_installed = nullptr;
    QNetworkAccessManager m_network;
    QTimer m_pollTimer;
    QVariantList m_clients;
    bool m_loading = false;
    bool m_usingFallback = true;
    QString m_statusText;
    QString m_source;
};
