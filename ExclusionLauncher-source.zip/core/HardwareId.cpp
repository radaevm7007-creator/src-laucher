#include "HardwareId.hpp"

#include <QCryptographicHash>
#include <QSysInfo>

#ifdef Q_OS_WIN
#include <QSettings>
#include <windows.h>
#endif

namespace {

#ifdef Q_OS_WIN



QString machineGuid()
{
    QSettings reg(QStringLiteral("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Cryptography"),
                  QSettings::Registry64Format);
    return reg.value(QStringLiteral("MachineGuid")).toString();
}



QString systemVolumeSerial()
{
    wchar_t root[MAX_PATH] = {0};
    if (!GetSystemDirectoryW(root, MAX_PATH)) return {};

    root[3] = L'\0';

    DWORD serial = 0;
    if (!GetVolumeInformationW(root, nullptr, 0, &serial, nullptr, nullptr, nullptr, 0))
        return {};
    return QString::number(serial, 16);
}
#endif

}

QString HardwareId::value()
{


    static const QString cached = [] {
        QStringList parts;
#ifdef Q_OS_WIN
        parts << machineGuid() << systemVolumeSerial();
#endif



        parts << QSysInfo::machineHostName() << QSysInfo::currentCpuArchitecture();
        parts.removeAll(QString());



        const QByteArray raw = ("exclusion:" + parts.join(QLatin1Char('|'))).toUtf8();
        return QString::fromLatin1(
            QCryptographicHash::hash(raw, QCryptographicHash::Sha256).toHex());
    }();
    return cached;
}
