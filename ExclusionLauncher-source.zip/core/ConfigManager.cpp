#include "ConfigManager.hpp"

#include "AppConfig.hpp"
#include "AppPaths.hpp"
#include "ConfigInstall.hpp"
#include "HardwareId.hpp"
#include "NetworkFallback.hpp"
#include "SettingsManager.hpp"

#include <QtConcurrent>
#include <QCryptographicHash>
#include <QDateTime>
#include <QRegularExpression>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkReply>
#include <QUrlQuery>
#include <functional>
#include <memory>

namespace {

QVariantList toVariantList(const QJsonArray& array)
{
    QVariantList out;
    out.reserve(array.size());
    for (const auto& value : array)
        out.append(value.toVariant());
    return out;
}

QUrl resolvedUrl(const QString& raw, const QUrl& baseUrl)
{
    if (raw.isEmpty()) return {};
    const QUrl url(raw);
    if (url.isRelative() && !raw.startsWith(QStringLiteral("qrc:/")))
        return baseUrl.resolved(url);
    return url;
}

QString normalizedName(const QVariantMap& map, const QStringList& names, const QString& fallback = {})
{
    for (const QString& name : names) {
        const QString value = map.value(name).toString();
        if (!value.isEmpty()) return value;
    }
    return fallback;
}

int normalizedInt(const QVariantMap& map, const QStringList& names, int fallback = 0)
{
    for (const QString& name : names) {
        const QVariant value = map.value(name);
        if (value.isValid()) return value.toInt();
    }
    return fallback;
}

double normalizedDouble(const QVariantMap& map, const QStringList& names, double fallback = 0.0)
{
    for (const QString& name : names) {
        const QVariant value = map.value(name);
        if (value.isValid()) return value.toDouble();
    }
    return fallback;
}

bool isDriveAbsolutePath(const QString& path)
{
    static const QRegularExpression driveRe(QStringLiteral("^([A-Za-z]):[\\\\/].+$"));
    return driveRe.match(path.trimmed()).hasMatch();
}

QString localizedClientRelativePath(const QString& path, const QString& clientId)
{
    QString normalized = path.trimmed();
    normalized.replace(QLatin1Char('\\'), QLatin1Char('/'));
    const QString lower = normalized.toLower();
    const QString needle = QStringLiteral("exclusionlauncher/data/clients/")
        + clientId.toLower() + QLatin1Char('/');
    const int idx = lower.indexOf(needle);
    if (idx < 0) return {};

    QString tail = normalized.mid(idx + needle.size());
    while (tail.startsWith(QLatin1Char('/'))) tail.remove(0, 1);
    return tail.isEmpty() ? QStringLiteral("game/config") : tail;
}

}

ConfigManager::ConfigManager(SettingsManager* settings, QObject* parent)
    : QObject(parent), m_settings(settings)
{
    loadInstalled();
    loadCache();
    refresh();

    m_pollTimer.setInterval(30 * 1000);
    connect(&m_pollTimer, &QTimer::timeout, this, &ConfigManager::refresh);
    m_pollTimer.start();

    connect(&m_installWatcher, &QFutureWatcher<QString>::finished, this, [this] {
        const QString key = m_activeKey;
        const QString clientId = m_activeClientId;
        const QString configId = m_activeConfigId;
        const QString version = m_activeVersion;
        const QString err = m_installWatcher.result();
        if (!err.isEmpty()) {
            finishDownloadWithError(key, err);
            return;
        }

        QVariantMap entry = installedEntry(key);
        entry[QStringLiteral("clientId")] = clientId;
        entry[QStringLiteral("configId")] = configId;
        entry[QStringLiteral("version")] = version;
        entry[QStringLiteral("installedAt")] = QDateTime::currentDateTimeUtc().toString(Qt::ISODate);
        const QVariantMap existingConfig = findConfig(clientId, configId);
        const int previousRating = qMax(entry.value(QStringLiteral("userRating")).toInt(),
                                        existingConfig.value(QStringLiteral("userRating")).toInt());
        entry[QStringLiteral("userRating")] = previousRating;
        setInstalledEntry(key, entry);
        saveInstalled();
        reportDownload(clientId, configId, version);

        QFile::remove(m_activeArchive);
        QDir(m_activeStagingDir).removeRecursively();
        m_busy = false;
        m_activeKey.clear();
        m_activeClientId.clear();
        m_activeConfigId.clear();
        m_activeVersion.clear();
        m_activeArchive.clear();
        m_activeStagingDir.clear();
        emit busyChanged();
        setStatus(QStringLiteral("Конфиг установлен"));
        clearKeyProgress(key);
        rebuildClients();
    });
}

QString ConfigManager::keyFor(const QString& clientId, const QString& configId) const
{
    return clientId + QStringLiteral("::") + configId;
}

QVariantMap ConfigManager::installedEntry(const QString& key) const
{
    return m_installed.value(key);
}

void ConfigManager::setInstalledEntry(const QString& key, const QVariantMap& value)
{
    m_installed.insert(key, value);
}

void ConfigManager::setStatus(const QString& text)
{
    if (m_statusText == text) return;
    m_statusText = text;
    emit statusTextChanged();
}

void ConfigManager::loadInstalled()
{
    QFile file(AppPaths::root() + QStringLiteral("/configs-installed.json"));
    if (!file.open(QIODevice::ReadOnly)) return;
    const QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    if (!doc.isObject()) return;
    m_installed.clear();
    const QJsonObject root = doc.object();
    for (auto it = root.begin(); it != root.end(); ++it) {
        if (!it.value().isObject()) continue;
        m_installed.insert(it.key(), it.value().toObject().toVariantMap());
    }
}

void ConfigManager::saveInstalled() const
{
    QJsonObject root;
    for (auto it = m_installed.begin(); it != m_installed.end(); ++it)
        root.insert(it.key(), QJsonObject::fromVariantMap(it.value()));
    QFile file(AppPaths::root() + QStringLiteral("/configs-installed.json"));
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate))
        return;
    file.write(QJsonDocument(root).toJson(QJsonDocument::Indented));
}

void ConfigManager::loadCache()
{
    QFile file(AppPaths::root() + QStringLiteral("/configs.json"));
    if (!file.open(QIODevice::ReadOnly)) return;
    if (parseCatalog(file.readAll(), QUrl(AppConfig::ServerBaseUrl + QStringLiteral("/configs/")))) {
        m_usingFallback = true;
        m_source = QStringLiteral("cache");
        emit usingFallbackChanged();
        setStatus(QString());
    }
}

void ConfigManager::writeCache(const QByteArray& body)
{
    QFile file(AppPaths::root() + QStringLiteral("/configs.json"));
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate)) return;
    file.write(body);
}

bool ConfigManager::parseCatalog(const QByteArray& data, const QUrl& baseUrl)
{
    QJsonParseError error;
    const QJsonDocument doc = QJsonDocument::fromJson(data, &error);
    if (error.error != QJsonParseError::NoError || !doc.isObject())
        return false;

    const QJsonObject root = doc.object();
    const QJsonArray array = root.value(QStringLiteral("clients")).toArray();
    QVariantList parsed;

    for (const QJsonValue& clientValue : array) {
        const QVariantMap rawClient = clientValue.toObject().toVariantMap();
        QVariantMap client;
        const QString clientId = normalizedName(rawClient, {QStringLiteral("id")});
        if (clientId.isEmpty()) continue;
        client[QStringLiteral("id")] = clientId;
        client[QStringLiteral("name")] = normalizedName(rawClient, {QStringLiteral("name")}, clientId);
        client[QStringLiteral("minecraft")] = normalizedName(rawClient, {QStringLiteral("minecraft"), QStringLiteral("minecraftVersion"), QStringLiteral("mcVersion")});
        client[QStringLiteral("version")] = normalizedName(rawClient, {QStringLiteral("version"), QStringLiteral("clientVersion")});
        client[QStringLiteral("coverUrl")] = resolvedUrl(normalizedName(rawClient, {QStringLiteral("coverUrl"), QStringLiteral("iconUrl"), QStringLiteral("imageUrl")}), baseUrl).toString();

        QVariantList configs;
        const QJsonArray configsArray = clientValue.toObject().value(QStringLiteral("configs")).toArray();
        for (const QJsonValue& configValue : configsArray) {
            const QVariantMap rawConfig = configValue.toObject().toVariantMap();
            QVariantMap cfg;
            const QString configId = normalizedName(rawConfig, {QStringLiteral("id")});
            if (configId.isEmpty()) continue;

            cfg[QStringLiteral("id")] = configId;
            cfg[QStringLiteral("name")] = normalizedName(rawConfig, {QStringLiteral("name")}, configId);
            cfg[QStringLiteral("version")] = normalizedName(rawConfig, {QStringLiteral("version")});
            cfg[QStringLiteral("description")] = normalizedName(rawConfig, {QStringLiteral("description")});
            cfg[QStringLiteral("sizeText")] = normalizedName(rawConfig, {QStringLiteral("sizeText"), QStringLiteral("size")});
            cfg[QStringLiteral("updatedAt")] = normalizedName(rawConfig, {QStringLiteral("updatedAt"), QStringLiteral("updated"), QStringLiteral("date")});
            cfg[QStringLiteral("downloadUrl")] = resolvedUrl(normalizedName(rawConfig, {QStringLiteral("downloadUrl"), QStringLiteral("packageUrl"), QStringLiteral("url")}), baseUrl).toString();
            cfg[QStringLiteral("coverUrl")] = resolvedUrl(normalizedName(rawConfig, {QStringLiteral("coverUrl"), QStringLiteral("imageUrl"), QStringLiteral("previewUrl")}), baseUrl).toString();
            cfg[QStringLiteral("installPath")] = normalizedName(rawConfig, {QStringLiteral("installPath"), QStringLiteral("path"), QStringLiteral("targetPath"), QStringLiteral("configPath")}, QStringLiteral("game/config"));
            cfg[QStringLiteral("sha256")] = normalizedName(rawConfig, {QStringLiteral("sha256")});
            cfg[QStringLiteral("rating")] = normalizedDouble(rawConfig, {QStringLiteral("rating"), QStringLiteral("averageRating"), QStringLiteral("avgRating")}, 0.0);
            cfg[QStringLiteral("votes")] = normalizedInt(rawConfig, {QStringLiteral("votes"), QStringLiteral("ratingsCount"), QStringLiteral("voteCount")}, 0);
            cfg[QStringLiteral("userRating")] = normalizedInt(rawConfig, {QStringLiteral("userRating"), QStringLiteral("myRating")}, 0);
            cfg[QStringLiteral("downloadedByUser")] = rawConfig.value(QStringLiteral("downloadedByUser"), false).toBool();
            cfg[QStringLiteral("tags")] = toVariantList(configValue.toObject().value(QStringLiteral("tags")).toArray());
            configs.append(cfg);
        }
        client[QStringLiteral("configs")] = configs;
        client[QStringLiteral("configCount")] = configs.size();
        parsed.append(client);
    }

    m_catalog = parsed;
    rebuildClients();
    return true;
}

void ConfigManager::rebuildClients()
{
    QVariantList built;
    for (const QVariant& clientVar : m_catalog) {
        QVariantMap client = clientVar.toMap();
        const QString clientId = client.value(QStringLiteral("id")).toString();
        const QString clientRoot = QDir(m_settings ? m_settings->installDir() : AppPaths::clientsRoot()).filePath(clientId);
        const bool clientInstalled = QFileInfo::exists(clientRoot);
        QVariantList builtConfigs;
        for (const QVariant& cfgVar : client.value(QStringLiteral("configs")).toList()) {
            QVariantMap cfg = cfgVar.toMap();
            const QString configId = cfg.value(QStringLiteral("id")).toString();
            const QString key = keyFor(clientId, configId);
            const QVariantMap local = installedEntry(key);
            // «Установлен» = есть запись И файлы реально лежат на диске: человек
            // мог удалить папку конфига вручную — тогда предлагаем скачать заново,
            // а не врём «установлен».
            const QString instPath = resolveInstallPath(
                clientId, cfg.value(QStringLiteral("installPath")).toString());
            const bool absoluteTarget = isDriveAbsolutePath(cfg.value(QStringLiteral("installPath")).toString());
            const bool canInstall = clientInstalled || absoluteTarget;
            const bool onDisk = !instPath.isEmpty() && QFileInfo::exists(instPath);
            const bool installed = !local.isEmpty() && onDisk;
            const bool downloading = (m_activeKey == key);
            const int localRating = local.value(QStringLiteral("userRating")).toInt();
            const int serverRating = cfg.value(QStringLiteral("userRating")).toInt();
            const int myRating = qMax(localRating, serverRating);
            const bool canRate = installed || cfg.value(QStringLiteral("downloadedByUser"), false).toBool();
            cfg[QStringLiteral("installed")] = installed;
            cfg[QStringLiteral("clientInstalled")] = clientInstalled;
            cfg[QStringLiteral("canInstall")] = canInstall;
            cfg[QStringLiteral("canRate")] = canRate;
            cfg[QStringLiteral("userRating")] = myRating;
            cfg[QStringLiteral("installStatus")] = installed ? QStringLiteral("Установлен") : QStringLiteral("Не установлен");
            cfg[QStringLiteral("localVersion")] = local.value(QStringLiteral("version")).toString();
            cfg[QStringLiteral("actionText")] = !canInstall ? QStringLiteral("Нужен клиент") : installed ? QStringLiteral("Обновить") : QStringLiteral("Скачать");
            cfg[QStringLiteral("downloading")] = downloading;
            cfg[QStringLiteral("progress")] = m_progressByKey.value(key, 0.0);
            cfg[QStringLiteral("stateText")] = m_stateByKey.value(key);
            builtConfigs.append(cfg);
        }
        client[QStringLiteral("configs")] = builtConfigs;
        client[QStringLiteral("configCount")] = builtConfigs.size();
        built.append(client);
    }
    m_clients = built;
    emit clientsChanged();
}

void ConfigManager::refresh()
{
    if (m_loading) return;
    m_loading = true;
    emit loadingChanged();
    setStatus(QStringLiteral("Обновляем каталог конфигов…"));

    QUrl url(AppConfig::ServerBaseUrl + QStringLiteral("/configs.json"));
    QUrlQuery query(url);
    query.addQueryItem(QStringLiteral("hwid"), HardwareId::value());
    url.setQuery(query);

    NetworkFallback::get(&m_network, NetworkFallback::request(url), this, [this](QNetworkReply* reply) {
        m_loading = false;
        emit loadingChanged();
        reply->deleteLater();

        if (reply->error() != QNetworkReply::NoError) {
            setStatus(m_clients.isEmpty()
                          ? QStringLiteral("Каталог конфигов недоступен")
                          : QStringLiteral("Сервер конфигов недоступен — показан кэш"));
            return;
        }

        const QByteArray body = reply->readAll();
        const QUrl base = reply->url().adjusted(QUrl::RemoveFilename);
        if (!parseCatalog(body, base)) {
            setStatus(QStringLiteral("Не удалось разобрать каталог конфигов"));
            return;
        }

        writeCache(body);
        m_usingFallback = false;
        m_source = QStringLiteral("network");
        emit usingFallbackChanged();
        setStatus(QString());
    });
}

QVariantMap ConfigManager::findConfig(const QString& clientId, const QString& configId) const
{
    for (const QVariant& clientVar : m_catalog) {
        const QVariantMap client = clientVar.toMap();
        if (client.value(QStringLiteral("id")).toString() != clientId) continue;
        for (const QVariant& cfgVar : client.value(QStringLiteral("configs")).toList()) {
            const QVariantMap cfg = cfgVar.toMap();
            if (cfg.value(QStringLiteral("id")).toString() == configId)
                return cfg;
        }
    }
    return {};
}

QString ConfigManager::resolveInstallPath(const QString& clientId, const QString& relativePath) const
{
    const QString root = QDir(m_settings ? m_settings->installDir() : AppPaths::clientsRoot()).filePath(clientId);
    QString raw = relativePath.trimmed().isEmpty()
                      ? QStringLiteral("game/config")
                      : relativePath.trimmed();

    const QString localized = localizedClientRelativePath(raw, clientId);
    if (!localized.isEmpty()) raw = localized;

    // Абсолютный путь с буквой диска (C:\Minced\custom, D:/foo …). У другого
    // пользователя система может стоять на другом диске, а клиенты хранят свои
    // папки на СИСТЕМНОМ диске (getenv SystemDrive). Поэтому подменяем указанную
    // админом букву на системный диск пользователя — конфиг ляжет ровно туда,
    // откуда его читает клиент. Это единственный разрешённый абсолютный случай.
    static const QRegularExpression driveRe(QStringLiteral("^([A-Za-z]):[\\\\/](.*)$"));
    const QRegularExpressionMatch dm = driveRe.match(raw);
    if (dm.hasMatch()) {
        QString sysDrive = QString::fromLocal8Bit(qgetenv("SystemDrive")).trimmed(); // "C:"
        if (sysDrive.size() < 2) {
            const QString rp = QDir::rootPath();       // "C:/"
            sysDrive = rp.left(2);
        }
        if (sysDrive.size() < 2) sysDrive = QStringLiteral("C:");
        const QString rest = dm.captured(2);           // "Minced/custom"
        return QDir::cleanPath(sysDrive + QStringLiteral("/") + rest);
    }

    const QString cleanRelative = QDir::cleanPath(raw);
    if (QDir::isAbsolutePath(cleanRelative)) return {};
    if (cleanRelative == QStringLiteral("..") || cleanRelative.startsWith(QStringLiteral("../")))
        return {};
    const QString finalPath = QDir::cleanPath(QDir(root).filePath(cleanRelative));
    // ВАЖНО: QDir::cleanPath нормализует разделители в '/', а QDir::separator()
    // на Windows — '\'. Из-за этого prefix не совпадал с finalPath и даже
    // валидный "game/config" отвергался («некорректный путь установки»).
    // Сравниваем строго по '/'.
    const QString cleanRoot = QDir::cleanPath(root);
    const QString prefix = cleanRoot + QLatin1Char('/');
    if (finalPath != cleanRoot && !finalPath.startsWith(prefix))
        return {};
    return finalPath;
}

void ConfigManager::setKeyProgress(const QString& key, double value, const QString& state)
{
    m_progressByKey.insert(key, value);
    if (!state.isEmpty()) m_stateByKey.insert(key, state);
    rebuildClients();
}

void ConfigManager::clearKeyProgress(const QString& key)
{
    m_progressByKey.remove(key);
    m_stateByKey.remove(key);
}

void ConfigManager::finishDownloadWithError(const QString& key, const QString& message)
{
    if (m_reply) {
        m_reply->abort();
        m_reply->deleteLater();
        m_reply.clear();
    }
    if (!m_activeArchive.isEmpty()) QFile::remove(m_activeArchive);
    if (!m_activeStagingDir.isEmpty()) QDir(m_activeStagingDir).removeRecursively();
    m_busy = false;
    m_activeKey.clear();
    m_activeClientId.clear();
    m_activeConfigId.clear();
    m_activeVersion.clear();
    m_activeArchive.clear();
    m_activeStagingDir.clear();
    emit busyChanged();
    setStatus(message);
    clearKeyProgress(key);
    rebuildClients();
}

void ConfigManager::downloadConfig(const QString& clientId, const QString& configId)
{
    if (m_busy || m_installWatcher.isRunning()) return;
    const QVariantMap cfg = findConfig(clientId, configId);
    if (cfg.isEmpty()) return;
    const QString targetPath = resolveInstallPath(clientId, cfg.value(QStringLiteral("installPath")).toString());
    if (targetPath.isEmpty()) {
        setStatus(QStringLiteral("Сервер прислал некорректный путь установки конфига"));
        return;
    }
    const QString clientRoot = QDir(m_settings ? m_settings->installDir() : AppPaths::clientsRoot()).filePath(clientId);
    if (!QFileInfo::exists(clientRoot)
        && !isDriveAbsolutePath(cfg.value(QStringLiteral("installPath")).toString())) {
        setStatus(QStringLiteral("Сначала скачайте этот клиент"));
        rebuildClients();
        return;
    }

    const QString urlString = cfg.value(QStringLiteral("downloadUrl")).toString();
    const QUrl url(urlString);
    if (!url.isValid() || (url.scheme() != QStringLiteral("https") && url.scheme() != QStringLiteral("http"))) {
        setStatus(QStringLiteral("Некорректная ссылка на конфиг"));
        return;
    }

    m_busy = true;
    emit busyChanged();
    m_activeClientId = clientId;
    m_activeConfigId = configId;
    m_activeKey = keyFor(clientId, configId);
    m_activeVersion = cfg.value(QStringLiteral("version")).toString();

    QString ext = QStringLiteral(".bin");
    const QString urlPath = url.path();
    const QString low = urlPath.toLower();
    if (low.endsWith(QStringLiteral(".tar.xz"))) ext = QStringLiteral(".tar.xz");
    else if (low.endsWith(QStringLiteral(".txz"))) ext = QStringLiteral(".txz");
    else if (low.endsWith(QStringLiteral(".tar.gz"))) ext = QStringLiteral(".tar.gz");
    else if (low.endsWith(QStringLiteral(".tgz"))) ext = QStringLiteral(".tgz");
    else if (low.endsWith(QStringLiteral(".tar"))) ext = QStringLiteral(".tar");
    else if (low.endsWith(QStringLiteral(".zip"))) ext = QStringLiteral(".zip");
    else {
        const QString suffix = QFileInfo(urlPath).suffix();
        if (!suffix.isEmpty()) ext = QLatin1Char('.') + suffix;
    }
    m_activeArchive = QDir(AppPaths::tempRoot()).filePath(QStringLiteral("config-") + clientId + QStringLiteral("-") + configId + ext);
    m_activeStagingDir = QDir(AppPaths::tempRoot()).filePath(QStringLiteral("config-staging-") + clientId + QStringLiteral("-") + configId);
    QFile::remove(m_activeArchive);
    QDir(m_activeStagingDir).removeRecursively();

    setStatus(QStringLiteral("Скачиваем конфиг…"));
    setKeyProgress(m_activeKey, 0.0, QStringLiteral("Скачивание"));

    auto startRequest = std::make_shared<std::function<void(QUrl, bool)>>();
    *startRequest = [this, cfg, clientId, configId, targetPath, startRequest](QUrl requestUrl, bool allowFallback) {
        m_reply = m_network.get(NetworkFallback::request(requestUrl));
        connect(m_reply, &QNetworkReply::downloadProgress, this, [this](qint64 received, qint64 total) {
            if (!m_reply || m_activeKey.isEmpty()) return;
            const double progress = total > 0 ? qBound(0.0, double(received) / double(total), 1.0) : 0.0;
            setKeyProgress(m_activeKey, progress, QStringLiteral("Скачивание"));
        });
        connect(m_reply, &QNetworkReply::finished, this, [this, cfg, clientId, configId, targetPath, requestUrl, allowFallback, startRequest] {
            if (!m_reply) return;
            QNetworkReply* reply = m_reply.data();
            m_reply.clear();
            reply->deleteLater();

            if (reply->error() != QNetworkReply::NoError) {
                const QString fallback = allowFallback ? NetworkFallback::fallbackUrlForPrimary(requestUrl.toString()) : QString();
                if (!fallback.isEmpty()) {
                    QFile::remove(m_activeArchive);
                    setKeyProgress(m_activeKey, 0.0, QStringLiteral("Скачивание"));
                    (*startRequest)(QUrl(fallback), false);
                    return;
                }
                finishDownloadWithError(m_activeKey, QStringLiteral("Не удалось скачать конфиг"));
                return;
            }

            QFile file(m_activeArchive);
            if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
                finishDownloadWithError(m_activeKey, QStringLiteral("Не удалось записать архив конфига"));
                return;
            }
            file.write(reply->readAll());
            file.close();

            setKeyProgress(m_activeKey, 1.0, QStringLiteral("Установка"));
            setStatus(QStringLiteral("Устанавливаем конфиг…"));

            const QString archive = m_activeArchive;
            const QString staging = m_activeStagingDir;
            const QString expectedSha = cfg.value(QStringLiteral("sha256")).toString();
            const QString displayName = cfg.value(QStringLiteral("name")).toString();
            m_installWatcher.setFuture(QtConcurrent::run([archive, staging, targetPath, expectedSha, displayName]() -> QString {
                QString err;
                if (!ConfigInstall::installDownloaded(archive, staging, targetPath, expectedSha, displayName, &err))
                    return err.isEmpty() ? QStringLiteral("Не удалось установить конфиг") : err;
                return QString();
            }));
        });
    };
    (*startRequest)(url, true);
}

void ConfigManager::reportDownload(const QString& clientId, const QString& configId, const QString& version)
{
    QNetworkRequest request = NetworkFallback::request(QUrl(AppConfig::ServerBaseUrl + QStringLiteral("/stats/config-download")));
    request.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/json"));

    QJsonObject body;
    body.insert(QStringLiteral("client_id"), clientId);
    body.insert(QStringLiteral("config_id"), configId);
    body.insert(QStringLiteral("version"), version);
    body.insert(QStringLiteral("launcher_version"), QString::fromLatin1(AppConfig::LauncherVersion));
    body.insert(QStringLiteral("hwid"), HardwareId::value());

    QNetworkReply* reply = m_network.post(request, QJsonDocument(body).toJson(QJsonDocument::Compact));
    connect(reply, &QNetworkReply::finished, this, [reply] { reply->deleteLater(); });
}

void ConfigManager::updateCatalogConfigFields(const QString& clientId, const QString& configId, const QVariantMap& fields)
{
    for (int i = 0; i < m_catalog.size(); ++i) {
        QVariantMap client = m_catalog[i].toMap();
        if (client.value(QStringLiteral("id")).toString() != clientId) continue;
        QVariantList configs = client.value(QStringLiteral("configs")).toList();
        for (int j = 0; j < configs.size(); ++j) {
            QVariantMap cfg = configs[j].toMap();
            if (cfg.value(QStringLiteral("id")).toString() != configId) continue;
            for (auto it = fields.begin(); it != fields.end(); ++it)
                cfg[it.key()] = it.value();
            configs[j] = cfg;
            client[QStringLiteral("configs")] = configs;
            m_catalog[i] = client;
            return;
        }
    }
}

void ConfigManager::applyRatingResponse(const QString& clientId, const QString& configId, const QByteArray& body)
{
    QJsonParseError error;
    const QJsonDocument doc = QJsonDocument::fromJson(body, &error);
    if (error.error != QJsonParseError::NoError || !doc.isObject()) return;
    const QVariantMap map = doc.object().toVariantMap();
    QVariantMap fields;
    if (map.contains(QStringLiteral("rating"))) fields[QStringLiteral("rating")] = map.value(QStringLiteral("rating"));
    if (map.contains(QStringLiteral("averageRating"))) fields[QStringLiteral("rating")] = map.value(QStringLiteral("averageRating"));
    if (map.contains(QStringLiteral("votes"))) fields[QStringLiteral("votes")] = map.value(QStringLiteral("votes"));
    if (map.contains(QStringLiteral("ratingsCount"))) fields[QStringLiteral("votes")] = map.value(QStringLiteral("ratingsCount"));
    if (map.contains(QStringLiteral("userRating"))) fields[QStringLiteral("userRating")] = map.value(QStringLiteral("userRating"));
    if (fields.isEmpty()) return;
    updateCatalogConfigFields(clientId, configId, fields);
}

void ConfigManager::rateConfig(const QString& clientId, const QString& configId, int stars)
{
    stars = qBound(1, stars, 5);
    const QString key = keyFor(clientId, configId);
    QVariantMap local = installedEntry(key);
    const QVariantMap cfg = findConfig(clientId, configId);
    if (local.isEmpty() && !cfg.value(QStringLiteral("downloadedByUser"), false).toBool()) return;
    local[QStringLiteral("clientId")] = clientId;
    local[QStringLiteral("configId")] = configId;
    local[QStringLiteral("userRating")] = stars;
    setInstalledEntry(key, local);
    saveInstalled();
    QVariantMap fields;
    fields[QStringLiteral("userRating")] = stars;
    updateCatalogConfigFields(clientId, configId, fields);
    rebuildClients();

    QNetworkRequest request = NetworkFallback::request(QUrl(AppConfig::ServerBaseUrl + QStringLiteral("/stats/config-rate")));
    request.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/json"));

    QJsonObject body;
    body.insert(QStringLiteral("client_id"), clientId);
    body.insert(QStringLiteral("config_id"), configId);
    body.insert(QStringLiteral("rating"), stars);
    body.insert(QStringLiteral("hwid"), HardwareId::value());
    QNetworkReply* reply = m_network.post(request, QJsonDocument(body).toJson(QJsonDocument::Compact));
    connect(reply, &QNetworkReply::finished, this, [this, reply, clientId, configId] {
        const QByteArray body = reply->readAll();
        if (reply->error() == QNetworkReply::NoError)
            applyRatingResponse(clientId, configId, body);
        reply->deleteLater();
        rebuildClients();
    });
}
