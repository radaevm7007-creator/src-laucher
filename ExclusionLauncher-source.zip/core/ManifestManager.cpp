#include "ManifestManager.hpp"

#include "AppConfig.hpp"
#include "AppPaths.hpp"
#include "HardwareId.hpp"
#include "InstalledStore.hpp"
#include "NetworkFallback.hpp"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonArray>
#include <QSet>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkReply>
#include <QUrl>
#include <QUrlQuery>

ManifestManager::ManifestManager(InstalledStore* installed, QObject* parent)
    : QObject(parent), m_installed(installed)
{






    loadCache();
    if (m_clients.isEmpty()) loadFromInstalled();
    refresh();

    m_pollTimer.setInterval(30 * 1000);
    connect(&m_pollTimer, &QTimer::timeout, this, &ManifestManager::refresh);
    m_pollTimer.start();
}



void ManifestManager::setStatus(const QString& text)
{
    if (m_statusText == text) return;
    m_statusText = text;
    emit statusTextChanged();
}



void ManifestManager::loadCache()
{
    QFile f(AppPaths::root() + QStringLiteral("/manifest.json"));
    if (!f.open(QIODevice::ReadOnly)) return;
    if (parseManifest(f.readAll(), QUrl(AppConfig::ServerBaseUrl + QStringLiteral("/clients/")))) {
        m_usingFallback = true;
        m_source = QStringLiteral("cache");
        emit usingFallbackChanged();
        setStatus(QStringLiteral("Каталог из кэша"));
    }
}

void ManifestManager::writeCache(const QByteArray& body)
{
    QFile f(AppPaths::root() + QStringLiteral("/manifest.json"));
    if (f.open(QIODevice::WriteOnly | QIODevice::Truncate)) { f.write(body); f.close(); }
}

QVariantMap ManifestManager::ratingFieldsFromResponse(const QByteArray& body)
{
    QJsonParseError error;
    const QJsonDocument doc = QJsonDocument::fromJson(body, &error);
    if (error.error != QJsonParseError::NoError || !doc.isObject()) return {};
    const QVariantMap map = doc.object().toVariantMap();
    QVariantMap fields;
    if (map.contains(QStringLiteral("rating"))) fields[QStringLiteral("rating")] = map.value(QStringLiteral("rating"));
    if (map.contains(QStringLiteral("averageRating"))) fields[QStringLiteral("rating")] = map.value(QStringLiteral("averageRating"));
    if (map.contains(QStringLiteral("votes"))) fields[QStringLiteral("votes")] = map.value(QStringLiteral("votes"));
    if (map.contains(QStringLiteral("ratingsCount"))) fields[QStringLiteral("votes")] = map.value(QStringLiteral("ratingsCount"));
    if (map.contains(QStringLiteral("userRating"))) fields[QStringLiteral("userRating")] = map.value(QStringLiteral("userRating"));
    return fields;
}



void ManifestManager::loadFromInstalled()
{
    if (!m_installed) return;


    QVariantList parsed;
    QDir dir(AppPaths::clientsRoot());
    const auto ids = dir.entryList(QDir::Dirs | QDir::NoDotAndDotDot);
    for (const QString& id : ids) {
        if (!m_installed->isInstalled(id)) continue;
        QVariantMap c;
        c["id"] = id;
        c["name"] = id;
        c["version"] = m_installed->installedVersion(id);
        c["minecraft"] = QString();
        c["description"] = QStringLiteral("Локально установленный клиент");
        c["sizeText"] = QString();
        c["accent"] = QStringLiteral("#4CA8FF");
        c["packageUrl"] = QString();
        c["sha256"] = QString();
        c["coverUrl"] = QString();
        c["screenshots"] = QVariantList{};
        c["tags"] = QVariantList{};
        parsed.append(c);
    }
    if (parsed.isEmpty()) {
        m_clients.clear();
        m_source = QStringLiteral("empty");
        emit clientsChanged();
        setStatus(QStringLiteral("Каталог недоступен"));
        return;
    }
    m_clients = parsed;
    m_usingFallback = true;
    m_source = QStringLiteral("installed");
    emit clientsChanged();
    emit usingFallbackChanged();
    setStatus(QStringLiteral("Показаны только установленные клиенты"));
}



bool ManifestManager::parseManifest(const QByteArray& data, const QUrl& baseUrl)
{
    QJsonParseError parseError;
    const auto doc = QJsonDocument::fromJson(data, &parseError);
    if (parseError.error != QJsonParseError::NoError || !doc.isObject())
        return false;

    const QJsonArray array = doc.object().value("clients").toArray();
    QVariantList parsed;

    for (const auto& value : array) {
        const auto obj = value.toObject();
        QVariantMap client;
        client["id"]          = obj.value("id").toString();
        client["name"]        = obj.value("name").toString();
        client["minecraft"]   = obj.value("minecraft").toString();
        client["version"]     = obj.value("version").toString();
        client["description"] = obj.value("description").toString();
        client["sizeText"]    = obj.value("sizeText").toString();
        client["accent"]      = obj.value("accent").toString(QStringLiteral("#4CA8FF"));
        client["coverUrl"]    = obj.value("coverUrl").toString();

        QVariantList screenshots;
        for (const auto& s : obj.value("screenshots").toArray())
            screenshots.append(s.toString());
        client["screenshots"] = screenshots;


        QVariantList tags;
        for (const auto& t : obj.value("tags").toArray())
            tags.append(t.toString());
        client["tags"] = tags;

        QString packageUrl = obj.value("packageUrl").toString();
        if (!packageUrl.isEmpty() && !packageUrl.startsWith(QStringLiteral("qrc:/"))
            && QUrl(packageUrl).isRelative()) {
            packageUrl = baseUrl.resolved(QUrl(packageUrl)).toString();
        }
        client["packageUrl"] = packageUrl;
        client["sha256"]     = obj.value("sha256").toString();
        client["rating"]     = obj.value("rating").toDouble(0.0);
        client["votes"]      = obj.value("votes").toInt(0);
        client["userRating"] = obj.value("userRating").toInt(0);

        if (!client["id"].toString().isEmpty())
            parsed.push_back(client);
    }

    if (m_installed) {
        for (const QVariant& value : parsed) {
            const QVariantMap client = value.toMap();
            const QString id = client.value(QStringLiteral("id")).toString();
            if (id.isEmpty() || m_installed->isInstalled(id)) continue;
            const QString clientDir = QDir(AppPaths::clientsRoot()).filePath(id);
            if (!QFileInfo(clientDir).isDir()) continue;
            m_installed->markInstalled(id, QString(), QString(), QString());
        }
    }

    m_clients = parsed;
    emit clientsChanged();
    return true;
}

void ManifestManager::updateClientFields(const QString& clientId, const QVariantMap& fields)
{
    if (clientId.isEmpty() || fields.isEmpty()) return;
    for (int i = 0; i < m_clients.size(); ++i) {
        QVariantMap client = m_clients[i].toMap();
        if (client.value(QStringLiteral("id")).toString() != clientId) continue;
        for (auto it = fields.begin(); it != fields.end(); ++it)
            client[it.key()] = it.value();
        m_clients[i] = client;
        emit clientsChanged();
        return;
    }
}

void ManifestManager::rateClient(const QString& clientId, int stars)
{
    if (!m_installed || clientId.isEmpty() || !m_installed->isInstalled(clientId)) return;
    stars = qBound(1, stars, 5);

    QVariantMap fields;
    fields[QStringLiteral("userRating")] = stars;
    updateClientFields(clientId, fields);

    QNetworkRequest request = NetworkFallback::request(QUrl(AppConfig::ServerBaseUrl + QStringLiteral("/stats/client-rate")));
    request.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/json"));

    QJsonObject body;
    body.insert(QStringLiteral("client_id"), clientId);
    body.insert(QStringLiteral("rating"), stars);
    body.insert(QStringLiteral("hwid"), HardwareId::value());

    QNetworkReply* reply = m_network.post(request, QJsonDocument(body).toJson(QJsonDocument::Compact));
    connect(reply, &QNetworkReply::finished, this, [this, reply, clientId] {
        const QByteArray response = reply->readAll();
        if (reply->error() == QNetworkReply::NoError)
            updateClientFields(clientId, ratingFieldsFromResponse(response));
        reply->deleteLater();
    });
}



void ManifestManager::refresh()
{
    if (m_loading) return;
    m_loading = true;
    emit loadingChanged();
    setStatus(QStringLiteral("Проверяем каталог на сайте…"));

    QUrl url(AppConfig::RemoteManifestUrl);
    QUrlQuery query(url);
    query.addQueryItem(QStringLiteral("hwid"), HardwareId::value());
    url.setQuery(query);

    NetworkFallback::get(&m_network, NetworkFallback::request(url), this, [this](QNetworkReply* reply) {
        m_loading = false;
        emit loadingChanged();
        reply->deleteLater();

        if (reply->error() != QNetworkReply::NoError) {

            if (m_clients.isEmpty()) loadFromInstalled();
            setStatus(QStringLiteral("Сервер недоступен — показаны только скачанные клиенты"));
            return;
        }

        const QByteArray body = reply->readAll();
        const QUrl base = reply->url().adjusted(QUrl::RemoveFilename);
        if (parseManifest(body, base)) {
            writeCache(body);
            m_usingFallback = false;
            m_source = QStringLiteral("network");
            emit usingFallbackChanged();
            setStatus(QStringLiteral("Каталог обновлён с сервера"));








            if (m_installed) {
                static const QStringList legacyDemos = {
                    QStringLiteral("aurora-vanilla"),
                    QStringLiteral("aurora-performance"),
                    QStringLiteral("aurora-classic"),
                    QStringLiteral("aurora-modded"),
                };
                for (const QString& id : legacyDemos) {
                    if (!m_installed->allIds().contains(id)) continue;
                    QDir(QDir(AppPaths::clientsRoot()).filePath(id)).removeRecursively();
                    m_installed->remove(id);
                }
            }
        } else {
            if (m_clients.isEmpty()) loadFromInstalled();
            setStatus(QStringLiteral("Manifest сервера повреждён"));
        }
    });
}
