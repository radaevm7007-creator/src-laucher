#pragma once

#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QStandardPaths>
#include <QString>

namespace AppPaths {














inline bool isWritableDir(const QString& path)
{
    if (!QDir().mkpath(path)) return false;
    QFile probe(path + QStringLiteral("/.write-test"));
    if (!probe.open(QIODevice::WriteOnly)) return false;
    probe.close();
    probe.remove();
    return true;
}

inline QString root()
{

    static const QString resolved = [] {
        const QString app = QCoreApplication::applicationDirPath();
        QDir parent(app);
        parent.cdUp();
        const QString beside = QDir::cleanPath(parent.filePath(QStringLiteral("data")));
        const QString legacy = app + QStringLiteral("/data");





        if (QFileInfo::exists(legacy) && !QFileInfo::exists(beside)) {
            if (!QDir().rename(legacy, beside) && isWritableDir(legacy))
                return legacy;
        }

        if (isWritableDir(beside)) return beside;


        if (QFileInfo::exists(legacy) && isWritableDir(legacy)) return legacy;
        const QString fallback = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
        QDir().mkpath(fallback);
        return fallback;
    }();
    return resolved;
}

inline QString subdir(const QString& name)
{
    const QString path = root() + QLatin1Char('/') + name;
    QDir().mkpath(path);
    return path;
}

inline QString clientsRoot()  { return subdir(QStringLiteral("clients")); }
inline QString tempRoot()     { return subdir(QStringLiteral("temp")); }
inline QString logsRoot()     { return subdir(QStringLiteral("logs")); }
inline QString runtimesRoot() { return subdir(QStringLiteral("runtimes")); }




inline QString sharedRoot()   { return subdir(QStringLiteral("shared")); }
inline QString sharedSaves()  { return subdir(QStringLiteral("shared/saves")); }
inline QString sharedServersFile() { return sharedRoot() + QStringLiteral("/servers.dat"); }




inline QString mcAssetsRoot() { return subdir(QStringLiteral("mcassets")); }

inline QString settingsFile()  { return root() + QStringLiteral("/settings.json"); }
inline QString installedFile() { return root() + QStringLiteral("/installed.json"); }
inline QString runtimesFile()  { return root() + QStringLiteral("/runtimes.json"); }
inline QString newsCacheFile() { return root() + QStringLiteral("/news.json"); }

inline QString newsSeenFile()  { return root() + QStringLiteral("/news-seen.json"); }

}
