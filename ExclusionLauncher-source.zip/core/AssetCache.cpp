#include "AssetCache.hpp"

#include "AppConfig.hpp"
#include "NetworkFallback.hpp"

#include <QImage>
#include <QLoggingCategory>
#include <QMutexLocker>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QQuickImageProvider>
#include <QSslError>
#include <QSslSocket>
#include <QUrl>

Q_LOGGING_CATEGORY(lcAssets, "exclusion.assets")



namespace {

class AssetsImageProvider : public QQuickImageProvider
{
public:

    explicit AssetsImageProvider(AssetCache* cache)
        : QQuickImageProvider(QQuickImageProvider::Image), m_cache(cache) {}

    QImage requestImage(const QString& id, QSize* outSize, const QSize& requested) override
    {

        QString name = id;
        int q = name.indexOf(QLatin1Char('?'));
        if (q < 0) q = name.indexOf(QStringLiteral("%3F"), 0, Qt::CaseInsensitive);
        if (q >= 0) name.truncate(q);

        const QByteArray bytes = m_cache ? m_cache->dataFor(name) : QByteArray();
        if (bytes.isEmpty()) {
            qWarning() << "[assets] provider: no data for" << name;
            return {};
        }

        QImage img;
        if (!img.loadFromData(bytes)) {
            qWarning() << "[assets] не удалось декодировать" << name << bytes.size() << "байт";
            return {};
        }
        if (outSize) *outSize = img.size();
        if (requested.isValid() && (requested.width() > 0 || requested.height() > 0))
            return img.scaled(requested, Qt::KeepAspectRatio, Qt::SmoothTransformation);
        return img;
    }

private:
    AssetCache* m_cache;
};

}



AssetCache::AssetCache(QObject* parent) : QObject(parent)
{
    const QString base = AppConfig::ServerBaseUrl + QStringLiteral("/assets/");
    m_defs = {
        {"hero_bg.jpg", base + QStringLiteral("hero_bg.jpg")},
        {"app_bg.jpg",  base + QStringLiteral("app_bg.jpg")},
    };
    m_totalCount = m_defs.size();

    refresh();
}

QQuickImageProvider* AssetCache::createImageProvider()
{
    return new AssetsImageProvider(this);
}

bool AssetCache::hasAsset(const QString& name) const
{
    QMutexLocker g(&m_mutex);
    return m_data.contains(name);
}

QByteArray AssetCache::dataFor(const QString& name) const
{
    QMutexLocker g(&m_mutex);
    return m_data.value(name);
}

void AssetCache::refresh()
{
    m_pendingCount = 0;
    for (const auto& a : m_defs) {
        if (m_downloading.contains(a.name)) continue;
        ++m_pendingCount;
        m_downloading.insert(a.name);
        startDownload(a);
    }
    emit readyChanged();
}

void AssetCache::startDownload(const AssetDef& a)
{
    const QString name = a.name;
    NetworkFallback::get(&m_network, NetworkFallback::request(a.url), this, [this, name](QNetworkReply* r) {
        r->deleteLater();
        m_downloading.remove(name);
        if (m_pendingCount > 0) --m_pendingCount;

        if (r->error() == QNetworkReply::NoError) {
            const QByteArray bytes = r->readAll();
            {
                QMutexLocker g(&m_mutex);
                m_data.insert(name, bytes);
            }
            emit assetReady(name);
        } else {
            qWarning() << "[assets] не скачалось" << name << ":" << r->errorString();
        }
        emit readyChanged();
    });
}
