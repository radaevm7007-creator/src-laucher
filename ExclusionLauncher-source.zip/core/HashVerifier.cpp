#include "HashVerifier.hpp"

#include <QCryptographicHash>
#include <QFile>

QString HashVerifier::sha256File(const QString& path, QString* error)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        if (error) *error = QStringLiteral("Не удалось открыть файл для проверки SHA-256.");
        return {};
    }

    QCryptographicHash hash(QCryptographicHash::Sha256);
    if (!hash.addData(&file)) {
        if (error) *error = QStringLiteral("Не удалось вычислить SHA-256.");
        return {};
    }
    return QString::fromLatin1(hash.result().toHex());
}

bool HashVerifier::matchesSha256(const QString& path, const QString& expected, QString* error)
{
    if (expected.trimmed().isEmpty())
        return true;

    const QString actual = sha256File(path, error);
    return !actual.isEmpty() && actual.compare(expected.trimmed(), Qt::CaseInsensitive) == 0;
}
