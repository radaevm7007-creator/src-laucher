#pragma once

#include <QString>

namespace AppConfig {
inline constexpr auto LauncherName    = "Exclusion Launcher";
inline constexpr auto LauncherVersion = "0.2.6";


inline const QString ServerBaseUrl = QStringLiteral("https://pulsardev.tech/launcher");


inline const QString RemoteManifestUrl = ServerBaseUrl + QStringLiteral("/manifest.json");
inline const QString RemoteNewsUrl     = ServerBaseUrl + QStringLiteral("/news.json");
inline const QString RemoteRuntimesUrl = ServerBaseUrl + QStringLiteral("/runtimes.json");



inline const QString RemoteAppUrl      = ServerBaseUrl + QStringLiteral("/app/app.json");
}
