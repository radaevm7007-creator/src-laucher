#pragma once

#include <QFutureWatcher>
#include <QObject>
#include <QString>
#include <QTimer>

#include <atomic>
#include <memory>











class ClientVerifier final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool busy READ busy NOTIFY progressChanged)
    Q_PROPERTY(double progress READ progress NOTIFY progressChanged)

public:
    explicit ClientVerifier(QObject* parent = nullptr);
    ~ClientVerifier() override;

    bool busy() const { return m_busy; }
    double progress() const { return m_progress; }



    static bool writeManifest(const QString& clientDir);



    static bool hasManifest(const QString& clientDir);




    static QString checkClient(const QString& clientDir,
                               std::atomic<int>* counter = nullptr,
                               std::atomic_bool* cancel = nullptr);


    static int countPackageFiles(const QString& clientDir);


    void verify(const QString& clientId, const QString& clientDir);

signals:
    void progressChanged();
    void verified(const QString& clientId, bool ok, const QString& details);

private:
    struct Result {
        bool ok = false;
        QString details;
    };

    QFutureWatcher<Result> m_watcher;
    QString m_clientId;
    bool m_busy = false;
    double m_progress = 0.0;



    std::shared_ptr<std::atomic<int>> m_filesDone;
    int m_filesTotal = 0;
    QTimer m_tick;
};
