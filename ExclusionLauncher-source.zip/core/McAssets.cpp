#include "McAssets.hpp"

#include <QNetworkReply>
#include <QFile>
#include <QDir>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkRequest>
#include <QCryptographicHash>
#include <QSet>

namespace {
const char* kCdn = "https://resources.download.minecraft.net/";
QString objPath(const QString& sharedDir, const QString& hash)
{
    return sharedDir + QStringLiteral("/objects/") + hash.left(2) + QLatin1Char('/') + hash;
}
}

McAssets::McAssets(QObject* parent) : QObject(parent) {}

void McAssets::ensure(const QString& indexPath, const QString& sharedDir)
{
    m_sharedDir = sharedDir;
    m_queue.clear();
    m_next = m_inFlight = m_done = m_total = 0;
    m_running = true;
    m_canceled = m_failed = false;
    m_error.clear();

    QFile idxFile(indexPath);
    if (!idxFile.open(QIODevice::ReadOnly)) {
        m_running = false;
        emit finished(false, QStringLiteral("Не открыть индекс ассетов: ") + indexPath);
        return;
    }
    const QJsonObject root = QJsonDocument::fromJson(idxFile.readAll()).object();
    idxFile.close();
    const QJsonObject objects = root.value(QStringLiteral("objects")).toObject();


    QDir().mkpath(sharedDir + QStringLiteral("/indexes"));
    const QString idxDst = sharedDir + QStringLiteral("/indexes/") + QFileInfo(indexPath).fileName();
    QFile::remove(idxDst);
    QFile::copy(indexPath, idxDst);



    QSet<QString> seen;
    for (auto it = objects.begin(); it != objects.end(); ++it) {
        const QJsonObject o = it.value().toObject();
        const QString hash = o.value(QStringLiteral("hash")).toString();
        const qint64 size = qint64(o.value(QStringLiteral("size")).toDouble());
        if (hash.size() < 2 || seen.contains(hash)) continue;
        seen.insert(hash);
        const QString p = objPath(sharedDir, hash);
        const QFileInfo fi(p);
        if (fi.exists() && fi.size() == size) continue;
        m_queue.push_back({hash, size});
    }
    m_total = m_queue.size();

    if (m_total == 0) {
        m_running = false;
        emit finished(true, QString());
        return;
    }
    emit progress(0, m_total, QStringLiteral("Загрузка ресурсов Minecraft…"));
    pump();
}

void McAssets::cancel()
{
    m_canceled = true;
}

void McAssets::pump()
{
    if (m_canceled) {
        if (m_inFlight == 0 && m_running) {
            m_running = false;
            emit finished(false, QStringLiteral("отменено"));
        }
        return;
    }
    while (m_inFlight < m_concurrency && m_next < m_queue.size() && !m_failed) {
        startJob(m_queue.at(m_next++));
        ++m_inFlight;
    }
    if (m_inFlight == 0) {
        if (!m_running) return;
        m_running = false;
        emit finished(!m_failed, m_error);
    }
}

void McAssets::startJob(const Job& j)
{
    QNetworkRequest req{QUrl(QString::fromLatin1(kCdn) + j.hash.left(2) + QLatin1Char('/') + j.hash)};
    req.setHeader(QNetworkRequest::UserAgentHeader, QStringLiteral("ExclusionLauncher/0.1"));
    req.setAttribute(QNetworkRequest::RedirectPolicyAttribute,
                     QNetworkRequest::NoLessSafeRedirectPolicy);
    QNetworkReply* rep = m_nam.get(req);
    connect(rep, &QNetworkReply::finished, this, [this, rep, j] { onJobFinished(rep, j); });
}

void McAssets::onJobFinished(QNetworkReply* rep, const Job& j)
{
    rep->deleteLater();
    --m_inFlight;

    if (!m_canceled && !m_failed) {
        const QByteArray data = rep->readAll();
        const bool netOk = rep->error() == QNetworkReply::NoError;

        const QString gotHash = QString::fromLatin1(
            QCryptographicHash::hash(data, QCryptographicHash::Sha1).toHex());
        if (!netOk || gotHash != j.hash || data.size() != j.size) {
            m_failed = true;
            m_error = QStringLiteral("Ошибка загрузки ресурса ") + j.hash.left(10) +
                      (netOk ? QStringLiteral(" (хеш/размер)") : (QStringLiteral(": ") + rep->errorString()));
        } else {
            const QString p = objPath(m_sharedDir, j.hash);
            QDir().mkpath(QFileInfo(p).absolutePath());

            const QString tmp = p + QStringLiteral(".part");
            QFile f(tmp);
            if (f.open(QIODevice::WriteOnly | QIODevice::Truncate) &&
                f.write(data) == data.size()) {
                f.close();
                QFile::remove(p);
                if (!QFile::rename(tmp, p)) { QFile::remove(tmp); m_failed = true; m_error = QStringLiteral("Не записать ресурс"); }
            } else {
                f.close(); QFile::remove(tmp);
                m_failed = true; m_error = QStringLiteral("Не записать ресурс на диск");
            }
        }
        if (!m_failed) {
            ++m_done;
            if ((m_done % 32) == 0 || m_done == m_total)
                emit progress(m_done, m_total,
                              QStringLiteral("Загрузка ресурсов Minecraft… %1/%2").arg(m_done).arg(m_total));
        }
    }
    pump();
}
