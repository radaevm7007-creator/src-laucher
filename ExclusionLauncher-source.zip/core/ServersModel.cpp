#include "ServersModel.hpp"

#include <QRandomGenerator>
#include <QVariantMap>

namespace {
constexpr const char* kStatusOnline = "online";
constexpr const char* kStatusMedium = "medium";
constexpr const char* kStatusFull   = "full";
constexpr const char* kStatusOffline = "offline";
}

ServersModel::ServersModel(QObject* parent) : QObject(parent)
{
    seed();

    m_refreshTimer.setInterval(6000);
    m_refreshTimer.setSingleShot(false);
    connect(&m_refreshTimer, &QTimer::timeout, this, [this] {
        randomizeMetrics();
        emit itemsChanged();
    });
    m_refreshTimer.start();
}

QString ServersModel::selectedName() const
{
    if (m_selectedIndex < 0 || m_selectedIndex >= m_items.size())
        return {};
    return m_items.at(m_selectedIndex).toMap().value("name").toString();
}

void ServersModel::refresh()
{
    m_refreshing = true;
    emit statusChanged();
    randomizeMetrics();
    emit itemsChanged();
    m_refreshing = false;
    emit statusChanged();
}

void ServersModel::select(int index)
{
    if (index < 0 || index >= m_items.size() || index == m_selectedIndex)
        return;
    m_selectedIndex = index;
    emit selectedChanged();
}

void ServersModel::seed()
{
    m_items.clear();
    auto add = [this](const QString& name, const QString& status,
                      int online, int capacity, int ping) {
        QVariantMap m;
        m["name"] = name;
        m["status"] = status;
        m["online"] = online;
        m["capacity"] = capacity;
        m["ping"] = ping;
        m_items.append(m);
    };
    add("Exclusion x1",   kStatusOnline,  1250, 3000, 23);
    add("Exclusion x3",   kStatusOnline,  2100, 3000, 35);
    add("Exclusion Fun",  kStatusMedium,   850, 2000, 58);
    add("Exclusion PvP",  kStatusFull,    2000, 2000, 112);
    add("Exclusion Test", kStatusOffline,    0,  500,  -1);
    emit itemsChanged();
}

void ServersModel::randomizeMetrics()
{
    auto* rng = QRandomGenerator::global();
    for (int i = 0; i < m_items.size(); ++i) {
        auto m = m_items.at(i).toMap();
        const QString status = m.value("status").toString();
        if (status == kStatusOffline) {
            m["online"] = 0;
            m["ping"] = -1;
        } else {
            const int cap = m.value("capacity").toInt();
            const int base = m.value("online").toInt();
            const int drift = rng->bounded(-40, 41);
            int next = qBound(0, base + drift, cap);
            if (status == kStatusFull) next = cap;
            m["online"] = next;
            m["ping"] = qBound(15, m.value("ping").toInt() + rng->bounded(-6, 7), 250);
        }
        m_items.replace(i, m);
    }
}
