#pragma once

#include <QFutureWatcher>
#include <QObject>
#include <QString>
#include <QStringList>

#include <atomic>
#include <memory>

class SettingsManager;
class InstalledStore;











class IntegrityChecker final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool busy READ busy NOTIFY stateChanged)
    Q_PROPERTY(double progress READ progress NOTIFY progressChanged)
    Q_PROPERTY(QString statusText READ statusText NOTIFY stateChanged)
    Q_PROPERTY(int badClients READ badClients NOTIFY stateChanged)
    Q_PROPERTY(bool hasResult READ hasResult NOTIFY stateChanged)

public:
    explicit IntegrityChecker(SettingsManager* settings, InstalledStore* installed,
                              QObject* parent = nullptr);
    ~IntegrityChecker() override;

    bool busy() const { return m_busy; }
    double progress() const { return m_progress; }
    QString statusText() const { return m_statusText; }
    int badClients() const { return m_badClients; }
    bool hasResult() const { return m_hasResult; }

    Q_INVOKABLE void start();
    Q_INVOKABLE void cancel();

signals:
    void stateChanged();
    void progressChanged();
    void finished(int badClients, int totalClients);



    void repairRequired(const QStringList& clientIds);

private:
    struct Result {
        int total = 0;
        QStringList bad;
        QStringList reasons;
        bool cancelled = false;
    };

    Result runScan();
    void onScanFinished();

    SettingsManager* m_settings = nullptr;
    InstalledStore* m_installed = nullptr;
    QFutureWatcher<Result> m_watcher;

    QString m_statusText;
    double m_progress = 0.0;
    int m_badClients = 0;
    bool m_busy = false;
    bool m_hasResult = false;


    std::shared_ptr<std::atomic_bool> m_cancelRequested;
    std::shared_ptr<std::atomic<int>> m_filesDone;
};
