#include "ClientVerifier.hpp"

#include <QCryptographicHash>
#include <QDir>
#include <QDirIterator>
#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMutex>
#include <QSet>
#include <QThread>
#include <QThreadPool>
#include <QtConcurrent>

namespace {

const char kManifestName[] = ".exclusion-files.json";




bool skipEntry(const QString& rel)
{
    static const QStringList runtimeDirs{
        QStringLiteral("game"), QStringLiteral("logs"), QStringLiteral("crash-reports")
    };
    if (rel == QLatin1String(kManifestName)) return true;
    for (const QString& d : runtimeDirs)
        if (rel == d || rel.startsWith(d + QLatin1Char('/'))) return true;

    return rel.startsWith(QLatin1String("hs_err_pid")) || rel.startsWith(QLatin1String("replay_pid"));
}

QString sha256Of(const QString& path)
{
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly)) return {};
    QCryptographicHash h(QCryptographicHash::Sha256);


    while (!f.atEnd()) {
        const QByteArray chunk = f.read(1 << 20);
        if (chunk.isEmpty()) break;
        h.addData(chunk);
    }
    return QString::fromLatin1(h.result().toHex());
}

QStringList packageFiles(const QString& clientDir)
{
    QStringList out;
    QDir root(clientDir);
    QDirIterator it(clientDir, QDir::Files, QDirIterator::Subdirectories);
    while (it.hasNext()) {
        it.next();
        const QString rel = root.relativeFilePath(it.filePath());
        if (skipEntry(rel)) continue;
        out << rel;
    }
    out.sort();
    return out;
}

}

ClientVerifier::ClientVerifier(QObject* parent) : QObject(parent)
{
    m_tick.setInterval(120);
    connect(&m_tick, &QTimer::timeout, this, [this] {
        if (!m_filesDone || m_filesTotal <= 0) return;
        const double p = double(m_filesDone->load(std::memory_order_relaxed)) / m_filesTotal;


        const double next = qBound(0.0, p, 0.99);
        if (qFuzzyCompare(next, m_progress)) return;
        m_progress = next;
        emit progressChanged();
    });

    connect(&m_watcher, &QFutureWatcher<Result>::finished, this, [this] {
        const Result r = m_watcher.result();
        m_tick.stop();
        m_busy = false;
        m_progress = 1.0;
        emit progressChanged();
        emit verified(m_clientId, r.ok, r.details);
    });
}

ClientVerifier::~ClientVerifier()
{
    m_watcher.disconnect(this);
    if (m_watcher.isRunning()) m_watcher.waitForFinished();
}

bool ClientVerifier::hasManifest(const QString& clientDir)
{
    return QFileInfo::exists(QDir(clientDir).filePath(QLatin1String(kManifestName)));
}

bool ClientVerifier::writeManifest(const QString& clientDir)
{
    if (!QFileInfo(clientDir).isDir()) return false;

    QJsonObject files;
    QDir root(clientDir);
    for (const QString& rel : packageFiles(clientDir)) {
        const QString abs = root.filePath(rel);
        const QString hash = sha256Of(abs);
        if (hash.isEmpty()) return false;
        QJsonObject entry;
        entry.insert(QStringLiteral("size"), QFileInfo(abs).size());
        entry.insert(QStringLiteral("sha256"), hash);
        files.insert(rel, entry);
    }

    QJsonObject root_;
    root_.insert(QStringLiteral("files"), files);

    QFile f(root.filePath(QLatin1String(kManifestName)));
    if (!f.open(QIODevice::WriteOnly | QIODevice::Truncate)) return false;
    f.write(QJsonDocument(root_).toJson(QJsonDocument::Compact));
    return true;
}

int ClientVerifier::countPackageFiles(const QString& clientDir)
{


    int n = 0;
    for (const QString& rel : packageFiles(clientDir))
        if (rel.endsWith(QLatin1String(".jar"), Qt::CaseInsensitive)) ++n;
    return n;
}

QString ClientVerifier::checkClient(const QString& clientDir,
                                    std::atomic<int>* counter,
                                    std::atomic_bool* cancel)
{
    QFile mf(QDir(clientDir).filePath(QLatin1String(kManifestName)));
    if (!mf.open(QIODevice::ReadOnly))
        return QStringLiteral("манифест не читается");

    const QJsonObject files = QJsonDocument::fromJson(mf.readAll())
                                  .object().value(QStringLiteral("files")).toObject();
    if (files.isEmpty())
        return QStringLiteral("манифест пуст");

    QDir root(clientDir);







    auto isJar = [](const QString& p) {
        return p.endsWith(QLatin1String(".jar"), Qt::CaseInsensitive);
    };


    for (auto it = files.begin(); it != files.end(); ++it) {
        if (!isJar(it.key())) continue;
        const QFileInfo fi(root.filePath(it.key()));
        if (!fi.isFile())
            return QStringLiteral("нет файла: ") + it.key();
        if (fi.size() != it.value().toObject().value(QStringLiteral("size")).toVariant().toLongLong())
            return QStringLiteral("размер не совпал: ") + it.key();
    }









    struct Job { QString rel; QString want; };
    QList<Job> jobs;
    jobs.reserve(files.size());
    for (auto it = files.begin(); it != files.end(); ++it)
        if (isJar(it.key()))
            jobs.append({it.key(), it.value().toObject().value(QStringLiteral("sha256")).toString()});

    QMutex badMutex;
    QString bad;
    std::atomic_bool stop{false};




    QThreadPool pool;
    pool.setMaxThreadCount(qBound(2, QThread::idealThreadCount() / 2, 4));

    QtConcurrent::blockingMap(&pool, jobs, [&](const Job& job) {
        if (stop.load(std::memory_order_relaxed)) return;
        if (cancel && cancel->load()) { stop.store(true); return; }

        const bool same = sha256Of(root.filePath(job.rel)) == job.want;
        if (counter) counter->fetch_add(1, std::memory_order_relaxed);
        if (same) return;


        QMutexLocker lock(&badMutex);
        if (bad.isEmpty()) bad = QStringLiteral("контрольная сумма не совпала: ") + job.rel;
        stop.store(true);
    });

    if (cancel && cancel->load()) return {};
    return bad;
}

void ClientVerifier::verify(const QString& clientId, const QString& clientDir)
{
    if (m_busy) return;
    m_clientId = clientId;
    m_busy = true;
    m_progress = 0.0;
    emit progressChanged();



    m_filesDone = std::make_shared<std::atomic<int>>(0);
    m_filesTotal = countPackageFiles(clientDir);
    m_tick.start();

    auto done = m_filesDone;
    m_watcher.setFuture(QtConcurrent::run([clientDir, done]() -> Result {
        Result res;
        res.details = checkClient(clientDir, done.get());
        res.ok = res.details.isEmpty();
        return res;
    }));
}
