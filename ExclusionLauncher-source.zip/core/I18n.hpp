#pragma once

#include <QHash>
#include <QObject>
#include <QString>

class SettingsManager;





class I18n final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString language READ language NOTIFY languageChanged)

public:
    explicit I18n(SettingsManager* settings, QObject* parent = nullptr);

    QString language() const { return m_language; }

    Q_INVOKABLE QString t(const QString& key) const;

signals:
    void languageChanged();

private:
    void onSettingsLanguageChanged();

    SettingsManager* m_settings = nullptr;
    QString m_language;

    QHash<QString, QHash<QString, QString>> m_dict;
};
