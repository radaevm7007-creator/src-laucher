#include "RuntimeManager.hpp"

#include "SegmentedDownloader.hpp"
#include "AppConfig.hpp"
#include "AppPaths.hpp"
#include "HashVerifier.hpp"
#include "NetworkFallback.hpp"

#include <QDir>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QUrl>
#include <QThread>
#include <QtConcurrent>

#include <algorithm>


namespace {

QVariantMap makeRuntime(const QString& id,
                        const QString& vendor,
                        const QString& version,
                        const QString& url,
                        const QString& sha256,
                        const QString& javaExe = {},
                        const QString& note = {})
{
    QVariantMap spec;
    spec.insert(QStringLiteral("id"), id);
    spec.insert(QStringLiteral("vendor"), vendor);
    spec.insert(QStringLiteral("version"), version);
    spec.insert(QStringLiteral("url"), url);
    spec.insert(QStringLiteral("sha256"), sha256);
    if (!javaExe.isEmpty()) spec.insert(QStringLiteral("javaExe"), javaExe);
    if (!note.isEmpty()) spec.insert(QStringLiteral("_note"), note);
    return spec;
}

QVector<QVariantMap> fallbackRuntimes()
{
    const QString base = AppConfig::ServerBaseUrl + QStringLiteral("/runtimes/");
    return {
        makeRuntime(QStringLiteral("jdk25"), QStringLiteral("Temurin"), QStringLiteral("25.0.4+7"),
                    base + QStringLiteral("jdk25-win-x64.tar.xz"),
                    QStringLiteral("c8a49da4d9733161f344ee8ce550e80afe796f520fa41dd11e759aa043834b70"),
                    QStringLiteral("jdk-25.0.4+7/bin/javaw.exe")),
        makeRuntime(QStringLiteral("java25"), QStringLiteral("Temurin"), QStringLiteral("21.0.3+9"),
                    base + QStringLiteral("jdk21-win-x64.tar.xz"),
                    QStringLiteral("9fa947793fe2dd52fd3c9386906dfd926af1b44bd8a09a9b1dd809f4f8d2d1fa"),
                    QStringLiteral("jdk-21.0.3.9-hotspot/bin/javaw.exe"),
                    QStringLiteral("id java25 сохранён для совместимости; фактически JDK21")),
        makeRuntime(QStringLiteral("java17"), QStringLiteral("Temurin"), QStringLiteral("17.0.1+12"),
                    base + QStringLiteral("java17-win-x64.tar.xz"),
                    QStringLiteral("c65d3126213a6be292ce16b4faca0c0db5ff11721f01a16d1c0afeda4bab9693"),
                    QStringLiteral("java17/bin/javaw.exe")),
        makeRuntime(QStringLiteral("java8"), QStringLiteral("Temurin"), QStringLiteral("1.8.0_472"),
                    base + QStringLiteral("java8-win-x64.tar.xz"),
                    QStringLiteral("422ce32354a51c6cd3181d50daefb037c44b77b6a0eabf5b96e9b133d79fa059"),
                    QStringLiteral("java8/bin/javaw.exe")),
        makeRuntime(QStringLiteral("mc1.16.5"), QStringLiteral("Minecraft/Fabric"), QStringLiteral("1.16.5"),
                    base + QStringLiteral("mc1.16.5.tar.xz"),
                    QStringLiteral("0110c0295314c53b0ce8f596fb83047d67aaa64de0fba2f1fa0924b68defd902")),
        makeRuntime(QStringLiteral("m1.16.5"), QStringLiteral("Minecraft/Fabric"), QStringLiteral("1.16.5"),
                    base + QStringLiteral("mc1.16.5.tar.xz"),
                    QStringLiteral("0110c0295314c53b0ce8f596fb83047d67aaa64de0fba2f1fa0924b68defd902")),
        makeRuntime(QStringLiteral("mc1.20.1"), QStringLiteral("Minecraft/Fabric"), QStringLiteral("1.20.1"),
                    base + QStringLiteral("mc1.20.1.tar.xz"),
                    QStringLiteral("7101c290d0774677a4882bdfad15a41741b087031324201d51e8bed780cc98b3")),
        makeRuntime(QStringLiteral("mc1.21.4"), QStringLiteral("Minecraft/Fabric"), QStringLiteral("1.21.4"),
                    base + QStringLiteral("mc1.21.4.tar.xz"),
                    QStringLiteral("a09a184a5647fa21f88d6cb46e74242821671fff46cc48b9707831965297a517")),
        makeRuntime(QStringLiteral("mc1.21.8"), QStringLiteral("Minecraft/Fabric"), QStringLiteral("1.21.8"),
                    base + QStringLiteral("mc1.21.8.tar.xz"),
                    QStringLiteral("37b3ecfcf78395c5a681432ef29dcb9cb434756085151066ee16380e56e0e7c5")),
        makeRuntime(QStringLiteral("mc1.21.10"), QStringLiteral("Minecraft/Fabric"), QStringLiteral("1.21.10"),
                    base + QStringLiteral("mc1.21.10.tar.xz"),
                    QStringLiteral("17500903c441e2745a9398639fce039c5829994ca6477bb647e2c41a66f79d2b")),
        makeRuntime(QStringLiteral("mc1.21.11"), QStringLiteral("Minecraft/Fabric"), QStringLiteral("1.21.11"),
                    base + QStringLiteral("mc1.21.11.tar.xz"),
                    QStringLiteral("5f22b3f4b97bcf514fb397453347eb8ccb74029a384845ab48fb4ac31a7e4ab6")),
        makeRuntime(QStringLiteral("mc26.2"), QStringLiteral("Minecraft/Fabric"), QStringLiteral("26.2"),
                    base + QStringLiteral("mc26.2.tar.xz"),
                    QStringLiteral("a324b9b9c3aca8ef68771961d16a30c7cb4805df60607cf8435eb140e40f2250")),
        makeRuntime(QStringLiteral("mc262jsvg"), QStringLiteral("Minecraft/Fabric"), QStringLiteral("26.2"),
                    base + QStringLiteral("mc262jsvg.tar.xz"),
                    QStringLiteral("920eb7a248409ebb49304f522fcf49568a587f9acc0b1360feba9ef8d327c89f")),
    };
}

}


RuntimeManager::RuntimeManager(QObject* parent) : QObject(parent)
{

    connect(&m_hashWatcher, &QFutureWatcher<bool>::finished, this, [this] {
        if (!m_busy) return;
        if (!m_hashWatcher.result()) {


            if (m_archiveReused) {
                m_archiveReused = false;
                QFile::remove(m_currentArchive);
                const QString url = m_currentSpec.value(QStringLiteral("url")).toString();
                if (!url.isEmpty()) {
                    m_timer.restart();
                    m_seg->start(url, m_currentArchive, 8);
                    return;
                }
            }
            finishFail(QStringLiteral("SHA-256 архива Java не совпадает."));
            return;
        }
        m_archiveReused = false;
        setStatus(QStringLiteral("Распаковка Java…"));
        QDir().mkpath(m_currentStaging);
        m_archive.extractArchive(m_currentArchive, m_currentStaging);
    });

    connect(&m_archive, &ArchiveManager::finished, this, [this](bool ok, const QString& err) {
        if (!ok) { finishFail(err); return; }




        setStatus(QStringLiteral("Установка рантайма…"));
        const QString finalDir = QDir(AppPaths::runtimesRoot()).filePath(m_currentId);
        const QString staging  = m_currentStaging;
        m_installWatcher.setFuture(QtConcurrent::run([finalDir, staging]() -> QString {
            // Файлы может держать запущенная игра/антивирус — пробуем несколько
            // раз, прежде чем сдаться.
            for (int attempt = 0; attempt < 4; ++attempt) {
                if (attempt > 0)
                    QThread::msleep(500 * attempt);
                QDir(finalDir).removeRecursively();
                if (QFileInfo::exists(finalDir))
                    continue;                       // кто-то держит файлы
                QDir parent(QFileInfo(staging).absolutePath());
                if (parent.rename(QFileInfo(staging).fileName(), finalDir))
                    return QString();
                return QStringLiteral("Не удалось переместить runtime в ")
                       + finalDir
                       + QStringLiteral(" (проверьте свободное место на диске)");
            }
            return QStringLiteral("Не удалось заменить runtime в ")
                   + finalDir
                   + QStringLiteral(": папка занята. Закройте Minecraft и "
                                    "запущенные игры, затем попробуйте снова.");
        }));
    });

    connect(&m_installWatcher, &QFutureWatcher<QString>::finished, this, [this] {
        if (!m_busy) return;
        const QString err = m_installWatcher.result();
        if (!err.isEmpty()) { finishFail(err); return; }

        const QString finalDir = QDir(AppPaths::runtimesRoot()).filePath(m_currentId);
        QFile::remove(m_currentArchive);




        const QString sha = m_currentSpec.value("sha256").toString();
        if (!sha.isEmpty()) {
            QFile shaFile(QDir(finalDir).filePath(QStringLiteral(".sha256")));
            if (shaFile.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
                shaFile.write(sha.toUtf8());
                shaFile.close();
            }
        }



        const QString relJava = m_currentSpec.value("javaExe").toString();
        if (relJava.isEmpty()) {
            if (!QFileInfo::exists(QDir(finalDir).filePath(QStringLiteral("run.spec.json")))) {
                finishFail(QStringLiteral("В рантайме нет run.spec.json: ") + finalDir);
                return;
            }
            finishOk(QString());
            return;
        }

        const QString javaExe = QDir(finalDir).filePath(relJava);
        if (!QFileInfo::exists(javaExe)) {
            finishFail(QStringLiteral("В runtime не найден ") + javaExe);
            return;
        }
        finishOk(javaExe);
    });



    m_seg = new SegmentedDownloader(this);
    connect(m_seg, &SegmentedDownloader::progress, this, [this](qint64 got, qint64 total) {
        m_progress = total > 0 ? double(got) / double(total) : 0.0;
        m_speedText = humanSpeed(got, m_timer.elapsed());
        emit progressChanged();
    });
    connect(m_seg, &SegmentedDownloader::finished, this, [this](bool ok, const QString& err) {
        if (!ok) { finishFail(QStringLiteral("Скачивание не удалось: ") + err); return; }
        m_progress = 1.0;
        emit progressChanged();
        verifyAndExtract();
    });

    loadCachedManifest();
    loadFallbackManifest();





    refreshManifest();
}

void RuntimeManager::loadCachedManifest()
{
    QFile f(AppPaths::runtimesFile());
    if (!f.open(QIODevice::ReadOnly)) return;
    const auto doc = QJsonDocument::fromJson(f.readAll());
    if (!doc.isObject()) return;
    const auto arr = doc.object().value("runtimes").toArray();
    for (const auto& v : arr) {
        const auto o = v.toObject();
        const auto id = o.value("id").toString();
        if (id.isEmpty()) continue;
        m_runtimes.insert(id, o.toVariantMap());
    }
    emit manifestChanged();
    emit stateChanged();
}

void RuntimeManager::loadFallbackManifest()
{
    for (const QVariantMap& spec : fallbackRuntimes()) {
        const QString id = spec.value(QStringLiteral("id")).toString();
        if (!id.isEmpty())
            m_runtimes.insert(id, spec);
    }
    emit manifestChanged();
    emit stateChanged();
}



bool RuntimeManager::isInstalled(const QString& id) const
{
    const QVariantMap spec = m_runtimes.value(id).toMap();
    if (spec.isEmpty()) return false;



    const QString rel = spec.value("javaExe").toString();
    if (rel.isEmpty())
        return !rootFor(id).isEmpty();

    return QFileInfo::exists(QDir(AppPaths::runtimesRoot()).filePath(id + QStringLiteral("/") + rel));
}

QString RuntimeManager::javaExeFor(const QString& id) const
{
    const QVariantMap spec = m_runtimes.value(id).toMap();
    const QString rel = spec.value("javaExe").toString();
    if (rel.isEmpty()) return {};
    const QString full = QDir(AppPaths::runtimesRoot()).filePath(id + QStringLiteral("/") + rel);
    return QFileInfo::exists(full) ? full : QString();
}

QString RuntimeManager::rootFor(const QString& id) const
{
    const QString dir = QDir(AppPaths::runtimesRoot()).filePath(id);


    if (!QFileInfo::exists(QDir(dir).filePath(QStringLiteral("run.spec.json"))))
        return {};
    return dir;
}

QVariantMap RuntimeManager::runtimeSpec(const QString& id) const
{
    return m_runtimes.value(id).toMap();
}

QVariantList RuntimeManager::listRuntimes(bool wantJava) const
{
    QVariantList out;
    for (auto it = m_runtimes.begin(); it != m_runtimes.end(); ++it) {
        const QVariantMap spec = it.value().toMap();


        const bool isJava = !spec.value(QStringLiteral("javaExe")).toString().isEmpty();
        if (isJava != wantJava) continue;

        QVariantMap row;
        row.insert(QStringLiteral("id"), it.key());
        row.insert(QStringLiteral("vendor"), spec.value(QStringLiteral("vendor")));
        row.insert(QStringLiteral("version"), spec.value(QStringLiteral("version")));
        row.insert(QStringLiteral("installed"), isInstalled(it.key()));
        row.insert(QStringLiteral("downloading"), m_busy && m_currentId == it.key());
        out.append(row);
    }



    std::sort(out.begin(), out.end(), [](const QVariant& a, const QVariant& b) {
        return a.toMap().value(QStringLiteral("id")).toString()
             < b.toMap().value(QStringLiteral("id")).toString();
    });
    return out;
}

QVariantList RuntimeManager::javaRuntimes() const
{
    return listRuntimes(true);
}

QVariantList RuntimeManager::gameRuntimes() const
{


    return listRuntimes(false);
}

bool RuntimeManager::removeRuntime(const QString& id)
{
    if (id.isEmpty()) return false;


    if (m_busy && m_currentId == id) return false;

    const QString dir = QDir(AppPaths::runtimesRoot()).filePath(id);
    if (!QFileInfo::exists(dir)) return false;

    const bool ok = QDir(dir).removeRecursively();
    if (!ok) qWarning() << "[runtime] не удалось удалить" << dir;
    emit stateChanged();
    return ok;
}

void RuntimeManager::ensure(const QString& id)
{
    if (id.isEmpty()) return;



    if (isInstalled(id)) {
        const QString want = m_runtimes.value(id).toMap().value("sha256").toString();
        QString have;
        QFile shaFile(QDir(AppPaths::runtimesRoot()).filePath(id + QStringLiteral("/.sha256")));
        if (shaFile.open(QIODevice::ReadOnly)) {
            have = QString::fromUtf8(shaFile.readAll()).trimmed();
            shaFile.close();
        }
        if (want.isEmpty() || want.compare(have, Qt::CaseInsensitive) == 0) {
            emit ensured(id, javaExeFor(id), QString());
            return;
        }
        qInfo() << "[runtime]" << id << "устарел (sha сервера изменился) — перекачиваем";
    }

    if (!m_runtimes.contains(id)) {
        loadFallbackManifest();
    }

    if (!m_runtimes.contains(id)) {
        refreshManifest();
        emit ensured(id, QString(),
                     QStringLiteral("В manifest'е runtimes нет id: ") + id);
        return;
    }

    qInfo() << "[runtime] нужен" << id << "— ставим в очередь";
    m_queue.enqueue(id);
    if (!m_busy) startNextInQueue();
}

void RuntimeManager::startNextInQueue()
{
    if (m_queue.isEmpty()) return;
    m_currentId = m_queue.dequeue();
    m_currentSpec = m_runtimes.value(m_currentId).toMap();
    beginDownload(m_currentSpec);
}



void RuntimeManager::beginDownload(const QVariantMap& spec)
{
    const QString url = spec.value("url").toString();
    if (url.isEmpty()) { finishFail(QStringLiteral("В runtime нет url")); return; }

    m_busy = true;
    m_progress = 0.0;
    m_speedText.clear();


    const bool isJava = !spec.value("javaExe").toString().isEmpty();
    setStatus((isJava ? QStringLiteral("Скачивание Java (")
                      : QStringLiteral("Скачивание Minecraft ("))
              + m_currentId + QStringLiteral(")…"));


    QString ext = QStringLiteral(".tar.xz");
    const QString low = url.toLower();
    if (low.endsWith(QStringLiteral(".zip"))) ext = QStringLiteral(".zip");
    else if (low.endsWith(QStringLiteral(".tar.gz")) || low.endsWith(QStringLiteral(".tgz"))) ext = QStringLiteral(".tar.gz");
    else if (low.endsWith(QStringLiteral(".tar"))) ext = QStringLiteral(".tar");

    m_currentArchive = QDir(AppPaths::tempRoot()).filePath(QStringLiteral("runtime-") + m_currentId + ext);
    m_currentStaging = QDir(AppPaths::tempRoot()).filePath(QStringLiteral("runtime-staging-") + m_currentId);

    QDir(m_currentStaging).removeRecursively();
    m_archiveReused = false;

    if (m_file.isOpen()) m_file.close();




    if (QFileInfo(m_currentArchive).size() > 0) {
        m_archiveReused = true;
        setStatus(QStringLiteral("Проверка ранее скачанного архива…"));
        verifyAndExtract();
        return;
    }



    m_timer.restart();
    m_seg->start(url, m_currentArchive, 8);
}

void RuntimeManager::onDownloaded()
{
    if (m_file.isOpen()) {
        if (m_reply) m_file.write(m_reply->readAll());
        m_file.close();
    }
    if (!m_reply || m_reply->error() != QNetworkReply::NoError) {
        const QString err = m_reply ? m_reply->errorString() : QStringLiteral("отмена");
        if (m_reply) m_reply->deleteLater();
        m_reply.clear();
        finishFail(QStringLiteral("Скачивание Java не удалось: ") + err);
        return;
    }
    m_reply->deleteLater();
    m_reply.clear();
    m_progress = 1.0;
    emit progressChanged();
    verifyAndExtract();
}

void RuntimeManager::verifyAndExtract()
{
    setStatus(QStringLiteral("Проверка Java-архива…"));


    const QString archive  = m_currentArchive;
    const QString expected = m_currentSpec.value("sha256").toString();
    m_hashWatcher.setFuture(QtConcurrent::run([archive, expected]() -> bool {
        return HashVerifier::matchesSha256(archive, expected);
    }));
}



void RuntimeManager::finishOk(const QString& javaExe)
{
    qInfo() << "[runtime]" << m_currentId << "установлен";
    setStatus(QStringLiteral("Рантайм готов"));
    m_busy = false;
    m_progress = 1.0;
    emit progressChanged();
    emit stateChanged();
    emit ensured(m_currentId, javaExe, QString());
    if (!m_queue.isEmpty()) startNextInQueue();
}

void RuntimeManager::abortReply()
{
    if (m_seg) m_seg->cancel();
    if (QNetworkReply* reply = m_reply.data()) {



        m_reply.clear();
        reply->disconnect(this);
        reply->abort();
        reply->deleteLater();
    }
}

void RuntimeManager::cancelCurrent()
{
    if (!m_busy) return;

    m_queue.clear();
    finishFail(QStringLiteral("отменено"));
}

void RuntimeManager::finishFail(const QString& msg)
{
    abortReply();
    if (m_file.isOpen()) m_file.close();



    QDir(m_currentStaging).removeRecursively();
    m_archiveReused = false;

    qWarning() << "[runtime]" << m_currentId << "не установлен:" << msg;
    m_busy = false;
    m_statusText = QStringLiteral("Ошибка");
    m_errorMessage = msg;
    const QString id = m_currentId;
    m_currentId.clear();
    emit stateChanged();
    emit errorChanged();
    emit ensured(id, QString(), msg);
    if (!m_queue.isEmpty()) startNextInQueue();
}

void RuntimeManager::setStatus(const QString& t)
{
    m_statusText = t;
    emit stateChanged();
}

QString RuntimeManager::humanSpeed(qint64 bytes, qint64 ms) const
{
    if (ms <= 0) return QStringLiteral("0 MB/s");
    const double seconds = ms / 1000.0;
    const double mbps = (bytes / 1024.0 / 1024.0) / seconds;
    return QString::number(mbps, 'f', mbps < 10.0 ? 1 : 0) + QStringLiteral(" MB/s");
}

void RuntimeManager::clearError()
{
    if (m_errorMessage.isEmpty()) return;
    m_errorMessage.clear();
    emit errorChanged();
}



void RuntimeManager::refreshManifest()
{
    NetworkFallback::get(&m_network, NetworkFallback::request(AppConfig::RemoteRuntimesUrl), this, [this](QNetworkReply* r) {
        r->deleteLater();
        if (r->error() != QNetworkReply::NoError) return;
        const QByteArray body = r->readAll();
        const auto doc = QJsonDocument::fromJson(body);
        if (!doc.isObject()) return;


        QFile f(AppPaths::runtimesFile());
        if (f.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
            f.write(body);
            f.close();
        }

        m_runtimes.clear();
        for (const auto& v : doc.object().value("runtimes").toArray()) {
            const auto o = v.toObject();
            const auto id = o.value("id").toString();
            if (id.isEmpty()) continue;
            m_runtimes.insert(id, o.toVariantMap());
        }
        emit manifestChanged();
        emit stateChanged();
    emit stateChanged();
    });
}
