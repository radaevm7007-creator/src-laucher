#include "JavaLaunch.hpp"

#include <QtGlobal>

namespace {

bool isSplitHeapFlag(const QString& arg)
{
    const QString s = arg.trimmed();
    return s.compare(QStringLiteral("-Xmx"), Qt::CaseInsensitive) == 0 ||
           s.compare(QStringLiteral("-Xms"), Qt::CaseInsensitive) == 0 ||
           s.compare(QStringLiteral("-XX:MaxHeapSize"), Qt::CaseInsensitive) == 0 ||
           s.compare(QStringLiteral("-XX:InitialHeapSize"), Qt::CaseInsensitive) == 0;
}

bool isInlineHeapFlag(const QString& arg)
{
    const QString s = arg.trimmed();
    return s.startsWith(QStringLiteral("-Xmx"), Qt::CaseInsensitive) ||
           s.startsWith(QStringLiteral("-Xms"), Qt::CaseInsensitive) ||
           s.startsWith(QStringLiteral("-XX:MaxHeapSize="), Qt::CaseInsensitive) ||
           s.startsWith(QStringLiteral("-XX:InitialHeapSize="), Qt::CaseInsensitive);
}

}

namespace JavaLaunch {

QStringList sanitizeJvmHeapArgs(const QStringList& args)
{
    QStringList cleaned;
    cleaned.reserve(args.size());

    bool skipNext = false;
    for (const QString& arg : args) {
        if (skipNext) {
            skipNext = false;
            continue;
        }
        if (isSplitHeapFlag(arg)) {
            skipNext = true;
            continue;
        }
        if (isInlineHeapFlag(arg))
            continue;
        cleaned << arg;
    }

    return cleaned;
}

void applyMemoryArgs(QStringList& args, int memoryMb)
{
    args = sanitizeJvmHeapArgs(args);

    const int maxMb = qBound(1024, memoryMb, 32768);
    const int initialMb = qMin(maxMb, qBound(256, maxMb / 4, 1024));

    args.prepend(QStringLiteral("-Xmx") + QString::number(maxMb) + QStringLiteral("M"));
    args.prepend(QStringLiteral("-Xms") + QString::number(initialMb) + QStringLiteral("M"));
}

QProcessEnvironment cleanProcessEnvironment(QStringList* removedVars)
{
    QProcessEnvironment env = QProcessEnvironment::systemEnvironment();
    const QStringList unsafeVars = {
        QStringLiteral("_JAVA_OPTIONS"),
        QStringLiteral("JAVA_TOOL_OPTIONS"),
        QStringLiteral("JDK_JAVA_OPTIONS"),
    };

    if (removedVars)
        removedVars->clear();

    for (const QString& var : unsafeVars) {
        if (!env.contains(var))
            continue;
        env.remove(var);
        if (removedVars)
            *removedVars << var;
    }

    return env;
}

}
