#pragma once

#include <QObject>
#include <QFile>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QVector>
#include <QElapsedTimer>
#include <QPointer>
#include <QString>





class SegmentedDownloader : public QObject
{
    Q_OBJECT
public:
    explicit SegmentedDownloader(QObject* parent = nullptr);

    static int retryDelayMsForAttempt(int attempt);
    static QString fallbackUrlForPrimary(const QString& url);

    void start(const QString& url, const QString& destPath, int segments = 4);
    void cancel();

signals:
    void progress(qint64 received, qint64 total);
    void finished(bool ok, const QString& error);

private:
    struct Seg {
        qint64 start = 0;
        qint64 end = 0;
        qint64 written = 0;
        int retries = 0;
        QPointer<QNetworkReply> reply;
        QFile file;
    };

    void beginProbe();
    void beginSegments(qint64 total);
    void startSegment(int i);
    void onSegReadyRead(int i);
    void onSegFinished(int i);
    // Освободившийся сегмент забирает половину остатка у самого медленного —
    // иначе быстрые сегменты финишируют, а один медленный (хостер режет
    // скорость per-connection) тянет хвост в одиночку и средняя скорость падает
    // с 20 МБ/с до 1. Work-stealing держит все соединения занятыми до конца.
    bool tryStealWork(int freeIdx);
    void fallbackSingle();
    void onSingleReadyRead();
    void onSingleFinished();
    void emitProgress();
    void fail(const QString& err);
    void succeed();
    void cleanup();

    QNetworkAccessManager m_nam;
    QString m_url;
    QString m_dest;
    int m_segments = 4;
    qint64 m_total = -1;
    QVector<Seg*> m_segs;
    int m_doneSegs = 0;
    qint64 m_completedBytes = 0;   // байты полностью докачанных диапазонов
    bool m_canceled = false;
    bool m_finished = false;
    bool m_usedFallbackUrl = false;


    bool m_single = false;
    QFile m_singleFile;
    QPointer<QNetworkReply> m_singleReply;
    qint64 m_singleGot = 0;

    QElapsedTimer m_timer;
    static constexpr int kMaxRetries = 6;
};
