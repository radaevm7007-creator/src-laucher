#pragma once

#include <QProcessEnvironment>
#include <QStringList>

namespace JavaLaunch {

QStringList sanitizeJvmHeapArgs(const QStringList& args);
void applyMemoryArgs(QStringList& args, int memoryMb);
QProcessEnvironment cleanProcessEnvironment(QStringList* removedVars = nullptr);

}
