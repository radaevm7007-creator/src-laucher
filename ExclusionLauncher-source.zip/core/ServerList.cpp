#include "ServerList.hpp"

#include <QFile>
#include <QtEndian>

namespace {



enum Tag : quint8 {
    TagEnd = 0, TagByte = 1, TagShort = 2, TagInt = 3, TagLong = 4,
    TagFloat = 5, TagDouble = 6, TagByteArray = 7, TagString = 8,
    TagList = 9, TagCompound = 10, TagIntArray = 11, TagLongArray = 12
};




class Reader {
public:
    explicit Reader(const QByteArray& d) : m_d(d) {}

    bool ok() const { return m_ok; }
    int  pos() const { return m_pos; }

    quint8 u8() {
        if (!want(1)) return 0;
        return quint8(m_d.at(m_pos++));
    }
    qint16 i16() {
        if (!want(2)) return 0;
        const auto v = qFromBigEndian<qint16>(m_d.constData() + m_pos);
        m_pos += 2; return v;
    }
    qint32 i32() {
        if (!want(4)) return 0;
        const auto v = qFromBigEndian<qint32>(m_d.constData() + m_pos);
        m_pos += 4; return v;
    }
    qint64 i64() {
        if (!want(8)) return 0;
        const auto v = qFromBigEndian<qint64>(m_d.constData() + m_pos);
        m_pos += 8; return v;
    }
    QString str() {
        const quint16 len = quint16(i16());
        if (!want(len)) return {};
        const QString s = QString::fromUtf8(m_d.constData() + m_pos, len);
        m_pos += len; return s;
    }
    void skip(int n) { if (want(n)) m_pos += n; }

private:
    bool want(int n) {
        if (!m_ok) return false;
        if (n < 0 || m_pos + n > m_d.size()) { m_ok = false; return false; }
        return true;
    }
    const QByteArray& m_d;
    int m_pos = 0;
    bool m_ok = true;
};

class Writer {
public:
    QByteArray take() { return m_d; }

    void u8(quint8 v)  { m_d.append(char(v)); }
    void i16(qint16 v) { char b[2]; qToBigEndian(v, b); m_d.append(b, 2); }
    void i32(qint32 v) { char b[4]; qToBigEndian(v, b); m_d.append(b, 4); }
    void str(const QString& s) {
        const QByteArray u = s.toUtf8();
        i16(qint16(u.size()));
        m_d.append(u);
    }

    void tag(Tag t, const QString& name) { u8(t); str(name); }

private:
    QByteArray m_d;
};


void skipValue(Reader& r, quint8 type);

void skipCompound(Reader& r)
{
    while (r.ok()) {
        const quint8 t = r.u8();
        if (t == TagEnd) return;
        r.str();
        skipValue(r, t);
    }
}

void skipValue(Reader& r, quint8 type)
{
    switch (type) {
    case TagByte:   r.skip(1); break;
    case TagShort:  r.skip(2); break;
    case TagInt:    r.skip(4); break;
    case TagLong:   r.skip(8); break;
    case TagFloat:  r.skip(4); break;
    case TagDouble: r.skip(8); break;
    case TagByteArray: { const qint32 n = r.i32(); r.skip(n); break; }
    case TagString: r.str(); break;
    case TagIntArray:  { const qint32 n = r.i32(); r.skip(n * 4); break; }
    case TagLongArray: { const qint32 n = r.i32(); r.skip(n * 8); break; }
    case TagList: {
        const quint8 inner = r.u8();
        const qint32 n = r.i32();
        for (qint32 i = 0; i < n && r.ok(); ++i) {
            if (inner == TagCompound) skipCompound(r);
            else skipValue(r, inner);
        }
        break;
    }
    case TagCompound: skipCompound(r); break;
    default: break;
    }
}


ServerEntry readServer(Reader& r)
{
    ServerEntry e;
    while (r.ok()) {
        const quint8 t = r.u8();
        if (t == TagEnd) break;
        const QString key = r.str();

        if (t == TagString && key == QLatin1String("name"))       e.name = r.str();
        else if (t == TagString && key == QLatin1String("ip"))    e.ip   = r.str();
        else if (t == TagString && key == QLatin1String("icon"))  e.icon = r.str();
        else if (t == TagByte && key == QLatin1String("acceptTextures")) {
            e.acceptTextures = r.u8() != 0; e.hasAcceptTextures = true;
        }
        else if (t == TagByte && key == QLatin1String("hidden")) {
            e.hidden = r.u8() != 0; e.hasHidden = true;
        }
        else skipValue(r, t);
    }
    return e;
}

}



QVector<ServerEntry> ServerList::parse(const QByteArray& data, QString* error)
{
    QVector<ServerEntry> out;
    if (data.isEmpty()) return out;

    Reader r(data);

    if (r.u8() != TagCompound) {
        if (error) *error = QStringLiteral("servers.dat: корень не TAG_Compound");
        return out;
    }
    r.str();

    while (r.ok()) {
        const quint8 t = r.u8();
        if (t == TagEnd) break;
        const QString key = r.str();

        if (t == TagList && key == QLatin1String("servers")) {
            const quint8 inner = r.u8();
            const qint32 n = r.i32();

            if (inner != TagCompound) { for (qint32 i = 0; i < n && r.ok(); ++i) skipValue(r, inner); continue; }
            out.reserve(int(n));
            for (qint32 i = 0; i < n && r.ok(); ++i)
                out.push_back(readServer(r));
        } else {
            skipValue(r, t);
        }
    }

    if (!r.ok() && error) *error = QStringLiteral("servers.dat: файл обрывается на позиции ")
                                   + QString::number(r.pos());
    return out;
}

QByteArray ServerList::serialize(const QVector<ServerEntry>& servers)
{
    Writer w;
    w.tag(TagCompound, QString());
    w.tag(TagList, QStringLiteral("servers"));


    w.u8(TagCompound);
    w.i32(qint32(servers.size()));

    for (const ServerEntry& e : servers) {

        if (e.hasHidden) {
            w.tag(TagByte, QStringLiteral("hidden"));
            w.u8(e.hidden ? 1 : 0);
        }
        w.tag(TagString, QStringLiteral("ip"));
        w.str(e.ip);
        w.tag(TagString, QStringLiteral("name"));
        w.str(e.name);
        if (!e.icon.isEmpty()) {
            w.tag(TagString, QStringLiteral("icon"));
            w.str(e.icon);
        }
        if (e.hasAcceptTextures) {
            w.tag(TagByte, QStringLiteral("acceptTextures"));
            w.u8(e.acceptTextures ? 1 : 0);
        }
        w.u8(TagEnd);
    }

    w.u8(TagEnd);
    return w.take();
}

QVector<ServerEntry> ServerList::read(const QString& path, QString* error)
{
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly)) {

        return {};
    }
    return parse(f.readAll(), error);
}

bool ServerList::write(const QString& path, const QVector<ServerEntry>& servers, QString* error)
{
    const QByteArray data = serialize(servers);



    const QString tmp = path + QStringLiteral(".tmp");
    {
        QFile f(tmp);
        if (!f.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
            if (error) *error = QStringLiteral("не открыть на запись: ") + tmp;
            return false;
        }
        if (f.write(data) != data.size()) {
            if (error) *error = QStringLiteral("неполная запись: ") + tmp;
            return false;
        }
        f.close();
    }

    QFile::remove(path);
    if (!QFile::rename(tmp, path)) {
        if (error) *error = QStringLiteral("не переименовать ") + tmp;
        QFile::remove(tmp);
        return false;
    }
    return true;
}
