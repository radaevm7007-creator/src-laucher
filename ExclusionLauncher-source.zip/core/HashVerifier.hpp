#pragma once

#include <QString>

namespace HashVerifier {
QString sha256File(const QString& path, QString* error = nullptr);
bool matchesSha256(const QString& path, const QString& expected, QString* error = nullptr);
}
