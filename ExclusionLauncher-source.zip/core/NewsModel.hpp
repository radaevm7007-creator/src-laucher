#pragma once

#include <QNetworkAccessManager>
#include <QObject>
#include <QTimer>
#include <QVariantList>

class NewsModel final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QVariantList items READ items NOTIFY itemsChanged)
    Q_PROPERTY(QVariantList top READ top NOTIFY itemsChanged)
    Q_PROPERTY(bool loading READ loading NOTIFY loadingChanged)
    Q_PROPERTY(QString source READ source NOTIFY itemsChanged)

public:
    explicit NewsModel(QObject* parent = nullptr);

    QVariantList items() const { return m_items; }
    QVariantList top() const;
    Q_INVOKABLE QVariantList topN(int n) const;
    bool loading() const { return m_loading; }
    QString source() const { return m_source; }

    Q_INVOKABLE void refresh();
    Q_INVOKABLE void refreshFromCache();

signals:
    void itemsChanged();
    void loadingChanged();

private:
    void loadFallback();
    void loadCache();
    bool setItemsFromJson(const QByteArray& body);

    QNetworkAccessManager m_network;
    QTimer m_pollTimer;
    QVariantList m_items;
    QString m_source;
    bool m_loading = false;
};
