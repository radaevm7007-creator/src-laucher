#include "NewsModel.hpp"

#include "AppConfig.hpp"
#include "AppPaths.hpp"
#include "NetworkFallback.hpp"

#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QVariantMap>

namespace {



constexpr int kMaxNewsItems = 20;
}

NewsModel::NewsModel(QObject* parent) : QObject(parent)
{
    loadCache();
    refresh();


    m_pollTimer.setInterval(30 * 1000);
    connect(&m_pollTimer, &QTimer::timeout, this, &NewsModel::refresh);
    m_pollTimer.start();
}

QVariantList NewsModel::top() const
{
    return topN(3);
}

QVariantList NewsModel::topN(int n) const
{
    QVariantList out;
    for (int i = 0; i < m_items.size() && i < n; ++i)
        out.append(m_items.at(i));
    return out;
}



void NewsModel::loadFallback()
{


    m_items.clear();
    m_source = QStringLiteral("empty");
    emit itemsChanged();
}

void NewsModel::loadCache()
{
    QFile f(AppPaths::newsCacheFile());
    if (!f.open(QIODevice::ReadOnly)) return;
    if (setItemsFromJson(f.readAll()))
        m_source = QStringLiteral("cache");
}

bool NewsModel::setItemsFromJson(const QByteArray& body)
{
    const auto doc = QJsonDocument::fromJson(body);
    if (!doc.isObject()) return false;
    const auto arr = doc.object().value("items").toArray();
    if (arr.isEmpty()) return false;

    QVariantList next;
    for (const auto& v : arr) {
        if (next.size() >= kMaxNewsItems) break;
        const auto o = v.toObject();
        QVariantMap m;
        m["tag"]         = o.value("tag").toString();
        m["tagColor"]    = o.value("tagColor").toString(QStringLiteral("#4C90F5"));
        m["date"]        = o.value("date").toString();
        m["title"]       = o.value("title").toString();
        m["description"] = o.value("description").toString();
        next.append(m);
    }
    m_items = next;
    emit itemsChanged();
    return true;
}



void NewsModel::refresh()
{
    if (m_loading) return;
    m_loading = true;
    emit loadingChanged();

    NetworkFallback::get(&m_network, NetworkFallback::request(AppConfig::RemoteNewsUrl), this, [this](QNetworkReply* r) {
        r->deleteLater();
        m_loading = false;
        emit loadingChanged();

        if (r->error() != QNetworkReply::NoError) return;

        const QByteArray body = r->readAll();
        if (!setItemsFromJson(body)) return;
        m_source = QStringLiteral("network");


        QFile f(AppPaths::newsCacheFile());
        if (f.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
            f.write(body); f.close();
        }
        emit itemsChanged();
    });
}

void NewsModel::refreshFromCache()
{
    loadCache();
}
