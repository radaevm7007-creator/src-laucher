#pragma once

#include <QObject>
#include <QTimer>
#include <QVariantList>

class ServersModel final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QVariantList items READ items NOTIFY itemsChanged)
    Q_PROPERTY(QString selectedName READ selectedName NOTIFY selectedChanged)
    Q_PROPERTY(int selectedIndex READ selectedIndex NOTIFY selectedChanged)
    Q_PROPERTY(QString statusText READ statusText NOTIFY statusChanged)
    Q_PROPERTY(bool refreshing READ refreshing NOTIFY statusChanged)

public:
    explicit ServersModel(QObject* parent = nullptr);

    QVariantList items() const { return m_items; }
    QString selectedName() const;
    int selectedIndex() const { return m_selectedIndex; }
    QString statusText() const { return m_statusText; }
    bool refreshing() const { return m_refreshing; }

    Q_INVOKABLE void refresh();
    Q_INVOKABLE void select(int index);

signals:
    void itemsChanged();
    void selectedChanged();
    void statusChanged();

private:
    void seed();
    void randomizeMetrics();

    QVariantList m_items;
    QTimer m_refreshTimer;
    QString m_statusText = QStringLiteral("Готов к игре");
    int m_selectedIndex = 0;
    bool m_refreshing = false;
};
