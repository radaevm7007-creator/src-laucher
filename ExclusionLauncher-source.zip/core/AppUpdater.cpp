#include "AppUpdater.hpp"

#include "AppConfig.hpp"
#include "ArchiveManager.hpp"
#include "HashVerifier.hpp"
#include "NetworkFallback.hpp"

#include <QCoreApplication>
#include <QCryptographicHash>
#include <QDir>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QProcess>
#include <QStandardPaths>
#include <QtConcurrent>

namespace {


QString installRoot()
{
    return QDir(QCoreApplication::applicationDirPath()).filePath(QStringLiteral(".."));
}

QString appDir() { return QCoreApplication::applicationDirPath(); }



QString stagePath()    { return QDir(installRoot()).filePath(QStringLiteral("app-new")); }
QString stageVerPath() { return QDir(installRoot()).filePath(QStringLiteral("app-new.ver")); }

}

AppUpdater::AppUpdater(QObject* parent) : QObject(parent)
{



    m_recheck.setInterval(20 * 60 * 1000);
    connect(&m_recheck, &QTimer::timeout, this, [this] { checkForUpdate(); });
    m_recheck.start();

    connect(&m_unpackWatcher, &QFutureWatcher<bool>::finished,
            this, [this] { onUnpackFinished(); });
}

bool AppUpdater::applyStagedOnStartup()
{
    const QString stage = stagePath();
    const QString exe = QDir(stage).filePath(QStringLiteral("ExclusionLauncher.exe"));


    if (!QFileInfo::exists(exe)) {
        QDir(stage).removeRecursively();
        QFile::remove(stageVerPath());
        return false;
    }




    QString stagedVer;
    {
        QFile vf(stageVerPath());
        if (vf.open(QIODevice::ReadOnly)) stagedVer = QString::fromUtf8(vf.readAll()).trimmed();
    }
    if (stagedVer.isEmpty() || !isNewer(stagedVer, QString::fromLatin1(AppConfig::LauncherVersion))) {
        QDir(stage).removeRecursively();
        QFile::remove(stageVerPath());
        return false;
    }

    m_stagedDir = stage;
    m_newVersion = stagedVer;
    m_ready = true;
    writeAndLaunchScript();
    return true;
}


bool AppUpdater::isNewer(const QString& remote, const QString& local)
{
    const QStringList a = remote.split('.');
    const QStringList b = local.split('.');
    const int n = qMax(a.size(), b.size());
    for (int i = 0; i < n; ++i) {
        const int x = i < a.size() ? a[i].toInt() : 0;
        const int y = i < b.size() ? b[i].toInt() : 0;
        if (x != y) return x > y;
    }
    return false;
}

void AppUpdater::checkForUpdate()
{

    if (m_busy || m_ready) return;

    NetworkFallback::get(&m_net, NetworkFallback::request(AppConfig::RemoteAppUrl), this, [this](QNetworkReply* r) {
        r->deleteLater();
        if (r->error() != QNetworkReply::NoError) return;

        const auto obj = QJsonDocument::fromJson(r->readAll()).object();
        const QString remoteVer = obj.value(QStringLiteral("version")).toString();
        const QString url = obj.value(QStringLiteral("url")).toString();
        const QString sha = obj.value(QStringLiteral("sha256")).toString();
        if (remoteVer.isEmpty() || url.isEmpty()) return;


        if (m_busy || m_ready) return;

        if (isNewer(remoteVer, QString::fromLatin1(AppConfig::LauncherVersion))) {
            m_newVersion = remoteVer;
            downloadArchive(url, sha);
        }
    });
}

void AppUpdater::downloadArchive(const QString& url, const QString& sha256, bool allowFallback)
{
    const QString dst = QDir(installRoot()).filePath(QStringLiteral("update.tar.xz"));
    auto* file = new QFile(dst);
    if (!file->open(QIODevice::WriteOnly | QIODevice::Truncate)) { file->deleteLater(); return; }

    m_busy = true;

    auto* r = m_net.get(NetworkFallback::request(url));

    connect(r, &QNetworkReply::readyRead, this, [r, file] { file->write(r->readAll()); });
    connect(r, &QNetworkReply::finished, this, [this, r, file, dst, sha256, url, allowFallback] {
        r->deleteLater();
        file->write(r->readAll());
        file->close();
        file->deleteLater();

        if (r->error() != QNetworkReply::NoError) {
            QFile::remove(dst);
            const QString fallback = allowFallback ? NetworkFallback::fallbackUrlForPrimary(url) : QString();
            if (!fallback.isEmpty()) {
                downloadArchive(fallback, sha256, false);
                return;
            }
            m_busy = false;
            return;
        }


        unpackAsync(dst, sha256);
    });
}

void AppUpdater::unpackAsync(const QString& archivePath, const QString& sha256)
{

    const QString stage = QDir(installRoot()).filePath(QStringLiteral("app-new"));
    QDir(stage).removeRecursively();
    QDir().mkpath(stage);
    m_pendingStage = stage;



    m_unpackWatcher.setFuture(QtConcurrent::run(
        [archivePath, stage, sha256]() -> bool {
            if (!sha256.isEmpty() && !HashVerifier::matchesSha256(archivePath, sha256)) {
                QFile::remove(archivePath);
                return false;
            }
            const bool ok = ArchiveManager::extractSync(archivePath, stage);
            QFile::remove(archivePath);
            return ok;
        }));
}

void AppUpdater::onUnpackFinished()
{
    if (!m_unpackWatcher.result()) {
        QDir(m_pendingStage).removeRecursively();
        m_pendingStage.clear();
        m_busy = false;
        return;
    }



    {
        QFile vf(stageVerPath());
        if (vf.open(QIODevice::WriteOnly | QIODevice::Truncate))
            vf.write(m_newVersion.toUtf8());
    }

    m_stagedDir = m_pendingStage;
    m_pendingStage.clear();
    m_ready = true;
    m_busy = false;
    emit updateReadyChanged();
}

void AppUpdater::writeAndLaunchScript()
{
    if (!m_ready || m_stagedDir.isEmpty()) return;

    const QString root = QDir(installRoot()).absolutePath();
    const QString app = QDir::toNativeSeparators(appDir());
    const QString stage = QDir::toNativeSeparators(m_stagedDir);
    const QString exe = QDir::toNativeSeparators(QCoreApplication::applicationFilePath());
    const QString verMarker = QDir::toNativeSeparators(stageVerPath());
    const QString currentPid = QString::number(QCoreApplication::applicationPid());





    const QString bat = QDir::toNativeSeparators(QDir(root).filePath(QStringLiteral("update.cmd")));
    QFile f(bat);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Truncate)) return;
    const QString oldApp = QDir::toNativeSeparators(QDir(root).filePath(QStringLiteral("app-old")));
    const QString logPath = QDir::toNativeSeparators(QDir(root).filePath(QStringLiteral("update.log")));
    const QString script =
        "@echo off\r\n"
        "chcp 65001 >nul\r\n"
        "setlocal\r\n"
        "cd /d \"" + QDir::toNativeSeparators(root) + "\"\r\n"
        "set \"APP=" + app + "\"\r\n"
        "set \"STAGE=" + stage + "\"\r\n"
        "set \"OLD=" + oldApp + "\"\r\n"
        "set \"EXE=" + exe + "\"\r\n"
        "set \"VER=" + verMarker + "\"\r\n"
        "set \"PID=" + currentPid + "\"\r\n"
        "set \"LOG=" + logPath + "\"\r\n"
        "echo [%date% %time%] update start pid=%PID% app=%APP% stage=%STAGE% >> \"%LOG%\"\r\n"
        "set /a WAIT=0\r\n"
        ":wait\r\n"
        "tasklist /fi \"pid eq %PID%\" | find \"%PID%\" >nul && (\r\n"
        "  set /a WAIT+=1\r\n"
        "  if %WAIT% GEQ 60 goto fail_wait\r\n"
        "  ping 127.0.0.1 -n 2 >nul\r\n"
        "  goto wait\r\n"
        ")\r\n"
        "if not exist \"%STAGE%\\ExclusionLauncher.exe\" goto fail_no_stage\r\n"
        "rmdir /s /q \"%OLD%\" 2>nul\r\n"
        "move /y \"%APP%\" \"%OLD%\" >> \"%LOG%\" 2>&1\r\n"
        "if errorlevel 1 goto fail_move_old\r\n"
        "move /y \"%STAGE%\" \"%APP%\" >> \"%LOG%\" 2>&1\r\n"
        "if errorlevel 1 (\r\n"
        "  robocopy \"%STAGE%\" \"%APP%\" /MIR /R:2 /W:1 >> \"%LOG%\" 2>&1\r\n"
        "  if errorlevel 8 (\r\n"
        "    rmdir /s /q \"%APP%\" 2>nul\r\n"
        "    move /y \"%OLD%\" \"%APP%\" >> \"%LOG%\" 2>&1\r\n"
        "    goto fail_move_new\r\n"
        "  )\r\n"
        "  rmdir /s /q \"%STAGE%\" 2>nul\r\n"
        ")\r\n"
        "del /q \"%VER%\" 2>nul\r\n"
        "echo [%date% %time%] update applied >> \"%LOG%\"\r\n"
        "start \"\" \"%EXE%\"\r\n"
        "rmdir /s /q \"%OLD%\" 2>nul\r\n"
        "del \"%~f0\"\r\n"
        "exit /b 0\r\n"
        ":fail_wait\r\n"
        "echo [%date% %time%] failed: process did not exit >> \"%LOG%\"\r\n"
        "goto fail\r\n"
        ":fail_no_stage\r\n"
        "echo [%date% %time%] failed: staged launcher exe not found >> \"%LOG%\"\r\n"
        "goto fail\r\n"
        ":fail_move_old\r\n"
        "echo [%date% %time%] failed: cannot move current app to old >> \"%LOG%\"\r\n"
        "goto fail\r\n"
        ":fail_move_new\r\n"
        "echo [%date% %time%] failed: cannot move/copy staged app >> \"%LOG%\"\r\n"
        "goto fail\r\n"
        ":fail\r\n"
        "del /q \"%VER%\" 2>nul\r\n"
        "start \"\" \"%EXE%\" 2>nul\r\n"
        "exit /b 1\r\n";
    f.write(script.toUtf8());
    f.close();


    QProcess::startDetached(QStringLiteral("cmd"), {QStringLiteral("/c"), bat});
}

void AppUpdater::applyAndRestart()
{
    if (!m_ready || m_stagedDir.isEmpty()) return;
    writeAndLaunchScript();
    QCoreApplication::quit();
}
