#include "DownloadManager.hpp"
#include "SegmentedDownloader.hpp"
#include <QJsonDocument>
#include <QJsonObject>
#include "AppConfig.hpp"
#include "HardwareId.hpp"
#include "AppPaths.hpp"
#include "ClientVerifier.hpp"
#include "ClientInstall.hpp"
#include "HashVerifier.hpp"
#include "InstalledStore.hpp"
#include "GameLauncher.hpp"
#include "IntegrityChecker.hpp"
#include "SettingsManager.hpp"

#include <QDebug>
#include <QDir>
#include <QFileInfo>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QUrl>
#include <QtConcurrent>

DownloadManager::DownloadManager(SettingsManager* settings, InstalledStore* installed, QObject* parent)
    : QObject(parent), m_settings(settings), m_installed(installed), m_archive(this)
{

    m_seg = new SegmentedDownloader(this);
    connect(m_seg, &SegmentedDownloader::progress, this, [this](qint64 got, qint64 total) {
        m_progress = total > 0 ? double(got) / double(total) : 0.0;
        m_speedText = humanSpeed(got, m_timer.elapsed());
        emit progressChanged();
    });
    connect(m_seg, &SegmentedDownloader::finished, this, [this](bool ok, const QString& err) {
        if (!ok) { finishWithError(QStringLiteral("Не удалось скачать клиент: ") + err); return; }
        m_progress = 1.0;
        emit progressChanged();
        verifyAndExtract();
    });


    connect(&m_hashWatcher, &QFutureWatcher<bool>::finished, this, [this] {
        if (!m_busy) return;
        if (!m_hashWatcher.result()) {



            if (m_archiveReused) {
                m_archiveReused = false;
                QFile::remove(m_tempZip);
                if (m_downloadUrl.isValid()) { beginHttpDownload(m_downloadUrl); return; }
            }
            finishWithError(QStringLiteral("SHA-256 архива не совпадает."));
            return;
        }

        m_archiveReused = false;
        setState(QStringLiteral("Распаковка…"));
        QDir().mkpath(m_stagingDir);
        m_archive.extractArchive(m_tempZip, m_stagingDir);
    });

    connect(&m_archive, &ArchiveManager::finished, this, [this](bool ok, const QString& error) {
        if (!m_busy) return;
        if (!ok) {
            finishWithError(error);
            return;
        }



        setState(QStringLiteral("Установка…"));
        const QString finalDir = QDir(m_settings->installDir()).filePath(m_currentClientId);
        const QString staging  = m_stagingDir;
        m_installWatcher.setFuture(QtConcurrent::run([finalDir, staging]() -> QString {
            return ClientInstall::installExtractedClient(finalDir, staging);
        }));
    });

    connect(&m_installWatcher, &QFutureWatcher<QString>::finished, this, [this] {
        if (!m_busy) return;
        const QString err = m_installWatcher.result();
        if (!err.isEmpty()) { finishWithError(err); return; }



        m_installed->markInstalled(m_currentClientId,
                                   m_client.value("version").toString(),
                                   m_client.value("sha256").toString(),
                                   m_client.value("packageUrl").toString());
        QFile::remove(m_tempZip);
        setState(QStringLiteral("Установлен"));
        reportDownload(m_currentClientId, m_client.value("version").toString());
        const QString doneId = m_currentClientId;
        m_busy = false;
        m_progress = 1.0;
        emit stateChanged();
        emit progressChanged();
        emit installFinished(doneId);
    });
}

void DownloadManager::reportDownload(const QString& clientId, const QString& version)
{


    QNetworkRequest req{QUrl(AppConfig::ServerBaseUrl + QStringLiteral("/stats/download"))};
    req.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/json"));
    req.setHeader(QNetworkRequest::UserAgentHeader, QStringLiteral("ExclusionLauncher/0.1"));

    QJsonObject body;
    body.insert(QStringLiteral("client_id"), clientId);
    body.insert(QStringLiteral("version"), version);
    body.insert(QStringLiteral("launcher_version"), QString::fromLatin1(AppConfig::LauncherVersion));
    body.insert(QStringLiteral("hwid"), HardwareId::value());

    auto* r = m_network.post(req, QJsonDocument(body).toJson(QJsonDocument::Compact));
    connect(r, &QNetworkReply::finished, this, [r] { r->deleteLater(); });
}

void DownloadManager::setState(const QString& text)
{
    m_statusText = text;
    emit stateChanged();
}

QString DownloadManager::humanSpeed(qint64 bytes, qint64 ms) const
{
    if (ms <= 0) return QStringLiteral("0 MB/s");
    const double seconds = ms / 1000.0;
    const double mbps = (bytes / 1024.0 / 1024.0) / seconds;
    return QString::number(mbps, 'f', mbps < 10.0 ? 1 : 0) + QStringLiteral(" MB/s");
}

void DownloadManager::resetTransfer()
{
    if (m_seg) m_seg->cancel();
    if (QNetworkReply* reply = m_reply.data()) {




        m_reply.clear();
        reply->disconnect(this);
        reply->abort();
        reply->deleteLater();
    }
    if (m_file.isOpen()) m_file.close();
}

void DownloadManager::installClient(const QVariantMap& client)
{
    if (m_busy) return;
    if (m_blocker && m_blocker->busy()) {
        finishWithError(tr("Идёт проверка целостности файлов — дождитесь её завершения."));
        return;
    }




    clearError();

    m_client = client;
    m_currentClientId = client.value("id").toString();
    if (m_currentClientId.isEmpty()) {
        finishWithError(QStringLiteral("У клиента отсутствует ID."));
        return;
    }

    m_busy = true;
    m_progress = 0.0;
    m_speedText.clear();


    const QString packageUrlRaw = client.value("packageUrl").toString();
    QString ext = QStringLiteral(".zip");
    const QString low = packageUrlRaw.toLower();
    if      (low.endsWith(QStringLiteral(".tar.xz"))) ext = QStringLiteral(".tar.xz");
    else if (low.endsWith(QStringLiteral(".txz")))    ext = QStringLiteral(".txz");
    else if (low.endsWith(QStringLiteral(".tar.gz"))) ext = QStringLiteral(".tar.gz");
    else if (low.endsWith(QStringLiteral(".tgz")))    ext = QStringLiteral(".tgz");
    else if (low.endsWith(QStringLiteral(".tar")))    ext = QStringLiteral(".tar");
    m_tempZip = QDir(AppPaths::tempRoot()).filePath(m_currentClientId + ext);
    m_stagingDir = QDir(AppPaths::tempRoot()).filePath(QStringLiteral("staging-") + m_currentClientId);


    QDir(m_stagingDir).removeRecursively();
    m_archiveReused = false;
    emit stateChanged();
    emit progressChanged();

    const QString packageUrl = client.value("packageUrl").toString();
    if (packageUrl.startsWith(QStringLiteral("qrc:/"))) {
        QFile::remove(m_tempZip);
        beginResourceCopy(QStringLiteral(":/") + packageUrl.mid(QStringLiteral("qrc:/").size()));
        return;
    }

    const QUrl url(packageUrl);
    if (!url.isValid() || (url.scheme() != "https" && url.scheme() != "http")) {
        finishWithError(QStringLiteral("Некорректный URL архива клиента."));
        return;
    }
    m_downloadUrl = url;





    if (QFileInfo(m_tempZip).size() > 0) {
        m_archiveReused = true;
        setState(QStringLiteral("Проверка ранее скачанного архива…"));
        verifyAndExtract();
        return;
    }
    beginHttpDownload(url);
}

void DownloadManager::beginResourceCopy(const QString& resourcePath)
{
    setState(QStringLiteral("Подготавливаем демо-пакет…"));
    QFile source(resourcePath);
    if (!source.open(QIODevice::ReadOnly)) {
        finishWithError(QStringLiteral("Встроенный демо-архив не найден."));
        return;
    }

    QFile out(m_tempZip);
    if (!out.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        finishWithError(QStringLiteral("Нет доступа к временной папке."));
        return;
    }

    const QByteArray data = source.readAll();
    if (out.write(data) != data.size()) {
        finishWithError(QStringLiteral("Не удалось записать демо-архив."));
        return;
    }
    out.close();
    m_progress = 1.0;
    m_speedText = QStringLiteral("локально");
    emit progressChanged();
    verifyAndExtract();
}

void DownloadManager::beginHttpDownload(const QUrl& url)
{
    setState(QStringLiteral("Скачивание…"));
    if (m_file.isOpen()) m_file.close();



    m_timer.restart();
    m_seg->start(url.toString(), m_tempZip, 3);
}

void DownloadManager::verifyAndExtract()
{
    setState(QStringLiteral("Проверка файла…"));


    const QString archive  = m_tempZip;
    const QString expected = m_client.value("sha256").toString();
    m_hashWatcher.setFuture(QtConcurrent::run([archive, expected]() -> bool {
        return HashVerifier::matchesSha256(archive, expected);
    }));
}

void DownloadManager::cancel()
{
    if (!m_busy) return;
    m_busy = false;
    resetTransfer();
    m_archive.cancel();
    QFile::remove(m_tempZip);
    QDir(m_stagingDir).removeRecursively();
    m_progress = 0.0;
    setState(QStringLiteral("Отменено"));
    emit progressChanged();
}

void DownloadManager::removeClient(const QString& id)
{
    if (m_busy || id.isEmpty()) return;



    const QString target = QDir(m_settings->installDir()).filePath(id);
    QDir dir(target);
    if (dir.exists() && !dir.removeRecursively()) {
        finishWithError(tr("Не удалось удалить папку клиента (возможно, он сейчас запущен — закройте игру)."));
        return;
    }
    m_installed->remove(id);
}

void DownloadManager::finishWithError(const QString& message)
{
    resetTransfer();
    m_archive.cancel();

    if (!m_stagingDir.isEmpty()) QDir(m_stagingDir).removeRecursively();
    m_archiveReused = false;
    m_busy = false;
    m_statusText = QStringLiteral("Ошибка");
    m_errorMessage = message;
    emit stateChanged();
    emit errorChanged();
}

void DownloadManager::clearError()
{
    if (m_errorMessage.isEmpty()) return;
    m_errorMessage.clear();
    emit errorChanged();
}
