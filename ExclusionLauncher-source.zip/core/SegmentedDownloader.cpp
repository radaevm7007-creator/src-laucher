#include "SegmentedDownloader.hpp"

#include "NetworkFallback.hpp"

#include <QNetworkRequest>
#include <QUrl>
#include <QDir>
#include <QFileInfo>
#include <QTimer>

namespace {
QNetworkRequest makeReq(const QString& url)
{
    return NetworkFallback::request(url);
}
}

SegmentedDownloader::SegmentedDownloader(QObject* parent) : QObject(parent) {}

int SegmentedDownloader::retryDelayMsForAttempt(int attempt)
{
    if (attempt <= 1) return 750;
    if (attempt == 2) return 1500;
    if (attempt == 3) return 3000;
    return 5000;
}

QString SegmentedDownloader::fallbackUrlForPrimary(const QString& url)
{
    return NetworkFallback::fallbackUrlForPrimary(url);
}

void SegmentedDownloader::start(const QString& url, const QString& destPath, int segments)
{



    cleanup();

    m_url = url;
    m_dest = destPath;
    m_segments = qBound(1, segments, 16);
    m_total = -1;
    m_doneSegs = 0;
    m_completedBytes = 0;
    m_canceled = false;
    m_finished = false;
    m_usedFallbackUrl = false;
    m_single = false;
    m_singleGot = 0;
    m_timer.restart();

    QFile::remove(m_dest);
    beginProbe();
}

void SegmentedDownloader::cancel()
{
    m_canceled = true;
    if (m_singleReply) m_singleReply->abort();
    for (Seg* s : m_segs)
        if (s && s->reply) s->reply->abort();
}



void SegmentedDownloader::beginProbe()
{
    if (m_segments <= 1) { fallbackSingle(); return; }

    QNetworkRequest req = makeReq(m_url);
    req.setRawHeader("Range", "bytes=0-0");
    auto* r = m_nam.get(req);
    connect(r, &QNetworkReply::finished, this, [this, r] {
        const bool replyOk = r->error() == QNetworkReply::NoError;
        r->deleteLater();
        if (m_canceled) return;
        if (!replyOk) { fallbackSingle(); return; }
        const int code = r->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        qint64 total = -1;
        if (code == 206) {
            const QByteArray cr = r->rawHeader("Content-Range");
            const int slash = cr.lastIndexOf('/');
            if (slash >= 0) total = cr.mid(slash + 1).trimmed().toLongLong();
        }


        if (code != 206 || total <= 0) { fallbackSingle(); return; }
        beginSegments(total);
    });
}

void SegmentedDownloader::beginSegments(qint64 total)
{
    m_total = total;


    QFile f(m_dest);
    if (!f.open(QIODevice::WriteOnly) || !f.resize(total)) {
        fail(QStringLiteral("Не удалось создать файл: ") + m_dest);
        return;
    }
    f.close();


    int n = m_segments;
    const qint64 minSeg = 1 * 1024 * 1024;
    if (total / n < minSeg) n = qMax(1, int(total / minSeg));

    const qint64 base = total / n;
    for (int i = 0; i < n; ++i) {
        Seg* s = new Seg();
        s->start = qint64(i) * base;
        s->end = (i == n - 1) ? (total - 1) : (s->start + base - 1);
        s->written = 0;
        s->file.setFileName(m_dest);
        if (!s->file.open(QIODevice::ReadWrite) || !s->file.seek(s->start)) {
            delete s;
            fail(QStringLiteral("Не открыть сегмент файла"));
            return;
        }
        m_segs.push_back(s);
    }
    for (int i = 0; i < m_segs.size(); ++i) startSegment(i);
}

void SegmentedDownloader::startSegment(int i)
{
    Seg* s = m_segs.at(i);
    const qint64 from = s->start + s->written;
    if (from > s->end) { onSegFinished(i); return; }

    QNetworkRequest req = makeReq(m_url);
    req.setRawHeader("Range",
                     QByteArrayLiteral("bytes=") + QByteArray::number(from) +
                     '-' + QByteArray::number(s->end));
    s->reply = m_nam.get(req);
    connect(s->reply, &QNetworkReply::readyRead, this, [this, i] { onSegReadyRead(i); });
    connect(s->reply, &QNetworkReply::finished, this, [this, i] { onSegFinished(i); });
}

void SegmentedDownloader::onSegReadyRead(int i)
{
    if (m_canceled) return;
    Seg* s = m_segs.at(i);
    if (!s->reply) return;
    const QByteArray data = s->reply->readAll();
    if (data.isEmpty()) return;

    qint64 room = (s->end - (s->start + s->written)) + 1;
    qint64 n = qMin<qint64>(room, data.size());
    if (n > 0) {
        s->file.write(data.constData(), n);
        s->written += n;
    }
    emitProgress();
}

void SegmentedDownloader::onSegFinished(int i)
{
    if (m_canceled || m_finished) return;
    Seg* s = m_segs.at(i);
    QNetworkReply* rep = s->reply;
    const bool ok = rep && rep->error() == QNetworkReply::NoError;
    if (rep) { rep->deleteLater(); s->reply.clear(); }

    const qint64 need = (s->end - s->start) + 1;
    if (s->written >= need) {
        s->file.flush();
        // Диапазон докачан — учитываем байты и пробуем забрать работу у
        // самого медленного сегмента, чтобы это соединение не простаивало.
        m_completedBytes += s->written;
        s->written = 0;
        s->retries = 0;
        if (tryStealWork(i)) return;         // сегмент i получил новый диапазон
        // Красть нечего — сегмент выходит на покой.
        if (s->file.isOpen()) s->file.close();
        if (m_completedBytes >= m_total) succeed();
        return;
    }


    if (!ok || s->written < need) {
        const QString err = rep ? rep->errorString() : QStringLiteral("соединение закрыто");
        const int nextAttempt = ++s->retries;
        if (nextAttempt > kMaxRetries) {
            fail(QStringLiteral("Сегмент не докачался: ") + err);
            return;
        }
        QTimer::singleShot(retryDelayMsForAttempt(nextAttempt), this, [this, i] {
            if (!m_canceled && !m_finished)
                startSegment(i);
        });
    }
}

bool SegmentedDownloader::tryStealWork(int freeIdx)
{
    if (m_canceled || m_finished) return false;
    // Ищем активно качающийся сегмент с наибольшим остатком.
    int best = -1;
    qint64 bestRem = 0;
    for (int j = 0; j < m_segs.size(); ++j) {
        if (j == freeIdx) continue;
        Seg* sj = m_segs.at(j);
        if (!sj->reply) continue;                       // не качает (на покое)
        const qint64 rem = sj->end - (sj->start + sj->written) + 1;
        if (rem > bestRem) { bestRem = rem; best = j; }
    }
    static const qint64 kMinSteal = 4 * 1024 * 1024;    // мельчить не стоит
    if (best < 0 || bestRem < kMinSteal) return false;

    Seg* sj = m_segs.at(best);
    const qint64 curPos = sj->start + sj->written;       // где sj сейчас
    const qint64 oldEnd = sj->end;
    const qint64 mid = curPos + bestRem / 2;             // делим остаток пополам

    // Урезаем медленный сегмент до середины и перезапускаем — его соединение
    // остановится на mid, дальше докачает освободившийся сегмент.
    if (sj->reply) {
        sj->reply->disconnect(this);
        sj->reply->abort();
        sj->reply->deleteLater();
        sj->reply.clear();
    }
    sj->end = mid;
    startSegment(best);

    // Освободившийся сегмент берёт вторую половину [mid+1 .. oldEnd].
    Seg* si = m_segs.at(freeIdx);
    si->start = mid + 1;
    si->end = oldEnd;
    si->written = 0;
    si->retries = 0;
    if (!si->file.isOpen())
        (void)si->file.open(QIODevice::ReadWrite);
    si->file.seek(si->start);
    startSegment(freeIdx);
    return true;
}

void SegmentedDownloader::fallbackSingle()
{
    if (m_finished || m_canceled) return;
    m_single = true;
    m_singleFile.setFileName(m_dest);
    if (m_singleFile.isOpen()) m_singleFile.close();
    if (!m_singleFile.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        fail(QStringLiteral("Не открылся файл: ") + m_dest);
        return;
    }
    m_singleReply = m_nam.get(makeReq(m_url));
    connect(m_singleReply, &QNetworkReply::readyRead, this, &SegmentedDownloader::onSingleReadyRead);
    connect(m_singleReply, &QNetworkReply::downloadProgress, this,
            [this](qint64 got, qint64 total) { m_singleGot = got; m_total = total; emit progress(got, total); });
    connect(m_singleReply, &QNetworkReply::finished, this, &SegmentedDownloader::onSingleFinished);
}

void SegmentedDownloader::onSingleReadyRead()
{
    if (m_singleReply && m_singleFile.isOpen())
        m_singleFile.write(m_singleReply->readAll());
}

void SegmentedDownloader::onSingleFinished()
{
    if (m_singleReply && m_singleFile.isOpen())
        m_singleFile.write(m_singleReply->readAll());
    const bool ok = m_singleReply && m_singleReply->error() == QNetworkReply::NoError;
    const QString err = m_singleReply ? m_singleReply->errorString() : QStringLiteral("отмена");
    if (m_singleReply) { m_singleReply->deleteLater(); m_singleReply.clear(); }
    m_singleFile.close();
    if (m_canceled) return;
    if (ok) succeed(); else fail(err);
}

void SegmentedDownloader::emitProgress()
{
    if (m_single) return;
    qint64 got = m_completedBytes;          // уже докачанные (в т.ч. переуступленные) диапазоны
    for (Seg* s : m_segs) got += s->written; // + текущий прогресс активных сегментов
    emit progress(got, m_total);
}

void SegmentedDownloader::fail(const QString& err)
{
    if (m_finished) return;

    const QString fallbackUrl = m_usedFallbackUrl ? QString() : fallbackUrlForPrimary(m_url);
    if (!fallbackUrl.isEmpty()) {
        cleanup();
        QFile::remove(m_dest);
        m_url = fallbackUrl;
        m_total = -1;
        m_doneSegs = 0;
        m_completedBytes = 0;
        m_single = false;
        m_singleGot = 0;
        m_usedFallbackUrl = true;
        m_timer.restart();
        beginProbe();
        return;
    }

    m_finished = true;
    cleanup();
    emit finished(false, err);
}

void SegmentedDownloader::succeed()
{
    if (m_finished) return;
    m_finished = true;
    cleanup();
    emit finished(true, QString());
}

void SegmentedDownloader::cleanup()
{
    for (Seg* s : m_segs) {
        if (s->reply) {


            s->reply->disconnect(this);
            s->reply->abort();
            s->reply->deleteLater();
        }
        if (s->file.isOpen()) s->file.close();
        delete s;
    }
    m_segs.clear();
    if (m_singleReply) {
        m_singleReply->disconnect(this);
        m_singleReply->abort();
        m_singleReply->deleteLater();
        m_singleReply.clear();
    }
    if (m_singleFile.isOpen()) m_singleFile.close();
}
