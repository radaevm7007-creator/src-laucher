#include "InstalledStore.hpp"
#include "AppPaths.hpp"

#include <QDateTime>
#include <QFile>
#include <QJsonDocument>

InstalledStore::InstalledStore(QObject* parent) : QObject(parent)
{
    load();
}

void InstalledStore::load()
{
    QFile file(AppPaths::installedFile());
    if (!file.open(QIODevice::ReadOnly))
        return;

    const auto doc = QJsonDocument::fromJson(file.readAll());
    if (doc.isObject())
        m_clients = doc.object().value("clients").toObject();
}

void InstalledStore::save() const
{
    QFile file(AppPaths::installedFile());
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate))
        return;

    QJsonObject root;
    root.insert("clients", m_clients);
    file.write(QJsonDocument(root).toJson(QJsonDocument::Indented));
}

bool InstalledStore::isInstalled(const QString& id) const
{
    return m_clients.contains(id);
}

QString InstalledStore::installedVersion(const QString& id) const
{
    return m_clients.value(id).toObject().value("version").toString();
}

QString InstalledStore::installedSha(const QString& id) const
{
    return m_clients.value(id).toObject().value("sha256").toString();
}

QString InstalledStore::installedPackageUrl(const QString& id) const
{
    return m_clients.value(id).toObject().value("packageUrl").toString();
}

bool InstalledStore::needsUpdate(const QString& id, const QString& sha256,
                                 const QString& packageUrl) const
{
    if (!isInstalled(id) || sha256.isEmpty()) return false;



    const QString have = installedSha(id);
    if (have.compare(sha256, Qt::CaseInsensitive) != 0) return true;

    if (!packageUrl.isEmpty()) {
        const QString storedPackage = installedPackageUrl(id);
        if (!storedPackage.isEmpty() && storedPackage != packageUrl) return true;
    }

    return false;
}

void InstalledStore::markInstalled(const QString& id, const QString& version,
                                   const QString& sha256,
                                   const QString& packageUrl)
{
    QJsonObject entry{
        {"version", version},
        {"sha256", sha256},
        {"packageUrl", packageUrl},
        {"installedAt", QDateTime::currentDateTimeUtc().toString(Qt::ISODate)}
    };
    m_clients.insert(id, entry);
    save();
    ++m_revision;
    emit changed();
}

void InstalledStore::remove(const QString& id)
{
    if (!m_clients.contains(id)) return;
    m_clients.remove(id);
    save();
    ++m_revision;
    emit changed();
}
