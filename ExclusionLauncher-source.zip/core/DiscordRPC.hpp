#pragma once

#include <QDateTime>
#include <QLocalSocket>
#include <QObject>
#include <QString>
#include <QTimer>

class SettingsManager;











class DiscordRPC final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool connected READ connected NOTIFY connectedChanged)

public:
    explicit DiscordRPC(SettingsManager* settings, QObject* parent = nullptr);
    ~DiscordRPC() override;

    bool connected() const { return m_handshakeDone; }


    Q_INVOKABLE void setPresence(const QString& details, const QString& state);


    Q_INVOKABLE void setPlaying(const QString& clientName);
    Q_INVOKABLE void setIdle();

private:
    enum Opcode : quint32 { OpHandshake = 0, OpFrame = 1, OpClose = 2, OpPing = 3, OpPong = 4 };

    void tryConnect();
    void onConnected();
    void onDisconnected();
    void onReadyRead();

    void sendFrame(Opcode op, const QByteArray& json);
    void pushPresence();
    void onSettingChanged();

    QLocalSocket m_socket;
    QTimer m_reconnectTimer;
    SettingsManager* m_settings = nullptr;

    QByteArray m_rx;
    int m_pipeIndex = 0;
    bool m_handshakeDone = false;

    QString m_details;
    QString m_state;
    qint64 m_startedAt = 0;

signals:
    void connectedChanged();
};
