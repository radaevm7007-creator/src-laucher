#include "DiscordRPC.hpp"

#include "AppConfig.hpp"
#include "SettingsManager.hpp"

#include <QCoreApplication>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QUuid>

namespace {



constexpr const char* kApplicationId = "1538902019144683570";




constexpr const char* kLargeImage = "logo";


constexpr int kMaxPipeIndex = 10;

QString pipeName(int index)
{
#ifdef Q_OS_WIN
    return QStringLiteral("discord-ipc-%1").arg(index);
#else

    const QByteArray runtime = qgetenv("XDG_RUNTIME_DIR");
    const QString base = runtime.isEmpty() ? QStringLiteral("/tmp")
                                           : QString::fromLocal8Bit(runtime);
    return base + QStringLiteral("/discord-ipc-%1").arg(index);
#endif
}

}

DiscordRPC::DiscordRPC(SettingsManager* settings, QObject* parent)
    : QObject(parent), m_settings(settings)
{
    m_startedAt = QDateTime::currentSecsSinceEpoch();
    m_details = QStringLiteral("В лаунчере");

    connect(&m_socket, &QLocalSocket::connected,    this, &DiscordRPC::onConnected);
    connect(&m_socket, &QLocalSocket::disconnected, this, &DiscordRPC::onDisconnected);
    connect(&m_socket, &QLocalSocket::readyRead,    this, &DiscordRPC::onReadyRead);
    connect(&m_socket, &QLocalSocket::errorOccurred, this, [this](QLocalSocket::LocalSocketError) {

        m_pipeIndex = (m_pipeIndex + 1) % kMaxPipeIndex;
        if (!m_reconnectTimer.isActive()) m_reconnectTimer.start();
    });


    m_reconnectTimer.setInterval(15 * 1000);
    connect(&m_reconnectTimer, &QTimer::timeout, this, &DiscordRPC::tryConnect);

    if (m_settings) {
        connect(m_settings, &SettingsManager::discordRichPresenceChanged,
                this, &DiscordRPC::onSettingChanged);
        connect(m_settings, &SettingsManager::nicknameChanged, this, [this] { pushPresence(); });
    }

    onSettingChanged();
}

DiscordRPC::~DiscordRPC()
{
    if (m_socket.state() != QLocalSocket::UnconnectedState) {
        m_socket.disconnectFromServer();
        m_socket.abort();
    }
}



void DiscordRPC::onSettingChanged()
{
    const bool wanted = m_settings ? m_settings->discordRichPresence() : true;
    if (wanted) {
        if (m_socket.state() == QLocalSocket::UnconnectedState) tryConnect();
        m_reconnectTimer.start();
    } else {
        m_reconnectTimer.stop();
        if (m_socket.state() != QLocalSocket::UnconnectedState) {
            m_socket.disconnectFromServer();
            m_socket.abort();
        }
        if (m_handshakeDone) {
            m_handshakeDone = false;
            emit connectedChanged();
        }
    }
}

void DiscordRPC::tryConnect()
{
    if (m_settings && !m_settings->discordRichPresence()) return;
    if (m_socket.state() != QLocalSocket::UnconnectedState) return;

    m_rx.clear();
    m_socket.connectToServer(pipeName(m_pipeIndex));
}

void DiscordRPC::onConnected()
{
    m_reconnectTimer.stop();


    QJsonObject hello;
    hello.insert(QStringLiteral("v"), 1);
    hello.insert(QStringLiteral("client_id"), QString::fromLatin1(kApplicationId));
    sendFrame(OpHandshake, QJsonDocument(hello).toJson(QJsonDocument::Compact));
}

void DiscordRPC::onDisconnected()
{
    if (m_handshakeDone) {
        m_handshakeDone = false;
        emit connectedChanged();
    }
    m_rx.clear();
    if (!m_settings || m_settings->discordRichPresence())
        m_reconnectTimer.start();
}



void DiscordRPC::sendFrame(Opcode op, const QByteArray& json)
{
    if (m_socket.state() != QLocalSocket::ConnectedState) return;

    QByteArray frame;
    frame.reserve(8 + json.size());
    const quint32 opLE  = qToLittleEndian<quint32>(op);
    const quint32 lenLE = qToLittleEndian<quint32>(quint32(json.size()));
    frame.append(reinterpret_cast<const char*>(&opLE), 4);
    frame.append(reinterpret_cast<const char*>(&lenLE), 4);
    frame.append(json);

    m_socket.write(frame);
    m_socket.flush();
}

void DiscordRPC::onReadyRead()
{
    m_rx.append(m_socket.readAll());


    while (m_rx.size() >= 8) {
        quint32 op = 0, len = 0;
        memcpy(&op,  m_rx.constData(),     4);
        memcpy(&len, m_rx.constData() + 4, 4);
        op  = qFromLittleEndian(op);
        len = qFromLittleEndian(len);

        if (quint32(m_rx.size()) < 8 + len) return;

        const QByteArray payload = m_rx.mid(8, int(len));
        m_rx.remove(0, int(8 + len));

        switch (op) {
        case OpFrame: {




            const QJsonObject obj = QJsonDocument::fromJson(payload).object();
            const QString evt = obj.value(QStringLiteral("evt")).toString();
            const QString cmd = obj.value(QStringLiteral("cmd")).toString();

            if (evt == QLatin1String("ERROR")) {
                const QJsonObject data = obj.value(QStringLiteral("data")).toObject();
                qWarning() << "[discord] отказ:" << data.value(QStringLiteral("code")).toInt()
                           << data.value(QStringLiteral("message")).toString();
                break;
            }
            if (!m_handshakeDone && (evt == QLatin1String("READY")
                                     || cmd == QLatin1String("DISPATCH"))) {
                m_handshakeDone = true;
                qInfo() << "[discord] подключено, канал" << m_pipeIndex;
                emit connectedChanged();
                pushPresence();
            }
            break;
        }
        case OpPing:
            sendFrame(OpPong, payload);
            break;
        case OpClose:
            m_socket.disconnectFromServer();
            break;
        default:
            break;
        }
    }
}



void DiscordRPC::pushPresence()
{
    if (!m_handshakeDone) return;
    if (m_settings && !m_settings->discordRichPresence()) return;

    QJsonObject activity;
    if (!m_details.isEmpty()) activity.insert(QStringLiteral("details"), m_details);


    QString state = m_state;
    if (state.isEmpty() && m_settings) {
        const QString nick = m_settings->nickname();
        if (!nick.isEmpty()) state = QStringLiteral("Игрок: ") + nick;
    }
    if (!state.isEmpty()) activity.insert(QStringLiteral("state"), state);

    QJsonObject timestamps;
    timestamps.insert(QStringLiteral("start"), m_startedAt);
    activity.insert(QStringLiteral("timestamps"), timestamps);

    QJsonObject assets;
    assets.insert(QStringLiteral("large_image"), QString::fromLatin1(kLargeImage));
    assets.insert(QStringLiteral("large_text"),  QString::fromLatin1(AppConfig::LauncherName));
    activity.insert(QStringLiteral("assets"), assets);


    QJsonObject tgButton;
    tgButton.insert(QStringLiteral("label"), QStringLiteral("Telegram"));
    tgButton.insert(QStringLiteral("url"),   QStringLiteral("https://t.me/ExclusionLauncher"));
    QJsonArray buttons;
    buttons.append(tgButton);
    activity.insert(QStringLiteral("buttons"), buttons);

    QJsonObject args;
    args.insert(QStringLiteral("pid"), int(QCoreApplication::applicationPid()));
    args.insert(QStringLiteral("activity"), activity);

    QJsonObject cmd;
    cmd.insert(QStringLiteral("cmd"),   QStringLiteral("SET_ACTIVITY"));
    cmd.insert(QStringLiteral("args"),  args);
    cmd.insert(QStringLiteral("nonce"), QUuid::createUuid().toString(QUuid::WithoutBraces));

    sendFrame(OpFrame, QJsonDocument(cmd).toJson(QJsonDocument::Compact));
}

void DiscordRPC::setPresence(const QString& details, const QString& state)
{
    m_details = details;
    m_state = state;
    pushPresence();
}

void DiscordRPC::setPlaying(const QString& clientName)
{
    m_details = clientName.isEmpty() ? QStringLiteral("В игре")
                                     : QStringLiteral("Играет: ") + clientName;
    m_state.clear();
    pushPresence();
}

void DiscordRPC::setIdle()
{
    m_details = QStringLiteral("В лаунчере");
    m_state.clear();
    pushPresence();
}
