#pragma once

#include <QString>

namespace ClientInstall {

QString installExtractedClient(const QString& finalDir, const QString& stagingDir);

}
