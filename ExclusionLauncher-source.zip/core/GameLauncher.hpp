#pragma once

#include <QFutureWatcher>
#include <QObject>
#include <QPointer>
#include <QProcess>
#include <QString>
#include <QStringList>
#include <QTimer>
#include <QVariantMap>

#include <atomic>
#include <memory>

#include <QNetworkAccessManager>

class SettingsManager;
class McAssets;
class InstalledStore;
class RuntimeManager;
class ServerSync;
class IntegrityChecker;
class ClientVerifier;

class GameLauncher final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool running READ running NOTIFY stateChanged)
    Q_PROPERTY(QString runningClientId READ runningClientId NOTIFY stateChanged)
    Q_PROPERTY(QString statusText READ statusText NOTIFY stateChanged)
    Q_PROPERTY(QString lastError READ lastError NOTIFY errorChanged)


    Q_PROPERTY(bool preparing READ preparing NOTIFY progressChanged)
    Q_PROPERTY(double progress READ progress NOTIFY progressChanged)
    Q_PROPERTY(QString stageText READ stageText NOTIFY progressChanged)
    Q_PROPERTY(QString preparingClientId READ preparingClientId NOTIFY progressChanged)

public:
    explicit GameLauncher(SettingsManager* settings, InstalledStore* installed,
                          RuntimeManager* runtimes, QObject* parent = nullptr);


    bool running() const {
        for (const auto& p : m_games)
            if (p && p->state() != QProcess::NotRunning) return true;
        return false;
    }
    QString runningClientId() const { return m_runningClientId; }
    QString statusText() const { return m_statusText; }
    QString lastError() const { return m_lastError; }
    bool preparing() const { return m_preparing; }
    double progress() const { return m_progress; }
    QString stageText() const { return m_stageText; }
    QString preparingClientId() const { return m_preparingClientId; }


    void setBlocker(IntegrityChecker* blocker) { m_blocker = blocker; }


    void setServerSync(ServerSync* sync) { m_serverSync = sync; }


    void setVerifier(ClientVerifier* verifier);


    Q_INVOKABLE void launch(const QVariantMap& client);


    void launchVerified(const QVariantMap& client);



    Q_INVOKABLE void cancelPreparing();
    Q_INVOKABLE void terminate();


    ~GameLauncher() override;
    Q_INVOKABLE void clearError();



    Q_INVOKABLE QString resolveJavaExe() const;

signals:
    void stateChanged();
    void progressChanged();

    void gameStarted(const QString& id);



    void gameWindowReady(const QString& id);
    void errorChanged();
    void gameFinished(const QString& id, int exitCode);




    void reinstallRequired(const QVariantMap& client);

private:
    struct RunSpec {
        QString type;
        QString mcVersion;
        QString assetIndex;
        QString mainClass;
        QStringList jvmFlags;
        QStringList classpath;
        QStringList gameArgs;
        QString requiredRuntimeId;
        int requiredJdk = 0;





        QString mcRuntimeId;






        QStringList preCreateDirs;
    };





    void startComposite(const QString& javaExe,
                        const QString& clientDir,
                        const QString& runtimeDir,
                        const RunSpec& runtimeSpec,
                        const RunSpec& clientSpec,
                        const QString& username);



    void runComposite(const QString& javaExe,
                      const QString& clientDir,
                      const QString& runtimeDir,
                      const RunSpec& runtimeSpec,
                      const RunSpec& clientSpec,
                      const QString& username);


    void launchComposite(const QString& javaExe,
                         const QString& clientDir,
                         const QString& runtimeDir,
                         const RunSpec& runtimeSpec,
                         const RunSpec& clientSpec,
                         const QString& username,
                         const QString& assetsDir);




    void prepareGameDirAsync(const QString& javaExe,
                             const QString& clientDir,
                             const QString& runtimeDir,
                             const RunSpec& runtimeSpec,
                             const RunSpec& clientSpec,
                             const QString& username);


    bool readSpec(const QString& clientDir, RunSpec& out, QString* err) const;


    QString substitute(QString s,
                       const QString& pkgRoot,
                       const QString& gameDir,
                       const QString& assetsDir,
                       const QString& username,
                       const QString& uuid) const;


    void startProcess(const QString& javaExe,
                      const QString& clientDir,
                      const RunSpec& spec,
                      const QString& username);



    void applyUserPrefs(QStringList& jvmArgs, QStringList& gameArgs) const;




    void shareGameData(const QString& gameDir);

signals:
    // для AdSessionTracker: pid процесса игры (старт/выход)
    void gameProcessStarted(quint64 pid);
    void gameProcessEnded(quint64 pid);

public:
    void collectGameData(const QString& gameDir);







    void enforceNickname(const QString& gameDir, const QString& username);




    void startWindowBranding();
    void stopWindowBranding();
    void applyWindowBranding();



    void pollGameLog();

    void setStatus(const QString& t);



    void setStage(const QString& text, double progress);
    void endPreparing();

    void fail(const QString& msg);

    void reportLaunch(const QString& clientId);


    void onProcessFinished(QProcess* p, const QString& id, int code);

    SettingsManager* m_settings = nullptr;
    InstalledStore* m_installed = nullptr;
    RuntimeManager* m_runtimes = nullptr;
    McAssets* m_mcAssets = nullptr;
    IntegrityChecker* m_blocker = nullptr;
    ServerSync* m_serverSync = nullptr;
    ClientVerifier* m_verifier = nullptr;
    QNetworkAccessManager m_network;
    QPointer<QProcess> m_process;
    QList<QPointer<QProcess>> m_games;
    QString m_runningClientId;

    QString m_runningClientName;
    QTimer m_brandTimer;
    bool m_gameWindowSeen = false;
    QString m_gameLogPath;
    qint64 m_gameLogPos = 0;
    QString m_statusText;
    QString m_lastError;

    bool m_preparing = false;
    double m_progress = 0.0;
    QString m_stageText;
    QString m_preparingClientId;

    double m_stageFrom = 0.0;
    double m_stageTo = 0.0;


    QString m_pendingRuntimeId;
    QString m_pendingClientDir;
    QString m_pendingUsername;
    RunSpec m_pendingSpec;
    QVariantMap m_pendingClient;
    QVariantMap m_verifyingClient;



    QFutureWatcher<QString> m_prepWatcher;
    QTimer m_prepTicker;
    std::shared_ptr<std::atomic<int>> m_prepDone;
    std::shared_ptr<std::atomic<int>> m_prepTotal;
};
