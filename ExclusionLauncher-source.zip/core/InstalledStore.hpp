#pragma once

#include <QObject>
#include <QJsonObject>
#include <QString>

class InstalledStore final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(int revision READ revision NOTIFY changed)

public:
    explicit InstalledStore(QObject* parent = nullptr);

    int revision() const { return m_revision; }

    Q_INVOKABLE bool isInstalled(const QString& id) const;
    Q_INVOKABLE QString installedVersion(const QString& id) const;
    QString installedSha(const QString& id) const;
    QString installedPackageUrl(const QString& id) const;


    Q_INVOKABLE bool needsUpdate(const QString& id, const QString& sha256,
                                  const QString& packageUrl = QString()) const;

    void markInstalled(const QString& id, const QString& version,
                       const QString& sha256 = QString(),
                       const QString& packageUrl = QString());
    void remove(const QString& id);


    QStringList allIds() const { return m_clients.keys(); }

signals:
    void changed();

private:
    void load();
    void save() const;

    QJsonObject m_clients;
    int m_revision = 0;
};
