#include "IntegrityChecker.hpp"

#include "ClientVerifier.hpp"
#include "InstalledStore.hpp"
#include "SettingsManager.hpp"

#include <QDebug>
#include <QDir>
#include <QMetaObject>
#include <QTimer>
#include <QtConcurrent>

IntegrityChecker::IntegrityChecker(SettingsManager* settings, InstalledStore* installed,
                                   QObject* parent)
    : QObject(parent), m_settings(settings), m_installed(installed),
      m_cancelRequested(std::make_shared<std::atomic_bool>(false)),
      m_filesDone(std::make_shared<std::atomic<int>>(0))
{
    connect(&m_watcher, &QFutureWatcher<Result>::finished,
            this, &IntegrityChecker::onScanFinished);
}

IntegrityChecker::~IntegrityChecker()
{

    m_cancelRequested->store(true);
    m_watcher.disconnect(this);
    if (m_watcher.isRunning())
        m_watcher.waitForFinished();
}

void IntegrityChecker::start()
{
    if (m_busy) return;

    m_busy = true;
    m_hasResult = false;
    m_badClients = 0;
    m_progress = 0.0;
    m_cancelRequested->store(false);
    m_filesDone->store(0);
    m_statusText = tr("Проверка целостности…");
    emit stateChanged();
    emit progressChanged();

    m_watcher.setFuture(QtConcurrent::run([this] { return runScan(); }));
}

void IntegrityChecker::cancel()
{
    if (!m_busy) return;
    m_cancelRequested->store(true);
}

IntegrityChecker::Result IntegrityChecker::runScan()
{
    Result res;
    if (!m_settings || !m_installed) return res;

    const QStringList ids = m_installed->allIds();
    const QString rootDir = m_settings->installDir();



    QList<QPair<QString, QString>> targets;
    int totalFiles = 0;
    for (const QString& id : ids) {
        const QString clientDir = QDir(rootDir).filePath(id);
        if (!QFileInfo(clientDir).isDir()) {


            res.bad << id;
            res.reasons << tr("папка клиента отсутствует");
            continue;
        }
        if (!ClientVerifier::hasManifest(clientDir)) {


            res.bad << id;
            res.reasons << tr("нет слепка файлов");
            continue;
        }
        totalFiles += ClientVerifier::countPackageFiles(clientDir);
        targets.append({id, clientDir});
    }
    res.total = ids.size();

    auto bump = [this, totalFiles] {
        const int done = m_filesDone->load(std::memory_order_relaxed);
        const double p = totalFiles > 0 ? double(done) / double(totalFiles) : 1.0;

        QMetaObject::invokeMethod(this, [this, p] {
            m_progress = qBound(0.0, p, 1.0);
            emit progressChanged();
        }, Qt::QueuedConnection);
    };

    for (const auto& [id, clientDir] : targets) {
        if (m_cancelRequested->load()) { res.cancelled = true; return res; }

        const QString problem = ClientVerifier::checkClient(clientDir, m_filesDone.get(),
                                                           m_cancelRequested.get());
        if (m_cancelRequested->load()) { res.cancelled = true; return res; }
        if (!problem.isEmpty()) {
            res.bad << id;
            res.reasons << problem;
        }
        bump();
    }

    return res;
}

void IntegrityChecker::onScanFinished()
{
    const Result res = m_watcher.result();

    m_busy = false;
    m_progress = 1.0;
    m_badClients = res.bad.size();
    m_hasResult = !res.cancelled;

    if (res.cancelled)
        m_statusText = tr("Проверка отменена");
    else if (res.total == 0)
        m_statusText = tr("Нечего проверять — клиенты не установлены");
    else if (res.bad.isEmpty())
        m_statusText = tr("Все клиенты целы (%1)").arg(res.total);
    else
        m_statusText = tr("Повреждено клиентов: %1 из %2 — переустанавливаем")
                           .arg(res.bad.size()).arg(res.total);

    emit progressChanged();
    emit stateChanged();

    if (res.cancelled) return;

    for (int i = 0; i < res.bad.size(); ++i)
        qWarning() << "[integrity] повреждён клиент:" << res.bad.at(i) << res.reasons.value(i);

    emit finished(res.bad.size(), res.total);



    if (!res.bad.isEmpty()) {
        const QStringList bad = res.bad;
        QTimer::singleShot(0, this, [this, bad] { emit repairRequired(bad); });
    }
}
