#include "ArchiveManager.hpp"

#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QProcess>

namespace {

struct ArcKind {
    bool isTar = false, isTarXz = false, isTarGz = false, isZip = false;
};

ArcKind classify(const QString& path)
{
    const QString l = path.toLower();
    ArcKind k;
    k.isTarXz = l.endsWith(QStringLiteral(".tar.xz")) || l.endsWith(QStringLiteral(".txz"));
    k.isTarGz = l.endsWith(QStringLiteral(".tar.gz")) || l.endsWith(QStringLiteral(".tgz"));
    k.isTar   = l.endsWith(QStringLiteral(".tar")) || k.isTarXz || k.isTarGz;
    k.isZip   = l.endsWith(QStringLiteral(".zip"));
    return k;
}



QString intermediateTar(const QString& archivePath, const QString& dir)
{
    const QString base = QFileInfo(archivePath).fileName();
    QString name;
    const QString l = base.toLower();
    if (l.endsWith(QStringLiteral(".txz")) || l.endsWith(QStringLiteral(".tgz")))
        name = base.left(base.size() - 4) + QStringLiteral(".tar");
    else
        name = QFileInfo(base).completeBaseName();
    return QDir(dir).filePath(name);
}

}

ArchiveManager::ArchiveManager(QObject* parent) : QObject(parent)
{
    connect(&m_process, &QProcess::finished, this,
            [this](int exitCode, QProcess::ExitStatus status) {
        if (m_canceling)
            return;
        const bool ok = (status == QProcess::NormalExit && exitCode == 0);

        if (ok && !m_pendingTar.isEmpty()) {
            const QString tarFile = m_pendingTar;
            const QString dest    = m_pendingDest;
            m_pendingTar.clear();
            m_pendingDest.clear();
            const QString za = bundled7zaPath();
            m_secondStepTar = tarFile;
            m_process.start(za, {QStringLiteral("x"), QStringLiteral("-y"),
                                 tarFile, QStringLiteral("-o") + dest});
            return;
        }


        if (!m_secondStepTar.isEmpty()) {
            QFile::remove(m_secondStepTar);
            m_secondStepTar.clear();
        }

        if (ok) {
            m_fallbackArc.clear();
            m_fallbackDest.clear();
            m_usingFallback = false;
            emitDone(true, {});
            return;
        }




        m_pendingTar.clear();
        m_pendingDest.clear();
        QString err = QString::fromLocal8Bit(m_process.readAllStandardError());
        if (err.isEmpty())
            err = QString::fromLocal8Bit(m_process.readAllStandardOutput());

        if (!m_usingFallback && startFallbackExtract())
            return;

        m_fallbackArc.clear();
        m_fallbackDest.clear();
        m_usingFallback = false;
        emitDone(false, err.isEmpty() ? QStringLiteral("Ошибка распаковки архива.") : err);
    });
}



bool ArchiveManager::startFallbackExtract()
{
#ifdef Q_OS_WIN
    if (m_fallbackArc.isEmpty()) return false;
    const QString arc = m_fallbackArc;
    const QString dst = m_fallbackDest;

    const QString za  = bundled7zaPath();
    const QString tar = systemTarPath();



    const bool firstWas7za = !za.isEmpty();

    m_usingFallback = true;
    m_secondStepTar.clear();
    m_pendingTar.clear();
    m_pendingDest.clear();

    if (firstWas7za) {
        if (tar.isEmpty()) return false;

        m_process.start(tar, {QStringLiteral("-xf"), arc, QStringLiteral("-C"), dst});
        return m_process.waitForStarted(3000) || m_process.state() != QProcess::NotRunning;
    }

    if (za.isEmpty()) return false;
    const ArcKind k = classify(arc);
    if (k.isTarXz || k.isTarGz) {
        const QString workDir = QFileInfo(arc).absolutePath();
        m_pendingTar  = intermediateTar(arc, workDir);
        m_pendingDest = dst;
        m_process.start(za, {QStringLiteral("x"), QStringLiteral("-y"),
                             arc, QStringLiteral("-o") + workDir});
    } else {
        m_process.start(za, {QStringLiteral("x"), QStringLiteral("-y"),
                             arc, QStringLiteral("-o") + dst});
    }
    return m_process.waitForStarted(3000) || m_process.state() != QProcess::NotRunning;
#else
    return false;
#endif
}

bool ArchiveManager::startPipeExtract(const QString& za, const QString& arc, const QString& dst)
{
#ifdef Q_OS_WIN
    m_pendingTar.clear();
    m_pendingDest.clear();
    m_secondStepTar.clear();

    destroyPipe();
    m_pipeConsumer = new QProcess(this);
    m_pipeProducer = new QProcess(this);

    connect(m_pipeProducer, &QProcess::readyReadStandardOutput, this, [this] {
        if (!m_pipeConsumer || !m_pipeProducer) return;
        const QByteArray chunk = m_pipeProducer->readAllStandardOutput();
        if (!chunk.isEmpty()) m_pipeConsumer->write(chunk);
        if (m_pipeConsumer->bytesToWrite() > (256 << 20))
            m_pipeConsumer->waitForBytesWritten(30000);
    });
    connect(m_pipeProducer, &QProcess::finished, this,
            [this](int, QProcess::ExitStatus) {
        if (!m_pipeConsumer || !m_pipeProducer) return;
        const QByteArray tail = m_pipeProducer->readAllStandardOutput();
        if (!tail.isEmpty()) m_pipeConsumer->write(tail);
        m_pipeConsumer->closeWriteChannel();
    });
    connect(m_pipeConsumer, &QProcess::finished, this, &ArchiveManager::onPipeFinished);

    m_pipeConsumer->start(za, {QStringLiteral("x"), QStringLiteral("-y"),
                               QStringLiteral("-si"), QStringLiteral("-ttar"),
                               QStringLiteral("-o") + dst});
    if (!m_pipeConsumer->waitForStarted(4000)) { destroyPipe(); return false; }
    m_pipeProducer->start(za, {QStringLiteral("x"), QStringLiteral("-y"),
                               QStringLiteral("-so"), arc});
    if (!m_pipeProducer->waitForStarted(4000)) { destroyPipe(); return false; }
    return true;
#else
    Q_UNUSED(za); Q_UNUSED(arc); Q_UNUSED(dst);
    return false;
#endif
}

void ArchiveManager::onPipeFinished(int exitCode, QProcess::ExitStatus status)
{
    if (m_canceling)
        return;
    const bool consumerOk = (status == QProcess::NormalExit && exitCode == 0);
    if (m_pipeProducer)
        m_pipeProducer->waitForFinished(4000);
    const bool producerOk = m_pipeProducer
                            && m_pipeProducer->exitStatus() == QProcess::NormalExit
                            && m_pipeProducer->exitCode() == 0;
    QString err = m_pipeProducer
                      ? QString::fromLocal8Bit(m_pipeProducer->readAllStandardError())
                      : QString();
    destroyPipe();

    if (consumerOk && producerOk) {
        m_fallbackArc.clear();
        m_fallbackDest.clear();
        m_usingFallback = false;
        emitDone(true, {});
        return;
    }
    if (!m_usingFallback && startTwoStep7za())
        return;
    if (!m_usingFallback && startFallbackExtract())
        return;
    m_fallbackArc.clear();
    m_fallbackDest.clear();
    m_usingFallback = false;
    emitDone(false, err.isEmpty() ? QStringLiteral("Ошибка потоковой распаковки.") : err);
}

void ArchiveManager::destroyPipe()
{
    if (m_pipeProducer) {
        m_pipeProducer->disconnect(this);
        if (m_pipeProducer->state() != QProcess::NotRunning) {
            m_pipeProducer->kill();
            m_pipeProducer->waitForFinished(3000);
        }
        m_pipeProducer->deleteLater();
        m_pipeProducer = nullptr;
    }
    if (m_pipeConsumer) {
        m_pipeConsumer->disconnect(this);
        if (m_pipeConsumer->state() != QProcess::NotRunning) {
            m_pipeConsumer->kill();
            m_pipeConsumer->waitForFinished(3000);
        }
        m_pipeConsumer->deleteLater();
        m_pipeConsumer = nullptr;
    }
}

bool ArchiveManager::startTwoStep7za()
{
#ifdef Q_OS_WIN
    const QString za = bundled7zaPath();
    if (za.isEmpty() || m_fallbackArc.isEmpty()) return false;
    const ArcKind k = classify(m_fallbackArc);
    if (!(k.isTarXz || k.isTarGz)) return false;

    const QString workDir = QFileInfo(m_fallbackArc).absolutePath();
    m_pendingTar  = intermediateTar(m_fallbackArc, workDir);
    m_pendingDest = m_fallbackDest;
    m_process.start(za, {QStringLiteral("x"), QStringLiteral("-y"),
                         m_fallbackArc, QStringLiteral("-o") + workDir});
    if (m_process.waitForStarted(3000) || m_process.state() != QProcess::NotRunning)
        return true;
    m_pendingTar.clear();
    m_pendingDest.clear();
    return false;
#else
    return false;
#endif
}

void ArchiveManager::cancel()
{
    m_canceling = true;

    destroyPipe();
    if (m_process.state() != QProcess::NotRunning) {
        m_process.kill();
        m_process.waitForFinished(3000);
    }

    if (!m_pendingTar.isEmpty())    QFile::remove(m_pendingTar);
    if (!m_secondStepTar.isEmpty()) QFile::remove(m_secondStepTar);
    m_pendingTar.clear();
    m_pendingDest.clear();
    m_secondStepTar.clear();
    m_fallbackArc.clear();
    m_fallbackDest.clear();
    m_usingFallback = false;
    m_canceling = false;
}

void ArchiveManager::emitDone(bool ok, const QString& error)
{
    emit finished(ok, error);
}

void ArchiveManager::runProcess(const QString& program, const QStringList& args)
{
    m_process.start(program, args);
}

QString ArchiveManager::systemTarPath()
{
#ifdef Q_OS_WIN
    QString sysroot = QString::fromLocal8Bit(qgetenv("SystemRoot"));
    if (sysroot.isEmpty()) sysroot = QStringLiteral("C:/Windows");
    const QString p = QDir(sysroot).filePath(QStringLiteral("System32/tar.exe"));
    return QFileInfo::exists(p) ? QDir::toNativeSeparators(p) : QString();
#else
    return QStringLiteral("tar");
#endif
}

QString ArchiveManager::bundled7zaPath()
{
    const QString p = QDir(QCoreApplication::applicationDirPath())
                          .filePath(QStringLiteral("7za.exe"));
    return QFileInfo::exists(p) ? QDir::toNativeSeparators(p) : QString();
}

void ArchiveManager::extractArchive(const QString& archivePath, const QString& destination)
{
    if (m_process.state() != QProcess::NotRunning) {
        emit finished(false, QStringLiteral("Распаковка уже выполняется."));
        return;
    }

    QDir().mkpath(destination);
    m_pendingTar.clear();
    m_pendingDest.clear();
    m_secondStepTar.clear();
    m_fallbackArc.clear();
    m_fallbackDest.clear();
    m_usingFallback = false;

    const ArcKind k = classify(archivePath);

#ifdef Q_OS_WIN
    const QString safeArc = QDir::toNativeSeparators(QFileInfo(archivePath).absoluteFilePath());
    const QString safeDst = QDir::toNativeSeparators(QFileInfo(destination).absoluteFilePath());

    if (k.isZip) {

        QString a = safeArc; a.replace(QLatin1Char('\''), QStringLiteral("''"));
        QString d = safeDst; d.replace(QLatin1Char('\''), QStringLiteral("''"));
        const QString command = QStringLiteral(
            "Expand-Archive -LiteralPath '%1' -DestinationPath '%2' -Force").arg(a, d);
        runProcess(QStringLiteral("powershell.exe"),
                   {QStringLiteral("-NoProfile"), QStringLiteral("-NonInteractive"),
                    QStringLiteral("-Command"), command});
        return;
    }

    if (k.isTar) {







        m_fallbackArc  = safeArc;
        m_fallbackDest = safeDst;
        const QString za = bundled7zaPath();
        if (!za.isEmpty()) {
            if (k.isTarXz || k.isTarGz) {
                // Быстрый путь — потоковая распаковка без промежуточного .tar.
                if (startPipeExtract(za, safeArc, safeDst))
                    return;
                // Не удалось запустить pipe — прежний двухшаговый способ.
                const QString workDir = QFileInfo(safeArc).absolutePath();
                m_pendingTar  = intermediateTar(safeArc, workDir);
                m_pendingDest = safeDst;
                runProcess(za, {QStringLiteral("x"), QStringLiteral("-y"),
                                safeArc, QStringLiteral("-o") + workDir});
            } else {
                runProcess(za, {QStringLiteral("x"), QStringLiteral("-y"),
                                safeArc, QStringLiteral("-o") + safeDst});
            }
            return;
        }

        const QString sysTar = systemTarPath();
        if (!sysTar.isEmpty()) {
            runProcess(sysTar, {QStringLiteral("-xf"), safeArc,
                                QStringLiteral("-C"), safeDst});
            return;
        }
        emit finished(false, QStringLiteral(
            "Не найден распаковщик: нет ни 7za.exe рядом с лаунчером, ни tar.exe."));
        return;
    }
#else
    if (k.isTar) {
        runProcess(QStringLiteral("tar"), {QStringLiteral("-xf"), archivePath,
                                           QStringLiteral("-C"), destination});
        return;
    }
    if (k.isZip) {
        runProcess(QStringLiteral("unzip"), {QStringLiteral("-o"), archivePath,
                                             QStringLiteral("-d"), destination});
        return;
    }
#endif

    emit finished(false, QStringLiteral("Неизвестный формат архива: ") + archivePath);
}



bool ArchiveManager::extractSync(const QString& archivePath, const QString& destination,
                                 QString* err)
{
    auto setErr = [&](const QString& e) { if (err) *err = e; };
    QDir().mkpath(destination);

    const ArcKind k = classify(archivePath);
    const QString arc = QDir::toNativeSeparators(QFileInfo(archivePath).absoluteFilePath());
    const QString dst = QDir::toNativeSeparators(QFileInfo(destination).absoluteFilePath());

    auto runSync = [](const QString& prog, const QStringList& args) -> bool {
        QProcess p;
        p.start(prog, args);
        if (!p.waitForStarted(-1)) return false;
        p.waitForFinished(-1);
        return p.exitStatus() == QProcess::NormalExit && p.exitCode() == 0;
    };

#ifdef Q_OS_WIN
    if (k.isZip) {
        QString a = arc; a.replace(QLatin1Char('\''), QStringLiteral("''"));
        QString d = dst; d.replace(QLatin1Char('\''), QStringLiteral("''"));
        const QString cmd = QStringLiteral(
            "Expand-Archive -LiteralPath '%1' -DestinationPath '%2' -Force").arg(a, d);
        if (runSync(QStringLiteral("powershell.exe"),
                    {QStringLiteral("-NoProfile"), QStringLiteral("-NonInteractive"),
                     QStringLiteral("-Command"), cmd}))
            return true;
        setErr(QStringLiteral("Expand-Archive не справился."));
        return false;
    }

    if (k.isTar) {




        const QString za = bundled7zaPath();
        if (!za.isEmpty()) {
            bool ok;
            if (k.isTarXz || k.isTarGz) {
                const QString workDir = QFileInfo(arc).absolutePath();
                ok = runSync(za, {QStringLiteral("x"), QStringLiteral("-y"), arc,
                                  QStringLiteral("-o") + workDir});
                if (ok) {
                    const QString tarFile = intermediateTar(arc, workDir);
                    ok = runSync(za, {QStringLiteral("x"), QStringLiteral("-y"),
                                      tarFile, QStringLiteral("-o") + dst});
                    QFile::remove(tarFile);
                }
            } else {
                ok = runSync(za, {QStringLiteral("x"), QStringLiteral("-y"), arc,
                                  QStringLiteral("-o") + dst});
            }
            if (ok) return true;

        }

        const QString sysTar = systemTarPath();
        if (!sysTar.isEmpty() &&
            runSync(sysTar, {QStringLiteral("-xf"), arc, QStringLiteral("-C"), dst}))
            return true;

        setErr(QStringLiteral("Не удалось распаковать: ни 7za, ни tar не сработали."));
        return false;
    }
#else
    if (k.isTar) {
        if (runSync(QStringLiteral("tar"), {QStringLiteral("-xf"), arc,
                                            QStringLiteral("-C"), dst}))
            return true;
        setErr(QStringLiteral("tar не справился."));
        return false;
    }
    if (k.isZip) {
        if (runSync(QStringLiteral("unzip"), {QStringLiteral("-o"), arc,
                                              QStringLiteral("-d"), dst}))
            return true;
        setErr(QStringLiteral("unzip не справился."));
        return false;
    }
#endif

    setErr(QStringLiteral("Неизвестный формат архива: ") + archivePath);
    return false;
}
