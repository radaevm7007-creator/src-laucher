#include "GameLauncher.hpp"

#include "HardwareId.hpp"

#include "AppConfig.hpp"
#include "AppPaths.hpp"
#include "ClientVerifier.hpp"
#include "InstalledStore.hpp"
#include "IntegrityChecker.hpp"
#include "JavaLaunch.hpp"
#include "RuntimeManager.hpp"
#include "McAssets.hpp"
#include "ServerSync.hpp"
#include "SettingsManager.hpp"

#include <algorithm>

#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkReply>
#include <QNetworkRequest>

#include <QCryptographicHash>
#include <QDir>
#include <QDirIterator>
#include <QDateTime>
#include <QFile>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QSet>
#include <QJsonValue>
#include <QCoreApplication>
#include <QProcessEnvironment>
#include <QRandomGenerator>
#include <QStandardPaths>
#include <QTextStream>
#include <QtConcurrent>

#ifdef Q_OS_WIN
#include <windows.h>
#endif



namespace {


QString offlineUuidFor(const QString& nickname)
{
    const QByteArray data = ("OfflinePlayer:" + nickname).toUtf8();
    QByteArray md5 = QCryptographicHash::hash(data, QCryptographicHash::Md5);
    md5[6] = (md5[6] & 0x0F) | 0x30;
    md5[8] = (md5[8] & 0x3F) | 0x80;
    const QString hex = md5.toHex();
    return QString("%1-%2-%3-%4-%5")
        .arg(hex.mid(0, 8), hex.mid(8, 4), hex.mid(12, 4),
             hex.mid(16, 4), hex.mid(20, 12));
}





bool copyDirRecursive(const QString& from, const QString& to, QString* err = nullptr,
                      std::atomic<int>* counter = nullptr)
{
    QDir src(from);
    if (!src.exists()) {
        if (err) *err = QStringLiteral("нет папки ") + from;
        return false;
    }
    if (!QDir().mkpath(to)) {
        if (err) *err = QStringLiteral("не создать ") + to;
        return false;
    }

    for (const QFileInfo& fi : src.entryInfoList(QDir::Files | QDir::Dirs | QDir::NoDotAndDotDot)) {
        const QString dst = QDir(to).filePath(fi.fileName());
        if (fi.isDir()) {
            if (!copyDirRecursive(fi.absoluteFilePath(), dst, err, counter)) return false;
        } else {
            QFile::remove(dst);
            if (!QFile::copy(fi.absoluteFilePath(), dst)) {
                if (err) *err = QStringLiteral("не скопировать ") + fi.absoluteFilePath();
                return false;
            }
            if (counter) counter->fetch_add(1, std::memory_order_relaxed);
        }
    }
    return true;
}


int countFilesRecursive(const QString& dir)
{
    int n = 0;
    for (const QFileInfo& fi : QDir(dir).entryInfoList(QDir::Files | QDir::Dirs | QDir::NoDotAndDotDot))
        n += fi.isDir() ? countFilesRecursive(fi.absoluteFilePath()) : 1;
    return n;
}

bool syncClientModsIntoGame(const QString& clientDir, const QString& gameDir, QString* err = nullptr)
{
    const QString cliMods = QDir(clientDir).filePath(QStringLiteral("mods"));
    const QString dstMods = QDir(gameDir).filePath(QStringLiteral("mods"));

    if (!QDir().mkpath(dstMods)) {
        if (err) *err = QStringLiteral("не создать ") + dstMods;
        return false;
    }

    if (!QFileInfo::exists(cliMods))
        return true;

    if (!copyDirRecursive(cliMods, dstMods, err))
        return false;

    const int modCount = countFilesRecursive(cliMods);
    if (modCount > 0 && QDir(dstMods).entryInfoList(QDir::Files | QDir::Dirs | QDir::NoDotAndDotDot).isEmpty()) {
        if (err) *err = QStringLiteral("моды клиента не попали в ") + dstMods;
        return false;
    }

    return true;
}

#ifdef Q_OS_WIN



HICON launcherIcon()
{
    static HICON icon = [] {
        const QString exe = QDir::toNativeSeparators(QCoreApplication::applicationFilePath());
        return ExtractIconW(GetModuleHandleW(nullptr),
                            reinterpret_cast<const wchar_t*>(exe.utf16()), 0);
    }();
    return (icon && icon != reinterpret_cast<HICON>(1)) ? icon : nullptr;
}

struct BrandContext {
    DWORD pid = 0;
    const wchar_t* title = nullptr;
    HICON icon = nullptr;
    bool found = false;
};



QString g_brandTitle;
DWORD g_brandPid = 0;
HWINEVENTHOOK g_nameHook = nullptr;

BOOL CALLBACK brandWindowProc(HWND hwnd, LPARAM param)
{
    auto* ctx = reinterpret_cast<BrandContext*>(param);

    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    if (pid != ctx->pid) return TRUE;



    if (GetWindow(hwnd, GW_OWNER) != nullptr) return TRUE;
    if (!IsWindowVisible(hwnd)) return TRUE;

    wchar_t current[512] = {};
    if (GetWindowTextW(hwnd, current, 512) <= 0) return TRUE;

    ctx->found = true;



    if (wcscmp(current, ctx->title) != 0)
        SetWindowTextW(hwnd, ctx->title);

    if (ctx->icon) {
        SendMessageW(hwnd, WM_SETICON, ICON_BIG,   reinterpret_cast<LPARAM>(ctx->icon));
        SendMessageW(hwnd, WM_SETICON, ICON_SMALL, reinterpret_cast<LPARAM>(ctx->icon));
    }
    return TRUE;
}





void CALLBACK nameChangeProc(HWINEVENTHOOK, DWORD event, HWND hwnd,
                             LONG idObject, LONG, DWORD, DWORD)
{
    if (event != EVENT_OBJECT_NAMECHANGE || idObject != OBJID_WINDOW || !hwnd) return;

    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    if (pid != g_brandPid || g_brandTitle.isEmpty()) return;
    if (GetWindow(hwnd, GW_OWNER) != nullptr) return;

    wchar_t current[512] = {};
    if (GetWindowTextW(hwnd, current, 512) <= 0) return;

    const wchar_t* want = reinterpret_cast<const wchar_t*>(g_brandTitle.utf16());


    if (wcscmp(current, want) == 0) return;

    SetWindowTextW(hwnd, want);
}
#endif




bool ensureSharedDir(const QString& linkPath, const QString& sharedPath, QString* err = nullptr)
{
    QDir().mkpath(sharedPath);

    const QFileInfo li(linkPath);
    if (li.isSymLink() || li.isJunction()) return true;

    if (li.isDir()) {
        QDir local(linkPath);
        const auto entries = local.entryInfoList(QDir::Files | QDir::Dirs | QDir::NoDotAndDotDot);
        for (const QFileInfo& fi : entries) {
            const QString dst = QDir(sharedPath).filePath(fi.fileName());
            if (QFileInfo::exists(dst)) continue;
            QDir().rename(fi.absoluteFilePath(), dst);
        }
        if (!local.removeRecursively()) {
            if (err) *err = QStringLiteral("не удалось убрать локальную папку ") + linkPath;
            return false;
        }
    }

#ifdef Q_OS_WIN

    const int rc = QProcess::execute(QStringLiteral("cmd"), {
        QStringLiteral("/c"), QStringLiteral("mklink"), QStringLiteral("/J"),
        QDir::toNativeSeparators(linkPath), QDir::toNativeSeparators(sharedPath)
    });
    if (rc != 0) {
        if (err) *err = QStringLiteral("mklink вернул ") + QString::number(rc);
        return false;
    }
    return true;
#else
    return QFile::link(sharedPath, linkPath);
#endif
}

QString firstExistingFile(const QStringList& paths)
{
    for (const auto& p : paths) if (!p.isEmpty() && QFileInfo::exists(p)) return p;
    return {};
}

QString quoteArgForLog(const QString& arg)
{
    QString s = arg;
    s.replace(QLatin1Char('"'), QStringLiteral("\\\""));
    return s.contains(QLatin1Char(' ')) ? QStringLiteral("\"") + s + QStringLiteral("\"") : s;
}

void appendTextFileTail(QTextStream& out, const QString& path, qint64 maxBytes)
{
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly)) {
        out << "\n[launcher] не удалось прочитать файл: " << path << "\n";
        return;
    }
    const qint64 start = qMax<qint64>(0, f.size() - maxBytes);
    if (start > 0) {
        f.seek(start);
        f.readLine();
    }
    out << "\n----- " << path << " -----\n";
    out << QString::fromUtf8(f.readAll());
    out << "\n----- end -----\n";
}

void appendLaunchLogHeader(const QString& logPath,
                           const QString& clientId,
                           const QString& javaExe,
                           const QString& workDir,
                           const QStringList& args,
                           const QStringList& removedJavaEnv = {})
{
    QDir().mkpath(QFileInfo(logPath).absolutePath());
    QFile f(logPath);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text))
        return;

    QTextStream out(&f);
    out << "\n========== launch "
        << QDateTime::currentDateTime().toString(QStringLiteral("yyyy-MM-dd HH:mm:ss"))
        << " ==========\n";
    out << "[launcher] client: " << clientId << "\n";
    out << "[launcher] java: " << javaExe << "\n";
    out << "[launcher] workdir: " << workDir << "\n";
    out << "[launcher] command: " << quoteArgForLog(javaExe);
    for (const QString& arg : args)
        out << ' ' << quoteArgForLog(arg);
    out << "\n\n";
    if (!removedJavaEnv.isEmpty())
        out << "[launcher] removed Java env vars: " << removedJavaEnv.join(QStringLiteral(", ")) << "\n\n";
}

void appendLauncherLogLine(const QString& logPath, const QString& line)
{
    QDir().mkpath(QFileInfo(logPath).absolutePath());
    QFile f(logPath);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text))
        return;
    QTextStream out(&f);
    out << "[launcher] " << line << "\n";
}

void appendCrashDiagnostics(const QString& logPath,
                            const QString& clientRoot,
                            const QString& gameDir)
{
    QDir().mkpath(QFileInfo(logPath).absolutePath());
    QFile f(logPath);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text))
        return;

    QTextStream out(&f);
    out << "\n========== crash diagnostics "
        << QDateTime::currentDateTime().toString(QStringLiteral("yyyy-MM-dd HH:mm:ss"))
        << " ==========\n";

    QVector<QFileInfo> reports;
    const QString crashDir = QDir(gameDir).filePath(QStringLiteral("crash-reports"));
    QDirIterator crashIt(crashDir, QStringList{QStringLiteral("crash-*.txt")},
                         QDir::Files, QDirIterator::NoIteratorFlags);
    while (crashIt.hasNext()) {
        crashIt.next();
        reports << crashIt.fileInfo();
    }

    for (const QString& root : {clientRoot, gameDir}) {
        QDirIterator hsIt(root, QStringList{QStringLiteral("hs_err_pid*.log")},
                          QDir::Files, QDirIterator::Subdirectories);
        while (hsIt.hasNext()) {
            hsIt.next();
            reports << hsIt.fileInfo();
        }
    }

    std::sort(reports.begin(), reports.end(), [](const QFileInfo& a, const QFileInfo& b) {
        return a.lastModified() > b.lastModified();
    });

    if (reports.isEmpty()) {
        out << "[launcher] crash-reports/hs_err_pid*.log не найдены.\n";
        return;
    }

    int appended = 0;
    QSet<QString> seen;
    for (const QFileInfo& fi : reports) {
        const QString path = fi.absoluteFilePath();
        if (seen.contains(path)) continue;
        seen.insert(path);
        out << "[launcher] найден crash-файл: " << path
            << " (" << fi.size() << " bytes, "
            << fi.lastModified().toString(Qt::ISODate) << ")\n";
        appendTextFileTail(out, path, 256 * 1024);
        if (++appended >= 3) break;
    }
}

QString classpathSeparator()
{
#ifdef Q_OS_WIN
    return QStringLiteral(";");
#else
    return QStringLiteral(":");
#endif
}

}



GameLauncher::GameLauncher(SettingsManager* settings, InstalledStore* installed,
                           RuntimeManager* runtimes, QObject* parent)
    : QObject(parent), m_settings(settings), m_installed(installed), m_runtimes(runtimes)
{
    if (m_runtimes) {


        connect(m_runtimes, &RuntimeManager::progressChanged, this, [this] {
            if (!m_preparing || m_pendingRuntimeId.isEmpty()) return;
            if (m_runtimes->currentId() != m_pendingRuntimeId) return;
            const double p = m_stageFrom + (m_stageTo - m_stageFrom) * m_runtimes->progress();
            m_progress = qBound(0.0, p, 1.0);
            const QString rt = m_runtimes->statusText();
            if (!rt.isEmpty()) m_stageText = rt;
            emit progressChanged();
        });

        connect(m_runtimes, &RuntimeManager::ensured, this,
                [this](const QString& id, const QString& javaExe, const QString& error) {
            if (id != m_pendingRuntimeId) return;
            const QString clientDir = m_pendingClientDir;
            const QString user      = m_pendingUsername;
            RunSpec spec            = m_pendingSpec;
            QVariantMap client      = m_pendingClient;
            m_pendingRuntimeId.clear();
            m_pendingClientDir.clear();
            m_pendingUsername.clear();
            m_pendingSpec = RunSpec{};
            m_pendingClient.clear();

            if (!error.isEmpty()) { fail(QStringLiteral("Не удалось получить рантайм: ") + error); return; }




            if (!spec.mcRuntimeId.isEmpty()) {
                const QString rtDir = m_runtimes->rootFor(spec.mcRuntimeId);
                if (rtDir.isEmpty()) {

                    m_pendingRuntimeId = spec.mcRuntimeId;
                    m_pendingClientDir = clientDir;
                    m_pendingUsername  = user;
                    m_pendingSpec      = spec;
                    m_pendingClient    = client;
                    m_stageFrom = 0.35; m_stageTo = 0.85;
                    setStage(QStringLiteral("Загрузка Minecraft ") + spec.mcRuntimeId + QStringLiteral("…"), 0.35);
                    m_runtimes->ensure(spec.mcRuntimeId);
                    return;
                }

                QString java = m_runtimes->javaExeFor(spec.requiredRuntimeId);
                if (java.isEmpty()) java = resolveJavaExe();
                if (java.isEmpty()) { fail(QStringLiteral("Java не найдена.")); return; }

                RunSpec rtSpec;
                QString rtErr;
                if (!readSpec(rtDir, rtSpec, &rtErr)) {
                    fail(QStringLiteral("Рантайм повреждён: ") + rtErr);
                    return;
                }
                startComposite(java, clientDir, rtDir, rtSpec, spec, user);
                return;
            }

            if (javaExe.isEmpty()) { fail(QStringLiteral("Java не найдена после установки.")); return; }

            if (!spec.mainClass.isEmpty()) {
                startProcess(javaExe, clientDir, spec, user);
            } else {

                const QString jar = QDir(clientDir).filePath(QStringLiteral("client.jar"));
                if (!QFileInfo::exists(jar)) { fail(QStringLiteral("client.jar не найден")); return; }
                QStringList args;
                args << QStringLiteral("-jar") << jar
                     << QStringLiteral("--username") << user
                     << QStringLiteral("--uuid") << offlineUuidFor(user)
                     << QStringLiteral("--accessToken") << QStringLiteral("0");
                if (m_process) m_process->deleteLater();
                m_process = new QProcess(this);
                m_process->setWorkingDirectory(clientDir);
                QStringList removedJavaEnv;
                m_process->setProcessEnvironment(JavaLaunch::cleanProcessEnvironment(&removedJavaEnv));
                m_games.append(m_process);

                const QString logPath = QDir(AppPaths::logsRoot()).filePath(m_runningClientId + QStringLiteral(".log"));
                m_gameLogPath = logPath;
                m_gameLogPos = QFileInfo(logPath).size();
                appendLaunchLogHeader(logPath, m_runningClientId, javaExe, clientDir, args, removedJavaEnv);
                m_process->setStandardOutputFile(logPath, QIODevice::Append);
                m_process->setStandardErrorFile(logPath, QIODevice::Append);

                connect(m_process, &QProcess::finished, this, [this, id = m_runningClientId](int code, QProcess::ExitStatus){
                    stopWindowBranding();
                    const QString clientRoot = QDir(m_settings->installDir()).filePath(id);
                    const QString gameDir = QDir(clientRoot).filePath(QStringLiteral("game"));
                    collectGameData(gameDir);
                    appendCrashDiagnostics(QDir(AppPaths::logsRoot()).filePath(id + QStringLiteral(".log")),
                                           clientRoot, gameDir);
                    emit gameFinished(id, code);
                    m_games.removeAll(m_process);
                    m_runningClientId.clear();
                    setStatus(QStringLiteral("Игра завершилась (") + QString::number(code) + QStringLiteral(")"));
                });
                reportLaunch(m_runningClientId);
                m_stageFrom = m_stageTo = 0.0;
                setStage(QStringLiteral("Запуск игры…"), 0.50);
                m_process->start(javaExe, args);
                if (m_process->waitForStarted(5000)) {
        emit gameProcessStarted(m_process->processId());
                    startWindowBranding();
            emit gameStarted(m_runningClientId);
                } else {
                    appendLauncherLogLine(logPath, QStringLiteral("Не удалось запустить java: ") + m_process->errorString());
                    fail(QStringLiteral("Не удалось запустить java: ") + m_process->errorString());
                    m_games.removeAll(m_process);
                    m_runningClientId.clear();
                }
            }
        });
    }
}

void GameLauncher::shareGameData(const QString& gameDir)
{






    const QString saves = QDir(gameDir).filePath(QStringLiteral("saves"));
    const QFileInfo si(saves);
    if (si.isSymLink() || si.isJunction())
        QDir().rmdir(saves);
    QDir().mkpath(saves);




    // servers.dat здесь больше не трогаем: список собирает ServerSync
    // (реклама + глобальные пользовательские серверы) при каждом запуске.
}

namespace {




void findNickFiles(const QString& dir, int depth, QStringList& out)
{
    if (depth < 0) return;
    static const QStringList kSkip = {
        QStringLiteral("saves"), QStringLiteral("resourcepacks"),
        QStringLiteral("shaderpacks"), QStringLiteral("assets"),
        QStringLiteral("logs"), QStringLiteral("mods"),
        QStringLiteral("libraries"), QStringLiteral("downloads"),
        QStringLiteral("crash-reports"), QStringLiteral(".fabric"),
        QStringLiteral("screenshots")
    };
    const QDir d(dir);
    for (const QFileInfo& fi : d.entryInfoList(QDir::Files | QDir::Dirs | QDir::NoDotAndDotDot)) {
        if (fi.isDir()) {
            if (kSkip.contains(fi.fileName(), Qt::CaseInsensitive)) continue;
            findNickFiles(fi.absoluteFilePath(), depth - 1, out);
        } else {
            // Раньше ловили только 3 известных файла — но каждый клиент хранит
            // ник по-своему (config.json, settings.json, alt.json, profile.json…),
            // из-за чего запускался Steve. Берём ВСЕ json/rock и внутри правим
            // только ник-подобные ключи (см. enforceNickname) — безопасно.
            const QString n = fi.fileName().toLower();
            if (n.endsWith(QStringLiteral(".json"))
                || n.endsWith(QStringLiteral(".rock"))
                || n == QStringLiteral("client.rock"))
                out << fi.absoluteFilePath();
        }
    }
}








void invalidateStaleFabricCache(const QString& gameDir, const QString& runtimeDir)
{
    const QString clientJar =
        QDir(runtimeDir).filePath(QStringLiteral("libs/minecraft-client.jar"));
    const QFileInfo jarInfo(clientJar);
    if (!jarInfo.exists()) return;

    const QString remapDir = QDir(gameDir).filePath(QStringLiteral(".fabric/remappedJars"));
    if (!QFileInfo(remapDir).isDir()) return;



    QDirIterator it(remapDir, QStringList{QStringLiteral("*.jar")},
                    QDir::Files, QDirIterator::Subdirectories);
    QDateTime newestCache;
    bool any = false;
    while (it.hasNext()) {
        it.next();
        const QDateTime m = it.fileInfo().lastModified();
        if (!any || m > newestCache) { newestCache = m; any = true; }
    }
    if (!any) return;

    if (jarInfo.lastModified() > newestCache) {
        qInfo() << "[fabric] рантайм обновлён — сбрасываю устаревший ремап-кэш:" << remapDir;
        QDir(remapDir).removeRecursively();
    }
}

}

namespace {
// Строковое значение этих ключей считаем ником и перезаписываем. Голые "name"
// и "user" сюда НЕ входят — иначе можно испортить посторонний json; accounts.json
// с ключом "name" обрабатывается отдельно ниже по имени файла.
bool isNickKey(const QString& k)
{
    static const QSet<QString> keys = {
        QStringLiteral("username"), QStringLiteral("nickname"),
        QStringLiteral("nick"), QStringLiteral("ign"),
        QStringLiteral("playername"), QStringLiteral("login"),
        QStringLiteral("currentname"), QStringLiteral("displayname"),
        QStringLiteral("sessionname"), QStringLiteral("user_name")
    };
    return keys.contains(k.toLower());
}
// Рекурсивно (ограниченная глубина) переписывает ник-ключи в объекте.
bool rewriteNick(QJsonObject& o, const QString& username, int depth)
{
    bool changed = false;
    for (const QString& k : o.keys()) {
        const QJsonValue v = o.value(k);
        if (v.isString()) {
            if (isNickKey(k) && v.toString() != username) {
                o.insert(k, username);
                changed = true;
            }
        } else if (v.isObject() && depth > 0) {
            QJsonObject sub = v.toObject();
            if (rewriteNick(sub, username, depth - 1)) { o.insert(k, sub); changed = true; }
        } else if (v.isArray() && depth > 0) {
            QJsonArray arr = v.toArray();
            bool ac = false;
            for (int i = 0; i < arr.size(); ++i) {
                if (arr[i].isObject()) {
                    QJsonObject e = arr[i].toObject();
                    if (rewriteNick(e, username, depth - 1)) { arr[i] = e; ac = true; }
                }
            }
            if (ac) { o.insert(k, arr); changed = true; }
        }
    }
    return changed;
}
}

void GameLauncher::enforceNickname(const QString& gameDir, const QString& username)
{
    if (username.isEmpty() || !QFileInfo(gameDir).isDir()) return;

    QStringList files;
    findNickFiles(gameDir, 3, files);

    for (const QString& path : files) {
        QFile f(path);
        if (!f.open(QIODevice::ReadOnly)) continue;
        const QByteArray raw = f.readAll();
        f.close();

        QJsonParseError perr;
        const QJsonDocument doc = QJsonDocument::fromJson(raw, &perr);
        if (perr.error != QJsonParseError::NoError) continue;

        const QString fname = QFileInfo(path).fileName().toLower();
        bool changed = false;
        QJsonDocument out;

        if (doc.isObject()) {
            QJsonObject o = doc.object();
            changed = rewriteNick(o, username, 4);
            if (changed) out.setObject(o);
        } else if (doc.isArray()) {
            QJsonArray arr = doc.array();
            // accounts.json (и любой массив аккаунтов): ключ "name" — это ник
            // аккаунта. Обновляем выбранный (или первый), плюс общий проход.
            const bool accounts = fname == QStringLiteral("accounts.json")
                || fname == QStringLiteral("alts.json")
                || fname == QStringLiteral("accounts.rock");
            int sel = -1;
            bool allObjWithName = !arr.isEmpty();
            for (int i = 0; i < arr.size(); ++i) {
                if (!arr[i].isObject()) { allObjWithName = false; continue; }
                QJsonObject e = arr[i].toObject();
                if (rewriteNick(e, username, 3)) { arr[i] = e; changed = true; }
                if (!e.contains(QStringLiteral("name"))) allObjWithName = false;
                if (sel < 0 && e.value(QStringLiteral("selected")).toBool()) sel = i;
            }
            if (accounts && allObjWithName) {
                if (sel < 0) sel = 0;
                QJsonObject e = arr[sel].toObject();
                if (e.value(QStringLiteral("name")).toString() != username) {
                    e.insert(QStringLiteral("name"), username);
                    e.insert(QStringLiteral("selected"), true);
                    arr[sel] = e;
                    changed = true;
                }
            }
            if (changed) out.setArray(arr);
        }

        if (!changed) continue;
        if (f.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
            f.write(out.toJson(QJsonDocument::Indented));
            f.close();
        }
    }
}

void GameLauncher::collectGameData(const QString& gameDir)
{


    const QString local = QDir(gameDir).filePath(QStringLiteral("servers.dat"));
    if (!QFileInfo::exists(local)) return;

    const QString shared = AppPaths::sharedServersFile();
    QFile::remove(shared);
    if (!QFile::copy(local, shared))
        qWarning() << "[shared] не удалось сохранить общий список серверов";
}

void GameLauncher::applyWindowBranding()
{
#ifdef Q_OS_WIN
    if (!m_process || m_process->state() != QProcess::Running) return;

    BrandContext ctx;
    ctx.pid   = static_cast<DWORD>(m_process->processId());
    ctx.title = reinterpret_cast<const wchar_t*>(g_brandTitle.utf16());
    ctx.icon  = launcherIcon();
    EnumWindows(brandWindowProc, reinterpret_cast<LPARAM>(&ctx));





    if (ctx.found && !m_gameWindowSeen) {
        m_gameWindowSeen = true;
        setStage(QStringLiteral("Игра запущена"), 1.0);
        endPreparing();

        emit gameWindowReady(m_runningClientId);
    }
#endif
}

void GameLauncher::pollGameLog()
{
    if (!m_preparing || m_gameLogPath.isEmpty()) return;

    QFile f(m_gameLogPath);
    if (!f.open(QIODevice::ReadOnly)) return;
    if (m_gameLogPos > f.size()) m_gameLogPos = 0;
    if (!f.seek(m_gameLogPos)) return;

    const QByteArray chunk = f.read(128 * 1024);
    m_gameLogPos += chunk.size();
    if (chunk.isEmpty()) return;

    const QString text = QString::fromUtf8(chunk);






    struct Step { QLatin1String needle; const char* text; double p; };
    static const Step kSteps[] = {
        {QLatin1String("Loading Minecraft"),     "Загрузка Minecraft…",    0.55},
        {QLatin1String("MIXIN Subsystem"),       "Подготовка модов…",      0.65},
        {QLatin1String("Datafixer"),             "Подготовка мира…",       0.72},
        {QLatin1String("Setting user"),          "Вход в игру…",           0.80},
        {QLatin1String("Backend library"),       "Инициализация графики…", 0.86},
        {QLatin1String("Sound engine started"),  "Загрузка звука…",        0.90},
        {QLatin1String("Created:"),              "Загрузка текстур…",      0.94},
    };

    for (const Step& st : kSteps) {
        if (m_progress >= st.p) continue;
        if (text.contains(st.needle))
            setStage(QString::fromUtf8(st.text), st.p);
    }
}

void GameLauncher::startWindowBranding()
{
#ifdef Q_OS_WIN
    if (!m_process) return;

    const QString name = m_runningClientName.isEmpty() ? m_runningClientId : m_runningClientName;
    g_brandTitle = QStringLiteral("Exclusion Launcher >>> ") + name;
    g_brandPid = static_cast<DWORD>(m_process->processId());
    m_gameWindowSeen = false;



    if (g_nameHook) { UnhookWinEvent(g_nameHook); g_nameHook = nullptr; }
    g_nameHook = SetWinEventHook(EVENT_OBJECT_NAMECHANGE, EVENT_OBJECT_NAMECHANGE,
                                 nullptr, nameChangeProc, g_brandPid, 0,
                                 WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS);



    m_brandTimer.setInterval(300);
    disconnect(&m_brandTimer, nullptr, this, nullptr);
    connect(&m_brandTimer, &QTimer::timeout, this, [this] {
        applyWindowBranding();
        pollGameLog();
    });
    m_brandTimer.start();
#endif
}

void GameLauncher::stopWindowBranding()
{
    m_brandTimer.stop();
#ifdef Q_OS_WIN
    if (g_nameHook) { UnhookWinEvent(g_nameHook); g_nameHook = nullptr; }
    g_brandPid = 0;
    g_brandTitle.clear();
#endif
}

void GameLauncher::applyUserPrefs(QStringList& jvmArgs, QStringList& gameArgs) const
{
    if (!m_settings) return;




    JavaLaunch::applyMemoryArgs(jvmArgs, m_settings->memoryMB());

    if (m_settings->fullscreen() && !gameArgs.contains(QStringLiteral("--fullscreen")))
        gameArgs << QStringLiteral("--fullscreen");
}

void GameLauncher::setStatus(const QString& t)
{
    m_statusText = t;
    emit stateChanged();
}

void GameLauncher::setStage(const QString& text, double progress)
{
    m_preparing = true;
    m_stageText = text;
    m_progress = qBound(0.0, progress, 1.0);
    m_statusText = text;
    emit progressChanged();
    emit stateChanged();
}

void GameLauncher::endPreparing()
{
    if (!m_preparing) return;
    m_preparing = false;
    m_progress = 0.0;
    m_stageText.clear();
    m_preparingClientId.clear();
    m_stageFrom = m_stageTo = 0.0;
    emit progressChanged();
}

void GameLauncher::fail(const QString& msg)
{
    m_lastError = msg;
    m_statusText = QStringLiteral("Ошибка запуска");
    endPreparing();
    emit errorChanged();
    emit stateChanged();
}

void GameLauncher::clearError()
{
    if (m_lastError.isEmpty()) return;
    m_lastError.clear();
    emit errorChanged();
}

QString GameLauncher::resolveJavaExe() const
{

    const QString fromSettings = m_settings ? m_settings->runtimePath() : QString();
    if (!fromSettings.isEmpty()) {
        QFileInfo fi(fromSettings);
        if (fi.isDir()) {
            const QString candidate = fi.absoluteFilePath()
                + QStringLiteral("/bin/java")
#ifdef Q_OS_WIN
                + QStringLiteral(".exe")
#endif
                ;
            if (QFileInfo::exists(candidate)) return candidate;
        }
        if (fi.isFile() && fi.isExecutable()) return fromSettings;
    }


    const QProcessEnvironment env = QProcessEnvironment::systemEnvironment();
    for (const QString& var : {QStringLiteral("JAVA_HOME"), QStringLiteral("JDK_HOME")}) {
        const QString root = env.value(var);
        if (root.isEmpty()) continue;
        const QString candidate = root
            + QStringLiteral("/bin/java")
#ifdef Q_OS_WIN
            + QStringLiteral(".exe")
#endif
            ;
        if (QFileInfo::exists(candidate)) return candidate;
    }


    return firstExistingFile({
        QStandardPaths::findExecutable(QStringLiteral("javaw")),
        QStandardPaths::findExecutable(QStringLiteral("java"))
    });
}

bool GameLauncher::readSpec(const QString& clientDir, RunSpec& out, QString* err) const
{
    QFile f(QDir(clientDir).filePath(QStringLiteral("run.spec.json")));
    if (!f.open(QIODevice::ReadOnly)) {
        if (err) *err = QStringLiteral("run.spec.json не найден: ") + f.fileName();
        return false;
    }
    QJsonParseError perr;
    const auto doc = QJsonDocument::fromJson(f.readAll(), &perr);
    if (perr.error != QJsonParseError::NoError || !doc.isObject()) {
        if (err) *err = QStringLiteral("run.spec.json невалиден: ") + perr.errorString();
        return false;
    }
    const auto o = doc.object();
    out.type       = o.value("type").toString();
    out.mcVersion  = o.value("mcVersion").toString();
    out.assetIndex = o.value("assetIndex").toString();
    out.mainClass  = o.value("mainClass").toString();

    out.jvmFlags.clear();
    for (const auto& v : o.value("jvmFlags").toArray())  out.jvmFlags  << v.toString();
    out.classpath.clear();
    for (const auto& v : o.value("classpath").toArray()) out.classpath << v.toString();
    out.gameArgs.clear();
    for (const auto& v : o.value("gameArgs").toArray())  out.gameArgs  << v.toString();

    out.preCreateDirs.clear();
    for (const auto& v : o.value("preCreateDirs").toArray()) out.preCreateDirs << v.toString();

    const auto req = o.value("requires").toObject();
    out.requiredRuntimeId = req.value("runtime").toString();
    out.mcRuntimeId = req.value("mcRuntime").toString();
    out.requiredJdk = req.value("jdk").toString().toInt();
    if (out.requiredJdk == 0) out.requiredJdk = req.value("jdk").toInt();




    if (out.mainClass.isEmpty() && out.mcRuntimeId.isEmpty()) {
        if (err) *err = QStringLiteral("run.spec.json: не указан ни mainClass, ни requires.mcRuntime");
        return false;
    }
    return true;
}

QString GameLauncher::substitute(QString s,
                                 const QString& pkgRoot,
                                 const QString& gameDir,
                                 const QString& assetsDir,
                                 const QString& username,
                                 const QString& uuid) const
{
    s.replace(QStringLiteral("{PKG_ROOT}"),     pkgRoot);
    s.replace(QStringLiteral("{GAME_DIR}"),     gameDir);
    s.replace(QStringLiteral("{ASSETS_DIR}"),   assetsDir);
    s.replace(QStringLiteral("{USERNAME}"),     username);
    s.replace(QStringLiteral("{UUID}"),         uuid);
    s.replace(QStringLiteral("{ACCESS_TOKEN}"), QStringLiteral("0"));
    return s;
}

void GameLauncher::setVerifier(ClientVerifier* verifier)
{
    m_verifier = verifier;
    if (!m_verifier) return;

    connect(m_verifier, &ClientVerifier::verified, this,
            [this](const QString& id, bool ok, const QString& details) {
        if (id != m_verifyingClient.value("id").toString()) return;
        const QVariantMap client = m_verifyingClient;
        m_verifyingClient.clear();

        if (ok) { launchVerified(client); return; }




        qWarning() << "[verify] клиент повреждён:" << id << details;
        endPreparing();
        fail(tr("Файлы клиента повреждены (%1). Переустановите клиент: удалите "
                "его в разделе «Клиенты» и скачайте заново.").arg(details));
    });
}

void GameLauncher::launch(const QVariantMap& client)
{




    if (m_preparing) {
        fail(QStringLiteral("Дождитесь запуска предыдущего клиента."));
        return;
    }
    if (m_blocker && m_blocker->busy()) {
        fail(tr("Идёт проверка целостности файлов — дождитесь её завершения."));
        return;
    }
    clearError();

    const QString id = client.value("id").toString();
    if (id.isEmpty()) { fail(QStringLiteral("Не указан id клиента.")); return; }

    m_preparingClientId = id;
    setStage(QStringLiteral("Подготовка к запуску…"), 0.02);

    const QString clientDir = QDir(m_settings->installDir()).filePath(id);




    const bool outdated = m_installed
        && (m_installed->installedVersion(id) != client.value(QStringLiteral("version")).toString()
            || m_installed->needsUpdate(id,
                                        client.value(QStringLiteral("sha256")).toString(),
                                        client.value(QStringLiteral("packageUrl")).toString()));
    if (!m_installed || !m_installed->isInstalled(id) || !QFileInfo(clientDir).isDir() || outdated) {
        endPreparing();
        emit reinstallRequired(client);
        return;
    }




    if (m_verifier && !m_verifier->busy() && ClientVerifier::hasManifest(clientDir)) {
        m_verifyingClient = client;
        setStage(QStringLiteral("Проверка файлов клиента…"), 0.05);
        m_verifier->verify(id, clientDir);
        return;
    }

    launchVerified(client);
}

void GameLauncher::cancelPreparing()
{
    if (!m_preparing) return;



    m_pendingRuntimeId.clear();
    m_pendingClientDir.clear();
    m_pendingUsername.clear();
    m_pendingSpec = RunSpec{};
    m_pendingClient.clear();
    m_verifyingClient.clear();

    if (m_runtimes) m_runtimes->cancelCurrent();

    m_prepTicker.stop();
    endPreparing();
    setStatus(QStringLiteral("Запуск отменён"));
}

void GameLauncher::launchVerified(const QVariantMap& client)
{
    const QString id = client.value("id").toString();
    m_preparingClientId = id;
    setStage(QStringLiteral("Подготовка к запуску…"), 0.15);

    const QString clientDir = QDir(m_settings->installDir()).filePath(id);
    if (!QFileInfo(clientDir).isDir()) {
        fail(QStringLiteral("Папка клиента не найдена: ") + clientDir);
        return;
    }


    const QString specPath = QDir(clientDir).filePath(QStringLiteral("run.spec.json"));
    RunSpec spec;
    QString err;

    QString username = m_settings->nickname();
    if (username.isEmpty()) username = QStringLiteral("Player");

    m_runningClientId = id;

    m_runningClientName = client.value(QStringLiteral("name")).toString();

    if (QFileInfo::exists(specPath)) {
        if (!readSpec(clientDir, spec, &err)) { fail(err); return; }


        QString runtimeId = spec.requiredRuntimeId;
        if (runtimeId.isEmpty() && spec.requiredJdk > 0)
            runtimeId = QStringLiteral("java") + QString::number(spec.requiredJdk);


        if (!runtimeId.isEmpty() && m_runtimes) {
            const QString installed = m_runtimes->javaExeFor(runtimeId);
            if (!installed.isEmpty()) {


                if (!spec.mcRuntimeId.isEmpty()) {
                    const QString rtDir = m_runtimes->rootFor(spec.mcRuntimeId);
                    if (rtDir.isEmpty()) {
                        m_pendingRuntimeId = spec.mcRuntimeId;
                        m_pendingClientDir = clientDir;
                        m_pendingUsername  = username;
                        m_pendingSpec      = spec;
                        m_pendingClient    = client;
                        m_stageFrom = 0.35; m_stageTo = 0.85;
                        setStage(QStringLiteral("Загрузка Minecraft ") + spec.mcRuntimeId + QStringLiteral("…"), 0.35);
                        m_runtimes->ensure(spec.mcRuntimeId);
                        return;
                    }
                    RunSpec rtSpec;
                    QString rtErr;
                    if (!readSpec(rtDir, rtSpec, &rtErr)) {
                        fail(QStringLiteral("Рантайм повреждён: ") + rtErr);
                        return;
                    }
                    startComposite(installed, clientDir, rtDir, rtSpec, spec, username);
                    return;
                }
                startProcess(installed, clientDir, spec, username);
                return;
            }

            m_pendingRuntimeId = runtimeId;
            m_pendingClientDir = clientDir;
            m_pendingUsername  = username;
            m_pendingSpec      = spec;
            m_pendingClient    = client;
            m_stageFrom = 0.05; m_stageTo = 0.35;
            setStage(QStringLiteral("Загрузка Java ") + runtimeId + QStringLiteral("…"), 0.05);
            m_runtimes->ensure(runtimeId);
            return;
        }


        const QString java = resolveJavaExe();
        if (java.isEmpty()) {
            fail(QStringLiteral("Java не найдена. Укажите путь к JDK в настройках "
                                "или обеспечьте наличие runtime на сервере."));
            return;
        }
        startProcess(java, clientDir, spec, username);
        return;
    }


    const QString java = resolveJavaExe();
    if (java.isEmpty()) {
        fail(QStringLiteral("Java не найдена. Укажите путь к JDK в настройках."));
        return;
    }


    const QString jarCandidate = firstExistingFile({
        QDir(clientDir).filePath(QStringLiteral("client.jar")),
        QDir(clientDir).filePath(id + QStringLiteral(".jar"))
    });
    if (jarCandidate.isEmpty()) {
        fail(QStringLiteral("Ни run.spec.json, ни client.jar не найдены в ") + clientDir);
        return;
    }

    QStringList args;
    args << QStringLiteral("-jar") << jarCandidate;

    args << QStringLiteral("--username") << username
         << QStringLiteral("--uuid")     << offlineUuidFor(username)
         << QStringLiteral("--accessToken") << QStringLiteral("0");

    m_process = new QProcess(this);
    m_games.append(m_process);
    m_process->setWorkingDirectory(clientDir);
    QStringList removedJavaEnv;
    m_process->setProcessEnvironment(JavaLaunch::cleanProcessEnvironment(&removedJavaEnv));

    const QString logPath = QDir(AppPaths::logsRoot()).filePath(m_runningClientId + QStringLiteral(".log"));
    appendLaunchLogHeader(logPath, m_runningClientId, java, clientDir, args, removedJavaEnv);
    m_gameLogPath = logPath;
    m_gameLogPos = QFileInfo(logPath).size();
    m_process->setStandardOutputFile(logPath, QIODevice::Append);
    m_process->setStandardErrorFile(logPath, QIODevice::Append);

    {
        QProcess* p = m_process;
        connect(p, &QProcess::finished, this, [this, p, id](int code, QProcess::ExitStatus) {
            onProcessFinished(p, id, code);
        });
    }
    reportLaunch(m_runningClientId);
    m_stageFrom = m_stageTo = 0.0;
    setStage(QStringLiteral("Запуск игры…"), 0.50);
    m_process->start(java, args);
    if (m_process->waitForStarted(5000)) {
        emit gameProcessStarted(m_process->processId());
        startWindowBranding();
            emit gameStarted(m_runningClientId);
    } else {
        appendLauncherLogLine(logPath, QStringLiteral("Не удалось запустить java: ") + m_process->errorString());
        fail(QStringLiteral("Не удалось запустить java: ") + m_process->errorString());
        m_games.removeAll(m_process);
        m_runningClientId.clear();
    }
}

void GameLauncher::startProcess(const QString& javaExe,
                                const QString& clientDir,
                                const RunSpec& spec,
                                const QString& username)
{
    const QString pkgRoot   = QDir::toNativeSeparators(QFileInfo(clientDir).absoluteFilePath());
    const QString gameDir   = QDir::toNativeSeparators(QDir(clientDir).filePath(QStringLiteral("game")));
    const QString assetsDir = QDir::toNativeSeparators(QDir(clientDir).filePath(QStringLiteral("assets")));
    const QString uuid      = offlineUuidFor(username);


    QStringList jvmArgs;
    bool skipNext = false;
    for (const auto& raw : spec.jvmFlags) {
        if (skipNext) { skipNext = false; continue; }
        if (raw == QStringLiteral("-cp") || raw == QStringLiteral("-classpath")) {
            skipNext = true; continue;
        }
        jvmArgs << substitute(raw, pkgRoot, gameDir, assetsDir, username, uuid);
    }


    QStringList gameArgs;
    for (const auto& raw : spec.gameArgs)
        gameArgs << substitute(raw, pkgRoot, gameDir, assetsDir, username, uuid);





    QString realGameDir = pkgRoot;
    {
        const int gi = gameArgs.indexOf(QStringLiteral("--gameDir"));
        if (gi >= 0 && gi + 1 < gameArgs.size())
            realGameDir = QDir::toNativeSeparators(gameArgs.at(gi + 1));
    }

    applyUserPrefs(jvmArgs, gameArgs);

    QStringList argv = jvmArgs;


    QStringList cpAbs;
    cpAbs.reserve(spec.classpath.size());
    for (const auto& rel : spec.classpath) {
        cpAbs << QDir::toNativeSeparators(QDir(pkgRoot).filePath(rel));
    }
    if (!cpAbs.isEmpty()) {
        argv << QStringLiteral("-cp") << cpAbs.join(classpathSeparator());
    }

    argv << spec.mainClass;
    argv += gameArgs;


    QDir().mkpath(gameDir);
    QDir().mkpath(realGameDir);
    QDir().mkpath(assetsDir);




    for (const QString& raw : spec.preCreateDirs) {
        QString p = raw;
        p.replace(QStringLiteral("{PKG_ROOT}"), pkgRoot);
        if (!p.trimmed().isEmpty()) QDir().mkpath(p);
    }




    shareGameData(realGameDir);
    enforceNickname(realGameDir, username);





    if (m_serverSync) {
        QString syncError;
        if (!m_serverSync->syncForClient(pkgRoot, realGameDir, &syncError))
            qWarning() << "[servers] не удалось обновить список:" << syncError;
    }


    m_process = new QProcess(this);
    m_games.append(m_process);
    m_process->setWorkingDirectory(pkgRoot);
    QStringList removedJavaEnv;
    m_process->setProcessEnvironment(JavaLaunch::cleanProcessEnvironment(&removedJavaEnv));


    const QString logPath = QDir(AppPaths::logsRoot()).filePath(m_runningClientId + QStringLiteral(".log"));


    appendLaunchLogHeader(logPath, m_runningClientId, javaExe, pkgRoot, argv, removedJavaEnv);
    m_gameLogPath = logPath;
    m_gameLogPos = QFileInfo(logPath).size();
    m_process->setStandardOutputFile(logPath, QIODevice::Append);
    m_process->setStandardErrorFile(logPath,  QIODevice::Append);

    const QString me = m_runningClientId;
    QProcess* p = m_process;
    connect(p, &QProcess::finished, this, [this, p, me](int code, QProcess::ExitStatus) {
        onProcessFinished(p, me, code);
    });

    reportLaunch(m_runningClientId);
    m_stageFrom = m_stageTo = 0.0;
    setStage(QStringLiteral("Запуск игры…"), 0.50);
    m_process->start(javaExe, argv);
    if (m_process->waitForStarted(5000)) {
        emit gameProcessStarted(m_process->processId());
        startWindowBranding();
            emit gameStarted(m_runningClientId);
    } else {
        appendLauncherLogLine(logPath, QStringLiteral("Не удалось запустить java: ") + m_process->errorString());
        fail(QStringLiteral("Не удалось запустить java: ") + m_process->errorString());
        m_games.removeAll(m_process);
        m_runningClientId.clear();
    }
}

void GameLauncher::reportLaunch(const QString& clientId)
{

    const QString url = AppConfig::ServerBaseUrl + QStringLiteral("/stats/launch");
    QNetworkRequest req{QUrl(url)};
    req.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/json"));
    req.setHeader(QNetworkRequest::UserAgentHeader, QStringLiteral("ExclusionLauncher/0.1"));

    QJsonObject body;
    body.insert("client_id", clientId);
    body.insert("launcher_version", QString::fromLatin1(AppConfig::LauncherVersion));


    body.insert("hwid", HardwareId::value());

    auto* r = m_network.post(req, QJsonDocument(body).toJson(QJsonDocument::Compact));
    connect(r, &QNetworkReply::finished, this, [r]{ r->deleteLater(); });
}

void GameLauncher::onProcessFinished(QProcess* p, const QString& id, int code)
{
    if (p && p->processId() > 0)
        emit gameProcessEnded(p->processId());



    const bool wasCurrent = (p == m_process);




    const bool launchCrash = wasCurrent && m_preparing && !m_gameWindowSeen;

    if (wasCurrent) {
        stopWindowBranding();
        m_runningClientId.clear();
    }
    m_games.removeAll(p);
    const QString clientRootForData = QDir(m_settings->installDir()).filePath(id);
    collectGameData(QDir(clientRootForData).filePath(QStringLiteral("game")));
    collectGameData(clientRootForData);
    // Сразу после выхода синхронизируем: добавленное игроком уезжает в общий
    // список, удалённое — удаляется из него (для обоих вариантов gameDir).
    if (m_serverSync) {
        QString syncErr;
        m_serverSync->syncForClient(clientRootForData,
                                    QDir(clientRootForData).filePath(QStringLiteral("game")), &syncErr);
        m_serverSync->syncForClient(clientRootForData, clientRootForData, &syncErr);
    }
    {
        const QString clientRoot = QDir(m_settings->installDir()).filePath(id);
        const QString gameDir = QDir(clientRoot).filePath(QStringLiteral("game"));
        appendCrashDiagnostics(QDir(AppPaths::logsRoot()).filePath(id + QStringLiteral(".log")),
                               clientRoot, gameDir);
    }
    emit gameFinished(id, code);

    if (launchCrash) {

        fail(tr("Клиент крашнулся в момент запуска (код %1). "
                "Подробности — в логе клиента (logs/%2.log).").arg(code).arg(id));
    } else {
        setStatus(QStringLiteral("Игра завершилась (код ") + QString::number(code) + QStringLiteral(")"));
    }

    if (p) p->deleteLater();
    emit stateChanged();
}

void GameLauncher::startComposite(const QString& javaExe,
                                  const QString& clientDir,
                                  const QString& runtimeDir,
                                  const RunSpec& rt,
                                  const RunSpec& clientSpec,
                                  const QString& username)
{



    const QString gameDir = QDir(QFileInfo(clientDir).absoluteFilePath())
                                .filePath(QStringLiteral("game"));
    if (!QFileInfo::exists(gameDir)) {
        prepareGameDirAsync(javaExe, clientDir, runtimeDir, rt, clientSpec, username);
        return;
    }
    runComposite(javaExe, clientDir, runtimeDir, rt, clientSpec, username);
}

void GameLauncher::prepareGameDirAsync(const QString& javaExe,
                                       const QString& clientDir,
                                       const QString& runtimeDir,
                                       const RunSpec& rt,
                                       const RunSpec& clientSpec,
                                       const QString& username)
{
    const QString rtRoot  = QDir::toNativeSeparators(QFileInfo(runtimeDir).absoluteFilePath());
    const QString cliRoot = QDir::toNativeSeparators(QFileInfo(clientDir).absoluteFilePath());
    const QString gameDir = QDir::toNativeSeparators(QDir(cliRoot).filePath(QStringLiteral("game")));
    const QString rtGame  = QDir(rtRoot).filePath(QStringLiteral("game"));

    m_stageFrom = m_stageTo = 0.0;
    setStage(QStringLiteral("Подготовка клиента…"), 0.60);

    auto done  = std::make_shared<std::atomic<int>>(0);
    auto total = std::make_shared<std::atomic<int>>(0);
    m_prepDone = done;
    m_prepTotal = total;


    m_prepTicker.setInterval(200);
    disconnect(&m_prepTicker, nullptr, this, nullptr);
    connect(&m_prepTicker, &QTimer::timeout, this, [this, done, total] {
        const int t = total->load(std::memory_order_relaxed);
        if (t <= 0) return;
        const double frac = double(done->load(std::memory_order_relaxed)) / double(t);
        m_progress = 0.60 + 0.34 * qBound(0.0, frac, 1.0);
        emit progressChanged();
    });
    m_prepTicker.start();

    disconnect(&m_prepWatcher, nullptr, this, nullptr);
    connect(&m_prepWatcher, &QFutureWatcher<QString>::finished, this,
            [this, javaExe, clientDir, runtimeDir, rt, clientSpec, username] {
        m_prepTicker.stop();


        if (!m_preparing) return;
        const QString err = m_prepWatcher.result();
        if (!err.isEmpty()) { fail(err); return; }
        runComposite(javaExe, clientDir, runtimeDir, rt, clientSpec, username);
    });

    m_prepWatcher.setFuture(QtConcurrent::run([rtGame, gameDir, cliRoot, done, total]() -> QString {
        if (QFileInfo::exists(rtGame)) {
            total->store(countFilesRecursive(rtGame), std::memory_order_relaxed);
            QString cpErr;
            if (!copyDirRecursive(rtGame, gameDir, &cpErr, done.get()))
                return QStringLiteral("Не удалось подготовить папку игры: ") + cpErr;
        }
        QString modsErr;
        if (!syncClientModsIntoGame(cliRoot, gameDir, &modsErr))
            return QStringLiteral("Не удалось установить моды клиента: ") + modsErr;
        return {};
    }));
}

void GameLauncher::runComposite(const QString& javaExe,
                                const QString& clientDir,
                                const QString& runtimeDir,
                                const RunSpec& rt,
                                const RunSpec& clientSpec,
                                const QString& username)
{
    const QString rtRoot = QDir::toNativeSeparators(QFileInfo(runtimeDir).absoluteFilePath());





    const QString localObjects = QDir(rtRoot).filePath(QStringLiteral("assets/objects"));
    const bool hasLocalAssets =
        QFileInfo::exists(localObjects) &&
        !QDir(localObjects).isEmpty(QDir::Dirs | QDir::Files | QDir::NoDotAndDotDot);

    if (hasLocalAssets) {
        launchComposite(javaExe, clientDir, runtimeDir, rt, clientSpec, username,
                        QDir::toNativeSeparators(QDir(rtRoot).filePath(QStringLiteral("assets"))));
        return;
    }

    const QString shared = QDir::toNativeSeparators(AppPaths::mcAssetsRoot());
    const QString indexPath =
        QDir(rtRoot).filePath(QStringLiteral("assets/indexes/") + rt.assetIndex + QStringLiteral(".json"));
    if (!QFileInfo::exists(indexPath)) {


        fail(QStringLiteral("В рантайме нет ни ассетов, ни индекса: ") + rt.assetIndex);
        return;
    }

    if (!m_mcAssets) m_mcAssets = new McAssets(this);
    disconnect(m_mcAssets, nullptr, this, nullptr);
    connect(m_mcAssets, &McAssets::progress, this, [this](int done, int total, const QString& text) {
        m_stageFrom = m_stageTo = 0.0;
        const double frac = total > 0 ? double(done) / double(total) : 0.0;
        setStage(text, 0.35 + 0.20 * qBound(0.0, frac, 1.0));
    });
    connect(m_mcAssets, &McAssets::finished, this,
            [this, javaExe, clientDir, runtimeDir, rt, clientSpec, username, shared](bool ok, const QString& err) {
        if (!ok) { fail(QStringLiteral("Не удалось загрузить ресурсы Minecraft: ") + err); return; }
        launchComposite(javaExe, clientDir, runtimeDir, rt, clientSpec, username, shared);
    });
    setStage(QStringLiteral("Загрузка ресурсов Minecraft…"), 0.35);
    m_mcAssets->ensure(indexPath, shared);
}

void GameLauncher::launchComposite(const QString& javaExe,
                                   const QString& clientDir,
                                   const QString& runtimeDir,
                                   const RunSpec& rt,
                                   const RunSpec& clientSpec,
                                   const QString& username,
                                   const QString& assetsDirIn)
{


    const QString rtRoot    = QDir::toNativeSeparators(QFileInfo(runtimeDir).absoluteFilePath());
    const QString cliRoot   = QDir::toNativeSeparators(QFileInfo(clientDir).absoluteFilePath());
    const QString gameDir   = QDir::toNativeSeparators(QDir(cliRoot).filePath(QStringLiteral("game")));
    const QString assetsDir = QDir::toNativeSeparators(assetsDirIn);
    const QString uuid      = offlineUuidFor(username);

    QStringList jvmArgs;
    bool skipNext = false;
    for (const auto& raw : rt.jvmFlags) {
        if (skipNext) { skipNext = false; continue; }
        if (raw == QStringLiteral("-cp") || raw == QStringLiteral("-classpath")) {
            skipNext = true; continue;
        }


        jvmArgs << substitute(raw, rtRoot, gameDir, assetsDir, username, uuid);
    }
    for (const auto& raw : clientSpec.jvmFlags)
        jvmArgs << substitute(raw, cliRoot, gameDir, assetsDir, username, uuid);

    QStringList gameArgs;
    const QStringList selectedGameArgs = clientSpec.gameArgs.isEmpty() ? rt.gameArgs : clientSpec.gameArgs;
    const QString gameSubRoot = clientSpec.gameArgs.isEmpty() ? rtRoot : cliRoot;
    for (const auto& raw : selectedGameArgs)
        gameArgs << substitute(raw, gameSubRoot, gameDir, assetsDir, username, uuid);



    QString realGameDir = cliRoot;
    {
        const int gi = gameArgs.indexOf(QStringLiteral("--gameDir"));
        if (gi >= 0 && gi + 1 < gameArgs.size())
            realGameDir = QDir::toNativeSeparators(gameArgs.at(gi + 1));
    }

    applyUserPrefs(jvmArgs, gameArgs);

    QStringList argv = jvmArgs;

    QStringList cpAbs;
    cpAbs.reserve(rt.classpath.size() + clientSpec.classpath.size());
    for (const auto& rel : clientSpec.classpath)
        cpAbs << QDir::toNativeSeparators(QDir(cliRoot).filePath(rel));
    for (const auto& rel : rt.classpath)
        cpAbs << QDir::toNativeSeparators(QDir(rtRoot).filePath(rel));
    if (!cpAbs.isEmpty())
        argv << QStringLiteral("-cp") << cpAbs.join(classpathSeparator());

    argv << (clientSpec.mainClass.isEmpty() ? rt.mainClass : clientSpec.mainClass);
    argv += gameArgs;

    QDir().mkpath(realGameDir);



    QString modsErr;
    if (!syncClientModsIntoGame(cliRoot, gameDir, &modsErr)) {
        fail(QStringLiteral("Не удалось установить моды клиента: ") + modsErr);
        return;
    }

    invalidateStaleFabricCache(gameDir, rtRoot);

    shareGameData(realGameDir);
    enforceNickname(realGameDir, username);

    if (m_serverSync) {
        QString syncError;
        if (!m_serverSync->syncForClient(cliRoot, realGameDir, &syncError))
            qWarning() << "[servers] не удалось обновить список:" << syncError;
    }


    m_process = new QProcess(this);
    m_games.append(m_process);
    m_process->setWorkingDirectory(cliRoot);
    QStringList removedJavaEnv;
    m_process->setProcessEnvironment(JavaLaunch::cleanProcessEnvironment(&removedJavaEnv));

    const QString logPath = QDir(AppPaths::logsRoot()).filePath(m_runningClientId + QStringLiteral(".log"));


    appendLaunchLogHeader(logPath, m_runningClientId, javaExe, cliRoot, argv, removedJavaEnv);
    m_gameLogPath = logPath;
    m_gameLogPos = QFileInfo(logPath).size();
    m_process->setStandardOutputFile(logPath, QIODevice::Append);
    m_process->setStandardErrorFile(logPath, QIODevice::Append);

    const QString me = m_runningClientId;
    QProcess* p = m_process;
    connect(p, &QProcess::finished, this, [this, p, me](int code, QProcess::ExitStatus) {
        onProcessFinished(p, me, code);
    });

    reportLaunch(m_runningClientId);
    m_stageFrom = m_stageTo = 0.0;
    setStage(QStringLiteral("Запуск игры…"), 0.50);
    m_process->start(javaExe, argv);
    if (m_process->waitForStarted(5000)) {
        emit gameProcessStarted(m_process->processId());
        startWindowBranding();
            emit gameStarted(m_runningClientId);
    } else {
        appendLauncherLogLine(logPath, QStringLiteral("Не удалось запустить java: ") + m_process->errorString());
        fail(QStringLiteral("Не удалось запустить java: ") + m_process->errorString());
        m_games.removeAll(m_process);
        m_runningClientId.clear();
    }
}

GameLauncher::~GameLauncher()
{


    m_prepTicker.stop();
    m_prepWatcher.disconnect(this);
    if (m_prepWatcher.isRunning()) m_prepWatcher.waitForFinished();



    for (QProcess* p : m_games) {
        if (!p || p->state() == QProcess::NotRunning) continue;

        p->disconnect(this);
        p->terminate();
        if (!p->waitForFinished(1000))
            p->kill();
        p->waitForFinished(1000);
    }
}

void GameLauncher::terminate()
{

    for (QProcess* p : m_games) {
        if (!p || p->state() == QProcess::NotRunning) continue;
        p->terminate();
        if (!p->waitForFinished(3000))
            p->kill();
    }
}
