#pragma once

#include <QFutureWatcher>
#include <QObject>
#include <QNetworkAccessManager>
#include <QString>
#include <QTimer>











class AppUpdater : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool updateReady READ updateReady NOTIFY updateReadyChanged)
    Q_PROPERTY(QString newVersion READ newVersion NOTIFY updateReadyChanged)

public:
    explicit AppUpdater(QObject* parent = nullptr);

    bool updateReady() const { return m_ready; }
    QString newVersion() const { return m_newVersion; }


    Q_INVOKABLE void checkForUpdate();



    Q_INVOKABLE void applyAndRestart();






    bool applyStagedOnStartup();

signals:
    void updateReadyChanged();

private:
    void downloadArchive(const QString& url, const QString& sha256, bool allowFallback = true);


    void unpackAsync(const QString& archivePath, const QString& sha256);
    void onUnpackFinished();


    void writeAndLaunchScript();
    static bool isNewer(const QString& remote, const QString& local);

    QNetworkAccessManager m_net;
    QTimer m_recheck;
    QFutureWatcher<bool> m_unpackWatcher;
    QString m_pendingStage;
    bool m_ready = false;
    bool m_busy = false;
    QString m_newVersion;
    QString m_stagedDir;
};
