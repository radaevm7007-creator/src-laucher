// setup.exe — установщик/лончер Exclusion Launcher (консольный).
//
// Ставит лаунчер в %LOCALAPPDATA%\ExclusionLauncher\app и запускает его.
// Если он уже установлен нужной версии — просто молча запускает.
//
// В консоли — только «Скачивание:» с анимацией прогресса, без лишнего текста.
// Скачивание идёт через системный WinINet (никаких сторонних DLL), распаковка —
// через tar.exe (штатная утилита Windows). Себя не удаляет — иначе поведенческие
// антивирусы принимают установщик за дроппер.

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wininet.h>
#include <shlobj.h>
#include <shobjidl.h>
#include <objbase.h>
#include <tlhelp32.h>

#include <cstdio>
#include <string>
#include <fstream>

#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "wininet.lib")

namespace {

const wchar_t* kAppJsonUrl = L"https://pulsardev.tech/launcher/app/app.json";
const wchar_t* kArchiveUrl = L"https://pulsardev.tech/launcher/app/app.tar.xz";
const wchar_t* kZipUrl     = L"https://pulsardev.tech/launcher/app/app.zip";
const wchar_t* kAppName    = L"Exclusion Launcher";
const wchar_t* kExeName    = L"ExclusionLauncher.exe";

std::wstring knownFolder(REFKNOWNFOLDERID id)
{
    wchar_t* p = nullptr;
    SHGetKnownFolderPath(id, 0, nullptr, &p);
    std::wstring s = p ? p : L"";
    if (p) CoTaskMemFree(p);
    return s;
}

std::wstring appRoot() { return knownFolder(FOLDERID_LocalAppData) + L"\\ExclusionLauncher"; }
std::wstring desktop() { return knownFolder(FOLDERID_Desktop); }

std::wstring lowerPath(std::wstring s)
{
    for (wchar_t& ch : s) ch = (wchar_t)towlower(ch);
    return s;
}

void stopInstalledLauncher(const std::wstring& exePath)
{
    const std::wstring wanted = lowerPath(exePath);
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return;

    PROCESSENTRY32W pe{};
    pe.dwSize = sizeof(pe);
    if (!Process32FirstW(snap, &pe)) {
        CloseHandle(snap);
        return;
    }

    do {
        if (_wcsicmp(pe.szExeFile, kExeName) != 0)
            continue;

        HANDLE proc = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION |
                                  PROCESS_TERMINATE | SYNCHRONIZE,
                                  FALSE, pe.th32ProcessID);
        if (!proc)
            continue;

        wchar_t path[MAX_PATH * 4] = {};
        DWORD size = (DWORD)(sizeof(path) / sizeof(path[0]));
        const bool same = QueryFullProcessImageNameW(proc, 0, path, &size)
                          && lowerPath(path) == wanted;
        if (same) {
            TerminateProcess(proc, 0);
            WaitForSingleObject(proc, 5000);
        }
        CloseHandle(proc);
    } while (Process32NextW(snap, &pe));

    CloseHandle(snap);
}

// Запускает программу; wait=true — ждёт код выхода.
DWORD run(const std::wstring& cmd, bool wait, bool showWindow = false)
{
    STARTUPINFOW si{ sizeof(si) };
    PROCESS_INFORMATION pi{};
    std::wstring line = cmd;
    DWORD flags = showWindow ? 0 : CREATE_NO_WINDOW;
    if (!CreateProcessW(nullptr, line.data(), nullptr, nullptr, FALSE,
                        flags, nullptr, nullptr, &si, &pi))
        return (DWORD)-1;
    DWORD code = 0;
    if (wait) {
        WaitForSingleObject(pi.hProcess, INFINITE);
        GetExitCodeProcess(pi.hProcess, &code);
    }
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    return code;
}

// Достаёт "version":"…" из app.json без полноценного парсера.
std::string jsonVersion(const std::string& json)
{
    auto k = json.find("\"version\"");
    if (k == std::string::npos) return {};
    auto q1 = json.find('"', json.find(':', k) + 1);
    auto q2 = json.find('"', q1 + 1);
    if (q1 == std::string::npos || q2 == std::string::npos) return {};
    return json.substr(q1 + 1, q2 - q1 - 1);
}

// Полоса прогресса, перерисовывается на месте: «Скачивание: [####......] 42%».
void drawProgress(DWORD done, DWORD total, int tick)
{
    const int W = 30;
    static int lastPct = -1;
    if (total > 0) {
        double frac = (double)done / (double)total;
        if (frac > 1.0) frac = 1.0;
        int pct = (int)(frac * 100.0);
        if (pct == lastPct) return;                 // тот же процент — не перерисовываем
        lastPct = pct;
        fputs("\r  Скачивание: [", stdout);
        int fill = (int)(frac * W);
        for (int i = 0; i < W; ++i) putchar(i < fill ? '#' : '.');
        printf("] %3d%%", pct);
    } else {
        // размер неизвестен — бегущий блок
        fputs("\r  Скачивание: [", stdout);
        int pos = tick % W;
        for (int i = 0; i < W; ++i) putchar(i == pos ? '#' : '.');
        printf("]  %lu KB", done / 1024);
    }
    fflush(stdout);
}

// Качает url в память (для маленького app.json).
std::string httpGet(const wchar_t* url)
{
    std::string out;
    HINTERNET hi = InternetOpenW(L"ExclusionSetup", INTERNET_OPEN_TYPE_PRECONFIG, nullptr, nullptr, 0);
    if (!hi) return out;
    HINTERNET hu = InternetOpenUrlW(hi, url, nullptr, 0,
                                    INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE, 0);
    if (hu) {
        char buf[8192]; DWORD got = 0;
        while (InternetReadFile(hu, buf, sizeof(buf), &got) && got > 0)
            out.append(buf, got);
        InternetCloseHandle(hu);
    }
    InternetCloseHandle(hi);
    return out;
}

// Качает url в файл, показывая анимацию прогресса.
bool httpToFile(const wchar_t* url, const std::wstring& path)
{
    HINTERNET hi = InternetOpenW(L"ExclusionSetup", INTERNET_OPEN_TYPE_PRECONFIG, nullptr, nullptr, 0);
    if (!hi) return false;
    HINTERNET hu = InternetOpenUrlW(hi, url, nullptr, 0,
                                    INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE, 0);
    if (!hu) { InternetCloseHandle(hi); return false; }

    DWORD total = 0, len = sizeof(total), idx = 0;
    HttpQueryInfoW(hu, HTTP_QUERY_CONTENT_LENGTH | HTTP_QUERY_FLAG_NUMBER, &total, &len, &idx);

    std::ofstream f(path, std::ios::binary | std::ios::trunc);
    if (!f) { InternetCloseHandle(hu); InternetCloseHandle(hi); return false; }

    char buf[65536]; DWORD got = 0, done = 0; int tick = 0;
    drawProgress(0, total, 0);
    while (InternetReadFile(hu, buf, sizeof(buf), &got) && got > 0) {
        f.write(buf, got);
        done += got;
        drawProgress(done, total, tick++);
    }
    f.close();
    InternetCloseHandle(hu);
    InternetCloseHandle(hi);

    // добить полосу до 100% и перевести строку
    if (total == 0) total = done;
    drawProgress(done ? done : 1, done ? done : 1, tick);
    fputs("\n", stdout);
    return done > 0;
}

// Ярлык на рабочем столе с иконкой лаунчера.
void createShortcut(const std::wstring& target)
{
    IShellLinkW* link = nullptr;
    if (FAILED(CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER,
                                IID_IShellLinkW, (void**)&link)))
        return;
    const std::wstring dir = target.substr(0, target.find_last_of(L'\\'));
    const std::wstring ico = dir + L"\\icon.ico";
    link->SetPath(target.c_str());
    link->SetWorkingDirectory(dir.c_str());
    // Отдельный icon.ico рядом с exe надёжнее иконки из ресурсов exe.
    if (GetFileAttributesW(ico.c_str()) != INVALID_FILE_ATTRIBUTES)
        link->SetIconLocation(ico.c_str(), 0);
    else
        link->SetIconLocation(target.c_str(), 0);
    link->SetDescription(kAppName);
    IPersistFile* pf = nullptr;
    if (SUCCEEDED(link->QueryInterface(IID_IPersistFile, (void**)&pf))) {
        const std::wstring lnk = desktop() + L"\\" + kAppName + L".lnk";
        pf->Save(lnk.c_str(), TRUE);
        pf->Release();
        // Сбрасываем кэш иконок Explorer, чтобы значок появился сразу.
        SHChangeNotify(SHCNE_UPDATEITEM, SHCNF_PATHW, lnk.c_str(), nullptr);
        SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST, nullptr, nullptr);
    }
    link->Release();
}

int fail(const char* msg)
{
    printf("\n  %s\n", msg);
    getchar();
    return 1;
}

} // namespace

int main()
{
    SetConsoleOutputCP(CP_UTF8);
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);

    const std::wstring root    = appRoot();
    const std::wstring appDir  = root + L"\\app";
    const std::wstring exe     = appDir + L"\\" + kExeName;
    const std::wstring verFile = root + L"\\.version";
    const std::wstring archive = root + L"\\app.tar.xz";

    SHCreateDirectoryExW(nullptr, appDir.c_str(), nullptr);

    const std::string remoteVer = jsonVersion(httpGet(kAppJsonUrl));

    bool installed = (GetFileAttributesW(exe.c_str()) != INVALID_FILE_ATTRIBUTES);
    std::string localVer;
    {
        std::ifstream vf(verFile, std::ios::binary);
        if (vf) std::getline(vf, localVer);
    }

    // Уже стоит нужная версия — молча запускаем.
    if (installed && !remoteVer.empty() && localVer == remoteVer) {
        run(L"\"" + exe + L"\"", false, true);
        return 0;
    }

    stopInstalledLauncher(exe);

    // Иначе — качаем и разворачиваем. На современных Windows берём маленький
    // app.tar.xz и распаковываем штатным tar.exe. Если tar.exe нет (Windows до
    // 1803 или урезанная сборка) или он не справился — берём app.zip и
    // разворачиваем через PowerShell Expand-Archive (есть на всех Win10+).
    wchar_t sysdir[MAX_PATH] = {};
    GetSystemDirectoryW(sysdir, MAX_PATH);
    const std::wstring tarExe = std::wstring(sysdir) + L"\\tar.exe";
    const bool haveTar = GetFileAttributesW(tarExe.c_str()) != INVALID_FILE_ATTRIBUTES;

    bool downloaded = false, extracted = false;

    if (haveTar) {
        if (httpToFile(kArchiveUrl, archive) &&
            GetFileAttributesW(archive.c_str()) != INVALID_FILE_ATTRIBUTES) {
            downloaded = true;
            if (run(L"\"" + tarExe + L"\" -xf \"" + archive + L"\" -C \"" + appDir + L"\"", true) == 0)
                extracted = true;
            DeleteFileW(archive.c_str());
        }
    }

    if (!extracted) {
        const std::wstring zip = root + L"\\app.zip";
        if (httpToFile(kZipUrl, zip) &&
            GetFileAttributesW(zip.c_str()) != INVALID_FILE_ATTRIBUTES) {
            downloaded = true;
            const std::wstring ps =
                L"powershell -NoProfile -ExecutionPolicy Bypass -Command "
                L"\"Expand-Archive -LiteralPath '" + zip +
                L"' -DestinationPath '" + appDir + L"' -Force\"";
            if (run(ps, true) == 0)
                extracted = true;
            DeleteFileW(zip.c_str());
        }
    }

    if (!extracted)
        return fail(downloaded ? "Не удалось распаковать архив."
                               : "Не удалось скачать. Проверьте интернет и запустите снова.");

    if (!remoteVer.empty()) {
        std::ofstream vf(verFile, std::ios::binary | std::ios::trunc);
        vf << remoteVer;
    }
    createShortcut(exe);

    run(L"\"" + exe + L"\"", false, true);
    return 0;
}
