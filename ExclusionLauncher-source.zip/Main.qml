import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Effects
import "components"
import "pages"

ApplicationWindow {
    id: window
    width: Math.min(1180, Screen.width - 80)
    height: Math.min(740, Screen.height - 80)
    minimumWidth: Math.min(980, Screen.width - 80)
    minimumHeight: Math.min(640, Screen.height - 80)
    visible: true
    // В software-фолбэке (после неудачного прошлого старта) прозрачность и
    // слои отключаем: именно они не дают окну появиться на проблемных
    // драйверах. Окно становится прямоугольным — это сознательный компромисс.
    color: SoftwareRender ? "#080B12" : "transparent"
    flags: Qt.Window | Qt.FramelessWindowHint
    title: "Exclusion Launcher"

    property int currentPage: 0
    property int windowRadius: window.visibility === Window.Maximized ? 0 : 14

    Component.onCompleted: {
        if (window.visibility === Window.Maximized || window.visibility === Window.FullScreen)
            window.visibility = Window.Windowed
        window.x = Screen.virtualX + Math.max(0, (Screen.width - window.width) / 2)
        window.y = Screen.virtualY + Math.max(0, (Screen.height - window.height) / 2)
    }

    onVisibilityChanged: {
        if (window.visibility === Window.Maximized || window.visibility === Window.FullScreen)
            window.visibility = Window.Windowed
    }

    Connections {
        target: GameLauncher




        function onGameWindowReady(id) {  }
        function onGameFinished(id, exitCode) {  }
    }













    property int _lastNewsCount: 0
    Connections {
        target: NewsModel
        function onItemsChanged() {
            var n = NewsModel.items.length
            if (n > window._lastNewsCount && window._lastNewsCount > 0 && !window.active)
                window.alert(0)
            window._lastNewsCount = n
        }
    }



    function tryPlay() {


        if (DownloadManager.busy || GameLauncher.preparing) return
        var list = ManifestManager.clients
        if (list.length === 0) return

        var selectedId = AppSettings.selectedClientId
        var target = null
        for (var i = 0; i < list.length; ++i) {
            if (list[i].id === selectedId) { target = list[i]; break }
        }
        if (!target) target = list[0]

        AppSettings.selectedClientId = target.id
        GameLauncher.launch(target)
    }


    Rectangle {
        id: windowShape
        anchors.fill: parent
        radius: window.windowRadius
        color: "white"
        visible: !SoftwareRender
        layer.enabled: !SoftwareRender
    }


    Item {
        id: appRoot
        anchors.fill: parent
        layer.enabled: !SoftwareRender
        layer.effect: MultiEffect {
            maskEnabled: true
            maskSource: windowShape
            maskThresholdMin: 0.5
            maskSpreadAtMin: 0.5
        }


        Rectangle {
            anchors.fill: parent
            color: "#080B12"
        }


        Image {
            id: appBg
            anchors.fill: parent


            readonly property string customBg:
                AppSettings.backgroundFile && AppSettings.backgroundFile.length > 0
                    ? "file:///" + AppSettings.backgroundFile.replace(/\\/g, "/") : ""
            source: customBg.length > 0
                        ? customBg
                        : ((AssetCache && AssetCache.readyCount >= 0 && AssetCache.hasAsset("app_bg.jpg"))
                           ? "image://assets/app_bg.jpg" : "")
            fillMode: Image.Stretch
            asynchronous: true
            cache: true
            visible: false
        }
        MultiEffect {
            source: appBg
            anchors.fill: parent
            visible: appBg.status === Image.Ready
            blurEnabled: AppSettings.bgBlur > 0
            blur: 1.0
            blurMax: Math.max(1, Math.round(48 * AppSettings.bgBlur / 100))
            brightness: -0.08
            saturation: -0.05
        }

        Rectangle {
            anchors.fill: parent
            visible: appBg.status !== Image.Ready
            gradient: Gradient {
                orientation: Gradient.Vertical
                GradientStop { position: 0.0; color: "#0C1220" }
                GradientStop { position: 1.0; color: "#070B12" }
            }
        }

        Rectangle {
            anchors.fill: parent
            color: "#40040812"
            visible: appBg.status === Image.Ready
        }


        StarParticles {
            anchors.fill: parent
            visible: AppSettings.snowEnabled
        }

        NavigationBar {
            id: nav
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            hostWindow: window
            currentIndex: window.currentPage
            onNavigate: function(index) { window.currentPage = index }
        }

        Rectangle {
            id: navSep
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: nav.bottom
            height: 1
            color: "#151F30"
        }

        Item {
            id: contentHost
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: navSep.bottom
            anchors.bottom: parent.bottom
            anchors.leftMargin: 20
            anchors.rightMargin: 20
            anchors.topMargin: 18
            anchors.bottomMargin: 18

            HomePage {
                anchors.fill: parent
                visible: window.currentPage === 0
                onOpenNews: window.currentPage = 1
                onOpenClients: window.currentPage = 2
                onPlay: window.tryPlay()
            }
            NewsPage {
                anchors.fill: parent
                visible: window.currentPage === 1
            }
            ClientsPage {
                anchors.fill: parent
                visible: window.currentPage === 2
                onViewImages: function(urls, startIndex) { imageViewer.open(urls, startIndex) }
                onRequestPlay: function(id) {
                    AppSettings.selectedClientId = id
                    window.currentPage = 0
                    window.tryPlay()
                }
            }
            ConfigsPage {
                anchors.fill: parent
                visible: window.currentPage === 3
            }
            SettingsPage {
                anchors.fill: parent
                visible: window.currentPage === 4
            }
        }

        UpdateOverlay {
            anchors.fill: parent
        }



        ImageViewer {
            id: imageViewer
            anchors.fill: parent
        }


        LoadingSplash {
            id: splash
            anchors.fill: parent


            preloadUrls: []

            Component.onCompleted: {

                if (NewsModel && typeof NewsModel.refresh === "function") NewsModel.refresh()
                if (ManifestManager && typeof ManifestManager.refresh === "function") ManifestManager.refresh()
                if (RuntimeManager && typeof RuntimeManager.refreshManifest === "function") RuntimeManager.refreshManifest()
                if (ConfigManager && typeof ConfigManager.refresh === "function") ConfigManager.refresh()


                if (PhotoStore && typeof PhotoStore.sync === "function") PhotoStore.sync()



                if (!NewsModel.loading)       splash.newsReady = true
                if (!ManifestManager.loading) splash.manifestReady = true
            }



            Connections {
                target: NewsModel
                function onLoadingChanged() {
                    if (!NewsModel.loading) splash.newsReady = true
                }
            }
            Connections {
                target: ManifestManager
                function onLoadingChanged() {
                    if (!ManifestManager.loading) splash.manifestReady = true
                }
            }










            assetsReady: true
        }




        Item {
            id: disclaimer
            anchors.fill: parent
            z: 150
            visible: !AppSettings.disclaimerAccepted

            Rectangle {
                anchors.fill: parent
                color: "#D8060912"
                MouseArea { anchors.fill: parent; hoverEnabled: true }
            }

            Rectangle {
                anchors.centerIn: parent
                width: Math.min(560, parent.width - 60)
                height: discCol.implicitHeight + 44
                radius: 16
                color: "#F20E1622"
                border.width: 1
                border.color: "#26364A"

                ColumnLayout {
                    id: discCol
                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    anchors.margins: 22
                    spacing: 14

                    Text {
                        Layout.fillWidth: true
                        text: "Прежде чем начать"
                        color: "#F1F4FA"
                        font.pixelSize: 18
                        font.bold: true
                    }
                    Text {
                        id: discText
                        Layout.fillWidth: true
                        wrapMode: Text.WordWrap
                        color: "#C4CCDA"
                        font.pixelSize: 13
                        lineHeight: 1.25


                        textFormat: Text.RichText
                        onLinkActivated: (link) => Qt.openUrlExternally(link)

                        HoverHandler {
                            cursorShape: discText.hoveredLink.length > 0
                                         ? Qt.PointingHandCursor : Qt.ArrowCursor
                        }
                        text: "Все клиенты в лаунчере — <b>не наши</b>. Они взяты из <b>открытых "
                              + "источников</b> (YouGame, Telegram и др.).<br><br>"
                              + "Большинство кряков взяты из Telegram-канала "
                              + "<a href=\"https://t.me/soezproject\" style=\"color:#41B4E6; text-decoration:none;\">@soezproject</a>.<br><br>"
                              + "Некоторые клиенты могут <b>крашиться и лагать</b> — это будет "
                              + "постепенно исправляться в обновлениях.<br><br>"
                              + "Нажимая «Принимаю», вы соглашаетесь со всем вышеперечисленным."
                    }

                    Rectangle {
                        Layout.alignment: Qt.AlignRight
                        Layout.topMargin: 4
                        Layout.preferredWidth: 150
                        Layout.preferredHeight: 40
                        radius: 10
                        color: okMouse.containsMouse ? Qt.lighter(AppSettings.accentColor, 1.08)
                                                     : AppSettings.accentColor
                        Behavior on color { ColorAnimation { duration: 120 } }
                        Text {
                            anchors.centerIn: parent
                            text: "Понятно, принимаю"
                            color: "#08131F"
                            font.pixelSize: 12
                            font.bold: true
                        }
                        MouseArea {
                            id: okMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: AppSettings.disclaimerAccepted = true
                        }
                    }
                }
            }
        }


        Rectangle {
            id: errorToast


            readonly property string msg: DownloadManager.errorMessage.length > 0
                                          ? DownloadManager.errorMessage
                                          : GameLauncher.lastError
            readonly property bool shown: msg.length > 0

            width: 380
            height: 82
            radius: 12
            anchors.right: parent.right
            anchors.bottom: parent.bottom
            anchors.margins: 20
            color: "#26141A"
            border.width: 1
            border.color: "#71303D"

            visible: opacity > 0
            opacity: shown ? 1 : 0
            z: 60

            Behavior on opacity { NumberAnimation { duration: 220; easing.type: Easing.InOutQuad } }



            Timer {
                id: errorAutoHide
                interval: 10000
                onTriggered: { DownloadManager.clearError(); GameLauncher.clearError() }
            }
            onShownChanged: shown ? errorAutoHide.restart() : errorAutoHide.stop()
            Connections {
                target: DownloadManager


                function onErrorChanged() {
                    if (DownloadManager.errorMessage.length > 0) errorAutoHide.restart()
                }
            }
            Connections {
                target: GameLauncher
                function onErrorChanged() {
                    if (GameLauncher.lastError.length > 0) errorAutoHide.restart()
                }
            }

            RowLayout {
                anchors.fill: parent
                anchors.margins: 14
                spacing: 12
                Text { text: "!"; color: "#FF7587"; font.pixelSize: 20; font.bold: true }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 3
                    Text {
                        text: (AppI18n.language, AppI18n.t("error.title"))
                        color: "#FFE5E9"; font.pixelSize: 12; font.bold: true
                    }
                    Text {
                        Layout.fillWidth: true
                        text: errorToast.msg
                        color: "#C798A1"
                        wrapMode: Text.WordWrap
                        font.pixelSize: 10
                        maximumLineCount: 2
                        elide: Text.ElideRight
                    }
                }
                Text {
                    text: "×"; color: "#CFAAB2"; font.pixelSize: 16
                    MouseArea { anchors.fill: parent; anchors.margins: -6; cursorShape: Qt.PointingHandCursor; onClicked: { DownloadManager.clearError(); GameLauncher.clearError() } }
                }
            }
        }
    }







    Rectangle {
        id: updateBanner
        readonly property bool show: false

        width: Math.min(520, parent.width - 40)
        height: bannerRow.implicitHeight + 24
        radius: 14
        color: "#F2101A2C"
        border.width: 1
        border.color: "#2A3A54"
        z: 90

        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom

        anchors.bottomMargin: show ? 22 : -(height + 40)
        Behavior on anchors.bottomMargin { NumberAnimation { duration: 320; easing.type: Easing.OutCubic } }

        RowLayout {
            id: bannerRow
            anchors.fill: parent
            anchors.margins: 12
            spacing: 14

            ColumnLayout {
                Layout.fillWidth: true
                spacing: 2
                Text {
                    Layout.fillWidth: true
                    text: "Вышло обновление " + (AppUpdater.newVersion || "")
                    color: "#F1F4FA"
                    font.pixelSize: 14
                    font.bold: true
                }
                Text {
                    Layout.fillWidth: true
                    text: "Можно обновиться сейчас — лаунчер перезапустится сам."
                    color: "#9AA6B8"
                    font.pixelSize: 11
                }
            }
            Rectangle {
                Layout.preferredWidth: updBtnText.width + 34
                Layout.preferredHeight: 36
                radius: 9
                color: updMouse.containsMouse ? Qt.lighter(AppSettings.accentColor, 1.1)
                                              : AppSettings.accentColor
                Behavior on color { ColorAnimation { duration: 120 } }
                Text {
                    id: updBtnText
                    anchors.centerIn: parent
                    text: "Обновить"
                    color: "#08131F"
                    font.pixelSize: 12
                    font.bold: true
                }
                MouseArea {
                    id: updMouse
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: AppUpdater.applyAndRestart()
                }
            }
        }
    }


    Rectangle {
        anchors.fill: parent
        color: "transparent"
        radius: window.windowRadius
        border.width: window.visibility === Window.Maximized ? 0 : 1
        border.color: "#1E2A3E"
        z: 100
    }
}


