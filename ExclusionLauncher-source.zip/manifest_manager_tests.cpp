#include "core/ManifestManager.hpp"

#include <QtTest/QtTest>

class ManifestManagerTests : public QObject
{
    Q_OBJECT

private slots:
    void ratingResponseFieldsNormalizeAliases()
    {
        const QByteArray body = R"({"averageRating":4.25,"ratingsCount":7,"userRating":5})";
        const QVariantMap fields = ManifestManager::ratingFieldsFromResponse(body);

        QCOMPARE(fields.value(QStringLiteral("rating")).toDouble(), 4.25);
        QCOMPARE(fields.value(QStringLiteral("votes")).toInt(), 7);
        QCOMPARE(fields.value(QStringLiteral("userRating")).toInt(), 5);
    }
};

QTEST_MAIN(ManifestManagerTests)

#include "manifest_manager_tests.moc"
