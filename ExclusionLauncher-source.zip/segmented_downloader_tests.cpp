#include "core/SegmentedDownloader.hpp"

#include <QtTest/QtTest>

class SegmentedDownloaderTests : public QObject
{
    Q_OBJECT

private slots:
    void retryDelayBacksOffWithoutHammeringServer()
    {
        QCOMPARE(SegmentedDownloader::retryDelayMsForAttempt(1), 750);
        QCOMPARE(SegmentedDownloader::retryDelayMsForAttempt(2), 1500);
        QCOMPARE(SegmentedDownloader::retryDelayMsForAttempt(3), 3000);
        QCOMPARE(SegmentedDownloader::retryDelayMsForAttempt(8), 5000);
    }

    void primaryLauncherUrlFallsBackToServerIp()
    {
        QCOMPARE(SegmentedDownloader::fallbackUrlForPrimary(
                     QStringLiteral("https://pulsardev.tech/launcher/clients/wild.tar.xz")),
                 QStringLiteral("http://144.31.164.188/launcher/clients/wild.tar.xz"));
        QCOMPARE(SegmentedDownloader::fallbackUrlForPrimary(
                     QStringLiteral("https://example.com/launcher/clients/wild.tar.xz")),
                 QString());
        QCOMPARE(SegmentedDownloader::fallbackUrlForPrimary(
                     QStringLiteral("https://pulsardev.tech/not-launcher/wild.tar.xz")),
                 QString());
    }
};

QTEST_MAIN(SegmentedDownloaderTests)

#include "segmented_downloader_tests.moc"
