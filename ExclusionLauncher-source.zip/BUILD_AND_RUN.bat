@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title Exclusion Launcher - Build and Run

set "QT_DIR=%QTDIR%"

if not defined QT_DIR (
    for /f "delims=" %%Q in ('dir /b /ad "C:\Qt\6.*\msvc2022_64" 2^>nul') do set "QT_DIR=C:\Qt\%%Q\msvc2022_64"
)

if not exist "%QT_DIR%\bin\windeployqt.exe" (
    echo.
    echo [ERROR] Qt 6 MSVC 2022 x64 not found.
    echo.
    echo Install Qt 6.5+ with component: MSVC 2022 64-bit
    echo or set environment variable QTDIR to e.g.:
    echo   C:\Qt\6.8.3\msvc2022_64
    echo.
    echo You can also run SETUP_QT_AND_RUN.bat for automatic setup.
    echo.
    pause
    exit /b 1
)

where cmake >nul 2>nul
if errorlevel 1 (
    echo [ERROR] CMake not found in PATH.
    echo Install CMake and reopen this BAT.
    pause
    exit /b 1
)

set "BUILD_DIR=%CD%\build"
set "CACHE_FILE=%BUILD_DIR%\CMakeCache.txt"
set "SRC_DIR_FWD=%CD:\=/%"

if exist "%CACHE_FILE%" (
    findstr /C:"CMAKE_HOME_DIRECTORY:INTERNAL=%SRC_DIR_FWD%" "%CACHE_FILE%" >nul
    if errorlevel 1 (
        echo [INFO] Removing stale CMake build directory...
        rmdir /s /q "%BUILD_DIR%"
        if exist "%BUILD_DIR%" goto :fail
    )
)

echo [1/4] Configuring CMake...
cmake -S . -B "%BUILD_DIR%" -G "Visual Studio 17 2022" -A x64 -DCMAKE_PREFIX_PATH="%QT_DIR%"
if errorlevel 1 goto :fail

echo [2/4] Building Release...
cmake --build "%BUILD_DIR%" --config Release --parallel
if errorlevel 1 goto :fail

echo [3/4] Deploying Qt runtime...
"%QT_DIR%\bin\windeployqt.exe" --release --qmldir "%CD%\qml" "%BUILD_DIR%\Release\ExclusionLauncher.exe"
if errorlevel 1 goto :fail

echo [4/4] Starting Exclusion Launcher...
start "" "%BUILD_DIR%\Release\ExclusionLauncher.exe"
exit /b 0

:fail
echo.
echo [ERROR] Build failed. See messages above.
pause
exit /b 1
