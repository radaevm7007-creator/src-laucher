#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ExclusionSetup — установщик/лончер Exclusion Launcher на Python.

Полный аналог setup.cpp. Ставит лаунчер в %LOCALAPPDATA%\\ExclusionLauncher\\app
и запускает. Если нужная версия уже стоит — просто молча запускает.

Отличие от C++-версии: распаковка .tar.xz идёт штатным tarfile+lzma (стандартная
библиотека Python), поэтому НЕ нужны ни tar.exe, ни 7za — работает на любой
Windows, где есть Python. .zip разворачивается zipfile. Себя не удаляет — иначе
поведенческие антивирусы принимают установщик за дроппер.

Запуск:  python setup.py
Сборка в .exe:  pyinstaller --onefile --console --name ExclusionSetup setup.py
"""

import json
import os
import subprocess
import sys
import tarfile
import urllib.request
import zipfile

APP_JSON_URL = "https://pulsardev.tech/launcher/app/app.json"
ARCHIVE_URL  = "https://pulsardev.tech/launcher/app/app.tar.xz"
ZIP_URL      = "https://pulsardev.tech/launcher/app/app.zip"
APP_NAME     = "Exclusion Launcher"
EXE_NAME     = "ExclusionLauncher.exe"
USER_AGENT   = "ExclusionSetup"          # под этим UA nginx-гейт пропускает

CREATE_NO_WINDOW = 0x08000000


def app_root() -> str:
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(base, "ExclusionLauncher")


def http_get(url: str) -> bytes:
    """Качает url в память (для маленького app.json)."""
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.read()
    except Exception:
        return b""


def draw_progress(done: int, total: int) -> None:
    """Полоса прогресса на месте: «Скачивание: [####......] 42%»."""
    width = 30
    if total > 0:
        frac = min(done / total, 1.0)
        fill = int(frac * width)
        bar = "#" * fill + "." * (width - fill)
        sys.stdout.write(f"\r  Скачивание: [{bar}] {int(frac * 100):3d}%")
    else:
        sys.stdout.write(f"\r  Скачивание: {done // 1024} КБ")
    sys.stdout.flush()


def download(url: str, path: str) -> bool:
    """Качает url в файл с анимацией прогресса. True — если что-то скачалось."""
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            total = int(r.headers.get("Content-Length") or 0)
            done = 0
            draw_progress(0, total)
            with open(path, "wb") as f:
                while True:
                    chunk = r.read(65536)
                    if not chunk:
                        break
                    f.write(chunk)
                    done += len(chunk)
                    draw_progress(done, total)
        draw_progress(done or 1, done or 1)
        sys.stdout.write("\n")
        return done > 0
    except Exception:
        sys.stdout.write("\n")
        return False


def json_version(data: bytes) -> str:
    try:
        return json.loads(data.decode("utf-8", "ignore")).get("version", "")
    except Exception:
        return ""


def extract(archive: str, dest: str) -> None:
    """Распаковка .tar.xz / .tar.gz / .tar / .zip средствами стандартной
    библиотеки — без внешних утилит."""
    low = archive.lower()
    if low.endswith((".tar.xz", ".txz")):
        mode = "r:xz"
    elif low.endswith((".tar.gz", ".tgz")):
        mode = "r:gz"
    elif low.endswith(".tar"):
        mode = "r:"
    elif low.endswith(".zip"):
        with zipfile.ZipFile(archive) as z:
            z.extractall(dest)
        return
    else:
        raise ValueError("неизвестный формат архива")

    with tarfile.open(archive, mode) as t:
        try:
            t.extractall(dest, filter="data")   # Python 3.12+: безопасный фильтр
        except TypeError:
            t.extractall(dest)


def make_shortcut(target: str) -> None:
    """Ярлык на рабочем столе с иконкой лаунчера (через WScript.Shell)."""
    app_dir = os.path.dirname(target)
    ico = os.path.join(app_dir, "icon.ico")
    icon = ico if os.path.exists(ico) else target
    ps = (
        "$w=New-Object -ComObject WScript.Shell;"
        "$d=[Environment]::GetFolderPath('Desktop');"
        f"$s=$w.CreateShortcut((Join-Path $d '{APP_NAME}.lnk'));"
        f"$s.TargetPath='{target}';"
        f"$s.WorkingDirectory='{app_dir}';"
        f"$s.IconLocation='{icon}';"
        f"$s.Description='{APP_NAME}';"
        "$s.Save()"
    )
    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
            creationflags=CREATE_NO_WINDOW, timeout=30,
        )
    except Exception:
        pass


def launch(exe: str) -> None:
    try:
        os.startfile(exe)                       # noqa: S606 (наш же бинарь)
    except Exception:
        subprocess.Popen([exe], cwd=os.path.dirname(exe))


def fail(msg: str) -> int:
    sys.stdout.write("\n  " + msg + "\n")
    try:
        input()
    except Exception:
        pass
    return 1


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    root = app_root()
    app_dir = os.path.join(root, "app")
    exe = os.path.join(app_dir, EXE_NAME)
    ver_file = os.path.join(root, ".version")
    os.makedirs(app_dir, exist_ok=True)

    remote_ver = json_version(http_get(APP_JSON_URL))

    installed = os.path.exists(exe)
    local_ver = ""
    if os.path.exists(ver_file):
        try:
            with open(ver_file, encoding="utf-8", errors="ignore") as f:
                local_ver = f.readline().strip()
        except Exception:
            pass

    # Уже стоит нужная версия — молча запускаем.
    if installed and remote_ver and local_ver == remote_ver:
        launch(exe)
        return 0

    # Иначе — качаем и разворачиваем. Сначала маленький .tar.xz; если не вышло —
    # .zip. Распаковка обоих — средствами Python, без tar.exe/7za.
    downloaded = extracted = False

    archive = os.path.join(root, "app.tar.xz")
    if download(ARCHIVE_URL, archive) and os.path.exists(archive):
        downloaded = True
        try:
            extract(archive, app_dir)
            extracted = True
        except Exception:
            extracted = False
    if os.path.exists(archive):
        try:
            os.remove(archive)
        except Exception:
            pass

    if not extracted:
        zip_path = os.path.join(root, "app.zip")
        if download(ZIP_URL, zip_path) and os.path.exists(zip_path):
            downloaded = True
            try:
                extract(zip_path, app_dir)
                extracted = True
            except Exception:
                extracted = False
        if os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except Exception:
                pass

    if not extracted:
        return fail("Не удалось распаковать архив." if downloaded
                    else "Не удалось скачать. Проверьте интернет и запустите снова.")

    if remote_ver:
        try:
            with open(ver_file, "w", encoding="utf-8") as f:
                f.write(remote_ver)
        except Exception:
            pass

    make_shortcut(exe)
    launch(exe)
    return 0


if __name__ == "__main__":
    sys.exit(main())
