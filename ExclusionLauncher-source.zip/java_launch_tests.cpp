#include "core/JavaLaunch.hpp"

#include <QtTest/QtTest>

class JavaLaunchTests : public QObject
{
    Q_OBJECT

private slots:
    void removesAllHeapArgumentsAndKeepsSafeOrder()
    {
        QStringList args = {
            QStringLiteral("-Dfoo=bar"),
            QStringLiteral("-Xms4096M"),
            QStringLiteral("-xMx512M"),
            QStringLiteral("-XX:InitialHeapSize=4g"),
            QStringLiteral("-XX:MaxHeapSize=512m"),
            QStringLiteral("-Xms"),
            QStringLiteral("2G"),
            QStringLiteral("-Xmx"),
            QStringLiteral("1G"),
        };

        JavaLaunch::applyMemoryArgs(args, 2048);

        QCOMPARE(args.at(0), QStringLiteral("-Xms512M"));
        QCOMPARE(args.at(1), QStringLiteral("-Xmx2048M"));
        QVERIFY(args.contains(QStringLiteral("-Dfoo=bar")));
        for (const QString& arg : args.mid(2)) {
            QVERIFY2(!arg.startsWith(QStringLiteral("-Xms"), Qt::CaseInsensitive), qPrintable(arg));
            QVERIFY2(!arg.startsWith(QStringLiteral("-Xmx"), Qt::CaseInsensitive), qPrintable(arg));
            QVERIFY2(!arg.startsWith(QStringLiteral("-XX:InitialHeapSize"), Qt::CaseInsensitive), qPrintable(arg));
            QVERIFY2(!arg.startsWith(QStringLiteral("-XX:MaxHeapSize"), Qt::CaseInsensitive), qPrintable(arg));
        }
    }

    void removesExternalJavaOptionsFromEnvironment()
    {
        qputenv("_JAVA_OPTIONS", "-Xmx512M");
        qputenv("JAVA_TOOL_OPTIONS", "-Xms4G");
        qputenv("JDK_JAVA_OPTIONS", "-XX:MaxHeapSize=512m");

        QStringList removed;
        const QProcessEnvironment env = JavaLaunch::cleanProcessEnvironment(&removed);

        QVERIFY(!env.contains(QStringLiteral("_JAVA_OPTIONS")));
        QVERIFY(!env.contains(QStringLiteral("JAVA_TOOL_OPTIONS")));
        QVERIFY(!env.contains(QStringLiteral("JDK_JAVA_OPTIONS")));
        QVERIFY(removed.contains(QStringLiteral("_JAVA_OPTIONS")));
        QVERIFY(removed.contains(QStringLiteral("JAVA_TOOL_OPTIONS")));
        QVERIFY(removed.contains(QStringLiteral("JDK_JAVA_OPTIONS")));

        qunsetenv("_JAVA_OPTIONS");
        qunsetenv("JAVA_TOOL_OPTIONS");
        qunsetenv("JDK_JAVA_OPTIONS");
    }
};

QTEST_MAIN(JavaLaunchTests)

#include "java_launch_tests.moc"
