import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import "../components"

Item {
    id: root
    property int section: 0


    function tr(key) { return (AppI18n.language, AppI18n.t(key)) }

    RowLayout {
        anchors.fill: parent
        spacing: 18


        Rectangle {
            Layout.preferredWidth: 220
            Layout.fillHeight: true
            radius: 14
            color: "#B80F1622"
            border.width: 1
            border.color: "#1B2635"

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 12
                spacing: 4

                Repeater {
                    model: [ root.tr("settings.design"),
                             root.tr("settings.game"),
                             root.tr("settings.common") ]
                    delegate: Rectangle {
                        required property int index
                        required property string modelData
                        Layout.fillWidth: true
                        Layout.preferredHeight: 46
                        radius: 10
                        color: root.section === index
                                    ? Qt.rgba(AppSettings.accentColor.r,
                                              AppSettings.accentColor.g,
                                              AppSettings.accentColor.b, 0.16)
                                    : (rowMouse.containsMouse ? "#121A26" : "transparent")
                        Behavior on color { ColorAnimation { duration: 120 } }


                        Rectangle {
                            width: 4
                            height: parent.height - 14
                            radius: 2
                            anchors.left: parent.left
                            anchors.leftMargin: 4
                            anchors.verticalCenter: parent.verticalCenter
                            color: AppSettings.accentColor
                            visible: root.section === index
                        }

                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            anchors.left: parent.left
                            anchors.leftMargin: 18
                            text: modelData
                            color: root.section === index ? "#FFFFFF" : "#B0B9C8"
                            font.pixelSize: 14
                            font.bold: true
                            font.letterSpacing: 0.4
                        }

                        MouseArea {
                            id: rowMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: root.section = index
                        }
                    }
                }

                Item { Layout.fillHeight: true }
            }
        }


        Rectangle {
            Layout.fillWidth: true
            Layout.fillHeight: true
            radius: 14
            color: "#B80F1622"
            border.width: 1
            border.color: "#1B2635"
            clip: true

            StackLayout {
                anchors.fill: parent
                anchors.margins: 22
                currentIndex: root.section


                ScrollView {
                    id: svDesign
                    clip: true
                    ScrollBar.horizontal.policy: ScrollBar.AlwaysOff
                    contentWidth: availableWidth

                    ColumnLayout {
                        width: svDesign.availableWidth
                        spacing: 10

                        Text {
                            text: root.tr("settings.designTitle")
                            color: "#F1F4FA"
                            font.pixelSize: 18
                            font.bold: true
                            Layout.bottomMargin: 8
                        }

                        SettingRow {
                            title: root.tr("settings.accent")
                            description: root.tr("settings.accentDesc")

                            Row {
                                spacing: 10
                                Repeater {
                                    model: ["#E056A1", "#4CA8FF", "#E56765", "#4CD97B", "#E5D157", "#8A63F5"]
                                    delegate: Rectangle {
                                        required property int index
                                        required property string modelData
                                        width: 36; height: 36; radius: 18
                                        color: modelData
                                        border.width: AppSettings.accentColor === modelData ? 3 : (colMouse.containsMouse ? 2 : 0)
                                        border.color: "#FFFFFF"
                                        Behavior on border.width { NumberAnimation { duration: 120 } }
                                        scale: AppSettings.accentColor === modelData ? 1.1 : 1.0
                                        Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutBack } }
                                        MouseArea {
                                            id: colMouse
                                            anchors.fill: parent
                                            hoverEnabled: true
                                            cursorShape: Qt.PointingHandCursor
                                            onClicked: AppSettings.accentColor = modelData
                                        }
                                    }
                                }
                            }
                        }

                        SettingRow {
                            title: root.tr("settings.stars")
                            description: root.tr("settings.starsDesc")
                            ExclusionToggle {
                                value: AppSettings.snowEnabled
                                onChanged: function(newValue) { AppSettings.snowEnabled = newValue }
                            }
                        }

                        SettingRow {
                            title: root.tr("settings.bg")
                            description: AppSettings.backgroundFile.length > 0
                                             ? AppSettings.backgroundFile
                                             : root.tr("settings.bgDesc")

                            Row {
                                spacing: 10

                                Rectangle {
                                    width: bgPickText.width + 30; height: 32; radius: 8
                                    color: bgPickMouse.containsMouse
                                             ? Qt.lighter(AppSettings.accentColor, 1.12)
                                             : AppSettings.accentColor
                                    Behavior on color { ColorAnimation { duration: 120 } }
                                    Text {
                                        id: bgPickText
                                        anchors.centerIn: parent
                                        text: root.tr("settings.bgPick")
                                        color: "#08131F"; font.pixelSize: 11; font.bold: true
                                    }
                                    MouseArea {
                                        id: bgPickMouse
                                        anchors.fill: parent
                                        hoverEnabled: true
                                        cursorShape: Qt.PointingHandCursor
                                        onClicked: bgDialog.open()
                                    }
                                }

                                Rectangle {
                                    width: bgResetText.width + 30; height: 32; radius: 8
                                    color: bgResetMouse.containsMouse ? "#1B2434" : "#131B27"
                                    border.width: 1
                                    border.color: bgResetMouse.containsMouse ? "#3A4E68" : "#26364A"
                                    Behavior on color { ColorAnimation { duration: 120 } }
                                    Behavior on border.color { ColorAnimation { duration: 120 } }
                                    Text {
                                        id: bgResetText
                                        anchors.centerIn: parent
                                        text: root.tr("settings.bgReset")
                                        color: "#B9C1CE"; font.pixelSize: 11; font.bold: true
                                    }
                                    MouseArea {
                                        id: bgResetMouse
                                        anchors.fill: parent
                                        hoverEnabled: true
                                        cursorShape: Qt.PointingHandCursor
                                        onClicked: {
                                            AppSettings.backgroundFile = ""
                                            AppSettings.bgBlur = 0
                                        }
                                    }
                                }
                            }
                        }

                        SettingRow {
                            title: root.tr("settings.bgBlur")
                            description: AppSettings.bgBlur === 0
                                             ? root.tr("settings.bgBlurOff")
                                             : AppSettings.bgBlur + "%"

                            RowLayout {
                                spacing: 10
                                Slider {
                                    id: blurSlider
                                    Layout.preferredWidth: 260
                                    Layout.alignment: Qt.AlignVCenter
                                    from: 0
                                    to: 100
                                    stepSize: 1
                                    value: AppSettings.bgBlur
                                    onMoved: AppSettings.bgBlur = Math.round(value)

                                    background: Rectangle {
                                        x: blurSlider.leftPadding
                                        y: blurSlider.topPadding + blurSlider.availableHeight / 2 - height / 2
                                        width: blurSlider.availableWidth
                                        height: 4
                                        radius: 2
                                        color: "#1A2434"
                                        Rectangle {
                                            width: blurSlider.visualPosition * parent.width
                                            height: parent.height
                                            radius: 2
                                            color: AppSettings.accentColor
                                        }
                                    }
                                    handle: Rectangle {
                                        x: blurSlider.leftPadding + blurSlider.visualPosition * (blurSlider.availableWidth - width)
                                        y: blurSlider.topPadding + blurSlider.availableHeight / 2 - height / 2
                                        width: 18; height: 18; radius: 9
                                        color: blurSlider.pressed
                                                 ? Qt.lighter(AppSettings.accentColor, 1.15)
                                                 : AppSettings.accentColor
                                        border.width: 2
                                        border.color: "#0B1220"
                                        Behavior on color { ColorAnimation { duration: 120 } }
                                    }
                                }

                                Rectangle {
                                    width: 54; height: 32; radius: 8
                                    color: "#0B1220"
                                    border.width: 1
                                    border.color: "#26364A"
                                    Text {
                                        anchors.centerIn: parent
                                        text: AppSettings.bgBlur + "%"
                                        color: "#EAEFF7"
                                        font.pixelSize: 11
                                        font.bold: true
                                    }
                                }
                            }
                        }
                    }
                }


                ScrollView {
                    id: svGame
                    clip: true
                    ScrollBar.horizontal.policy: ScrollBar.AlwaysOff
                    contentWidth: availableWidth

                    ColumnLayout {
                        width: svGame.availableWidth
                        spacing: 10

                        Text {
                            text: root.tr("settings.gameTitle")
                            color: "#F1F4FA"
                            font.pixelSize: 18
                            font.bold: true
                            Layout.bottomMargin: 8
                        }


                        SettingRow {
                            title: root.tr("settings.memory")
                            description: root.tr("settings.memoryDesc")

                            RowLayout {
                                spacing: 12
                                Slider {
                                    id: memSlider
                                    Layout.preferredWidth: 260
                                    from: 1024
                                    to: 16384
                                    stepSize: 128
                                    value: AppSettings.memoryMB
                                    onMoved: AppSettings.memoryMB = value




                                    background: Rectangle {
                                        x: memSlider.leftPadding
                                        y: memSlider.topPadding + memSlider.availableHeight / 2 - height / 2
                                        width: memSlider.availableWidth
                                        height: 4
                                        radius: 2
                                        color: "#1A2434"

                                        Rectangle {
                                            width: memSlider.visualPosition * parent.width
                                            height: parent.height
                                            radius: 2
                                            color: AppSettings.accentColor
                                        }
                                    }

                                    handle: Rectangle {
                                        x: memSlider.leftPadding + memSlider.visualPosition * (memSlider.availableWidth - width)
                                        y: memSlider.topPadding + memSlider.availableHeight / 2 - height / 2
                                        width: 18
                                        height: 18
                                        radius: 9
                                        color: memSlider.pressed
                                                 ? Qt.lighter(AppSettings.accentColor, 1.15)
                                                 : AppSettings.accentColor
                                        border.width: 2
                                        border.color: "#0B1220"
                                        Behavior on color { ColorAnimation { duration: 120 } }
                                    }
                                }
                                Rectangle {
                                    width: 96; height: 32; radius: 8
                                    color: "#0B1220"
                                    border.width: 1
                                    border.color: "#26364A"
                                    Text {
                                        anchors.centerIn: parent
                                        text: AppSettings.memoryMB + " MB"
                                        color: "#EAEFF7"
                                        font.pixelSize: 11
                                        font.bold: true
                                    }
                                }
                            }
                        }



                        SettingRow {
                            title: root.tr("settings.integrity")
                            description: IntegrityChecker.busy || IntegrityChecker.hasResult
                                            ? IntegrityChecker.statusText
                                            : root.tr("settings.integrityDesc")


                            Rectangle {
                                width: 120; height: 32; radius: 8
                                visible: !IntegrityChecker.busy
                                color: integrityMouse.containsMouse ? "#1B2434" : "#131B27"
                                border.width: 1
                                border.color: "#26364A"
                                Text {
                                    anchors.centerIn: parent
                                    text: root.tr("settings.integrityRun")
                                    color: "#EAEFF7"
                                    font.pixelSize: 11
                                    font.bold: true
                                }
                                MouseArea {
                                    id: integrityMouse
                                    anchors.fill: parent
                                    hoverEnabled: true
                                    cursorShape: Qt.PointingHandCursor
                                    onClicked: IntegrityChecker.start()
                                }
                            }


                            Row {
                                spacing: 10
                                visible: IntegrityChecker.busy

                                Rectangle {
                                    width: 180; height: 8; radius: 4
                                    anchors.verticalCenter: parent.verticalCenter
                                    color: "#1A2434"
                                    Rectangle {
                                        anchors.left: parent.left
                                        anchors.top: parent.top
                                        anchors.bottom: parent.bottom
                                        width: parent.width * Math.max(0, Math.min(1, IntegrityChecker.progress))
                                        radius: 4
                                        color: AppSettings.accentColor
                                        Behavior on width { NumberAnimation { duration: 120 } }
                                    }
                                }
                                Text {
                                    anchors.verticalCenter: parent.verticalCenter
                                    text: Math.round(IntegrityChecker.progress * 100) + "%"
                                    color: "#EAEFF7"
                                    font.pixelSize: 11
                                    font.bold: true
                                }
                                Rectangle {
                                    width: 84; height: 32; radius: 8
                                    anchors.verticalCenter: parent.verticalCenter
                                    color: cancelMouse.containsMouse ? "#7E2630" : "#131B27"
                                    border.width: 1
                                    border.color: cancelMouse.containsMouse ? "#7E2630" : "#26364A"
                                    Text {
                                        anchors.centerIn: parent
                                        text: root.tr("settings.integrityCancel")
                                        color: cancelMouse.containsMouse ? "#FFE5E9" : "#B9C1CE"
                                        font.pixelSize: 11
                                    }
                                    MouseArea {
                                        id: cancelMouse
                                        anchors.fill: parent
                                        hoverEnabled: true
                                        cursorShape: Qt.PointingHandCursor
                                        onClicked: IntegrityChecker.cancel()
                                    }
                                }
                            }
                        }





                        Text {
                            text: root.tr("settings.java")
                            color: "#F1F4FA"
                            font.pixelSize: 15
                            font.bold: true
                            Layout.topMargin: 14
                        }
                        Text {
                            Layout.fillWidth: true
                            text: root.tr("settings.javaDesc")
                            color: "#7C8899"
                            font.pixelSize: 11
                            wrapMode: Text.WordWrap
                        }

                        Text {
                            Layout.fillWidth: true
                            Layout.topMargin: 10
                            text: root.tr("settings.javaEmpty")
                            color: "#556275"
                            font.pixelSize: 11
                            visible: RuntimeManager.javaRuntimes.length === 0
                        }

                        Repeater {
                            model: RuntimeManager.javaRuntimes

                            delegate: RuntimeRow {
                                required property var modelData
                                info: modelData
                                titlePrefix: "Java"
                                textInstalled: root.tr("settings.javaInstalled")
                                textMissing: root.tr("settings.javaMissing")
                                textGet: root.tr("settings.javaGet")
                                textDelete: root.tr("settings.javaDelete")
                            }
                        }






                        Text {
                            text: root.tr("settings.game")
                            color: "#F1F4FA"
                            font.pixelSize: 15
                            font.bold: true
                            Layout.topMargin: 18
                        }
                        Text {
                            Layout.fillWidth: true
                            text: root.tr("settings.gameDesc")
                            color: "#7C8899"
                            font.pixelSize: 11
                            wrapMode: Text.WordWrap
                        }

                        Text {
                            Layout.fillWidth: true
                            Layout.topMargin: 10
                            text: root.tr("settings.javaEmpty")
                            color: "#556275"
                            font.pixelSize: 11
                            visible: RuntimeManager.gameRuntimes.length === 0
                        }

                        Repeater {
                            model: RuntimeManager.gameRuntimes

                            delegate: RuntimeRow {
                                required property var modelData
                                info: modelData
                                titlePrefix: "Minecraft"
                                textInstalled: root.tr("settings.javaInstalled")
                                textMissing: root.tr("settings.javaMissing")
                                textGet: root.tr("settings.javaGet")
                                textDelete: root.tr("settings.javaDelete")
                            }
                        }
                    }
                }


                ScrollView {
                    id: svCommon
                    clip: true
                    ScrollBar.horizontal.policy: ScrollBar.AlwaysOff
                    contentWidth: availableWidth

                    ColumnLayout {
                        width: svCommon.availableWidth
                        spacing: 10

                        Text {
                            text: root.tr("settings.commonTitle")
                            color: "#F1F4FA"
                            font.pixelSize: 18
                            font.bold: true
                            Layout.bottomMargin: 8
                        }

                        SettingRow {
                            title: root.tr("settings.lang")
                            description: root.tr("settings.langDesc")

                            Row {
                                spacing: 10
                                Repeater {
                                    model: [
                                        { code: "English",   flag: "us.png" },
                                        { code: "Русский",   flag: "ru.png" },
                                        { code: "Українська", flag: "ua.png" },
                                        { code: "Қазақша",   flag: "kz.png" },
                                        { code: "Беларуская", flag: "by.png" }
                                    ]
                                    delegate: Rectangle {
                                        required property int index
                                        required property var modelData
                                        property bool active: AppSettings.language === modelData.code
                                        width: 44; height: 44; radius: 22
                                        color: "transparent"
                                        border.width: active ? 3 : (langMouse.containsMouse ? 2 : 1)


                                        border.color: active ? AppSettings.accentColor : "#26364A"
                                        Behavior on border.color { ColorAnimation { duration: 140 } }
                                        Behavior on border.width { NumberAnimation { duration: 120 } }
                                        scale: active ? 1.08 : 1.0
                                        Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutBack } }

                                        Image {
                                            anchors.centerIn: parent
                                            width: 38; height: 38
                                            source: "qrc:/icons/data/flags/" + modelData.flag
                                            sourceSize.width: 128
                                            sourceSize.height: 128
                                            fillMode: Image.PreserveAspectFit
                                            smooth: true
                                            mipmap: true
                                        }

                                        MouseArea {
                                            id: langMouse
                                            anchors.fill: parent
                                            hoverEnabled: true
                                            cursorShape: Qt.PointingHandCursor
                                            onClicked: AppSettings.language = modelData.code
                                        }
                                    }
                                }
                            }
                        }

                        SettingRow {
                            title: root.tr("settings.discord")
                            description: root.tr("settings.discordDesc")
                            ExclusionToggle {
                                value: AppSettings.discordRichPresence
                                onChanged: function(newValue) { AppSettings.discordRichPresence = newValue }
                            }
                        }

                        SettingRow {
                            title: root.tr("settings.folder")
                            description: AppSettings.installDir




                            Rectangle {
                                width: 100; height: 32; radius: 8
                                color: openMouse.containsMouse
                                         ? Qt.lighter(AppSettings.accentColor, 1.12)
                                         : AppSettings.accentColor
                                Behavior on color { ColorAnimation { duration: 120 } }
                                Text {
                                    anchors.centerIn: parent
                                    text: root.tr("settings.folderOpen")
                                    color: "#08131F"
                                    font.pixelSize: 11
                                    font.bold: true
                                }
                                MouseArea {
                                    id: openMouse
                                    anchors.fill: parent
                                    hoverEnabled: true
                                    cursorShape: Qt.PointingHandCursor
                                    onClicked: AppSettings.openInstallFolder()
                                }
                            }
                        }

                    }
                }
            }
        }
    }

    FileDialog {
        id: bgDialog
        title: root.tr("settings.bgPick")
        nameFilters: ["Images (*.png *.jpg *.jpeg *.bmp *.webp)"]
        onAccepted: AppSettings.backgroundFile = selectedFile.toString().replace(/^file:\/\//, "")
    }
}


