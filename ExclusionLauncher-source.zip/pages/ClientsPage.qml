import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../components"

Item {
    id: root



    signal viewImages(var urls, int startIndex)



    signal requestPlay(string id)


    property var pendingDelete: null
    function confirmDelete(client) { root.pendingDelete = client }

    property string ratingLockedId: ""
    Timer { id: ratingLockTimer; interval: 5000; onTriggered: root.ratingLockedId = "" }



    function tr(key) { return (AppI18n.language, AppI18n.t(key)) }

    function tagName(tag) {
        if (tag === "official") return root.tr("tag.official")
        if (tag === "paste") return root.tr("tag.paste")
        if (tag === "awful") return root.tr("tag.awful")
        return tag
    }


    function _findById(id) {
        var list = ManifestManager.clients
        for (var i = 0; i < list.length; ++i)
            if (list[i].id === id) return list[i]
        return list.length > 0 ? list[0] : ({})
    }





    property string viewedId: ""

    function _firstInstalledId() {
        var list = ManifestManager.clients
        for (var i = 0; i < list.length; ++i)
            if ((InstalledStore.revision, InstalledStore.isInstalled)(list[i].id))
                return list[i].id
        return ""
    }
    function _defaultViewId() {
        if (AppSettings.selectedClientId.length > 0) return AppSettings.selectedClientId
        return ManifestManager.clients.length > 0 ? ManifestManager.clients[0].id : ""
    }


    Component.onCompleted: {
        if (AppSettings.selectedClientId.length === 0)
            AppSettings.selectedClientId = _firstInstalledId()
        if (root.viewedId.length === 0)
            root.viewedId = _defaultViewId()
        _syncClients()
    }
    Connections {
        target: ManifestManager
        function onClientsChanged() {
            if (AppSettings.selectedClientId.length === 0)
                AppSettings.selectedClientId = root._firstInstalledId()
            if (root.viewedId.length === 0)
                root.viewedId = root._defaultViewId()
            root._syncClients()
        }
    }


    Connections {
        target: InstalledStore
        function onRevisionChanged() {
            // Раньше тут сбрасывали выбор на первый установленный, если выбранный
            // не установлен. Больше не делаем: не скачанный клиент можно держать
            // выбранным — на главной для него показывается кнопка «Скачать».
            // Сбрасываем только если клиента вообще нет в каталоге.
            if (AppSettings.selectedClientId.length > 0
                    && !root._findById(AppSettings.selectedClientId))
                AppSettings.selectedClientId = root._firstInstalledId()
        }
    }

    property var selected: _findById(root.viewedId)








    ListModel { id: clientsModel; dynamicRoles: true }


    property string filter: ""


    property string versionFilter: ""
    property string tagFilter: ""
    onVersionFilterChanged: root._syncClients()
    onTagFilterChanged: root._syncClients()
    property bool searchActive: filter.length > 0 || versionFilter.length > 0 || tagFilter.length > 0
    property var nameCounts: ({})



    function _cmpVerDesc(a, b) {
        var pa = String(a).split('.'), pb = String(b).split('.')
        var n = Math.max(pa.length, pb.length)
        for (var i = 0; i < n; ++i) {
            var na = parseInt(pa[i] || '0', 10), nb = parseInt(pb[i] || '0', 10)
            if (na !== nb) return nb - na
        }
        return 0
    }
    property var versionList: {
        var list = ManifestManager.clients, seen = {}, out = []
        for (var i = 0; i < list.length; ++i) {
            var v = list[i].minecraft
            if (v && !seen[v]) { seen[v] = true; out.push(v) }
        }
        out.sort(root._cmpVerDesc)
        return out
    }
    property var tagList: {
        var list = ManifestManager.clients, seen = {}, out = []
        for (var i = 0; i < list.length; ++i) {
            var t = list[i].tags
            if (!t) continue
            for (var j = 0; j < t.length; ++j)
                if (t[j] && !seen[t[j]]) { seen[t[j]] = true; out.push(t[j]) }
        }
        return out
    }






    function _targetOrder() {
        var list = ManifestManager.clients
        var favs = AppSettings.favouriteClientIds
        var needle = root.filter.toLowerCase()
        var uniq = []
        for (var i = 0; i < list.length; ++i) {
            var c = list[i]
            if (root.versionFilter.length > 0 && String(c.minecraft || "") !== root.versionFilter) continue

            if (root.tagFilter.length > 0 && (c.tags || []).indexOf(root.tagFilter) < 0) continue


            if (needle.length > 0
                && String(c.name || "").toLowerCase().indexOf(needle) < 0
                && String(c.id || "").toLowerCase().indexOf(needle) < 0) continue
            uniq.push(c)
        }



        uniq.sort(function(a, b) {
            var ra = root._tagRank(a), rb = root._tagRank(b)
            if (ra !== rb) return ra - rb
            var fa = favs.indexOf(a.id) >= 0 ? 0 : 1
            var fb = favs.indexOf(b.id) >= 0 ? 0 : 1
            return fa - fb
        })
        return uniq
    }



    function _rebuildNameCounts() {
        var list = ManifestManager.clients
        var counts = {}
        for (var i = 0; i < list.length; ++i) {
            var name = list[i].name || list[i].id
            counts[name] = (counts[name] || 0) + 1
        }
        root.nameCounts = counts
    }

    function _sameNameCount(name) {
        return root.nameCounts[name] || 0
    }


    function _tagRank(c) {
        var t = c.tags || []
        if (t.indexOf("official") >= 0) return 0
        if (t.indexOf("paste") >= 0) return 1
        if (t.indexOf("awful") >= 0) return 2
        return 3
    }


    function _siblingVersions() {
        if (!root.selected) return []
        var target = root.selected.name || root.selected.id
        var out = []
        var list = ManifestManager.clients
        for (var i = 0; i < list.length; ++i)
            if ((list[i].name || list[i].id) === target) out.push(list[i])

        out.sort(function(a, b) {
            return root._cmpVerDesc(a.minecraft || "", b.minecraft || "")
        })
        return out
    }

    function _indexOfId(id, from) {
        for (var i = from; i < clientsModel.count; ++i)
            if (clientsModel.get(i).client.id === id) return i
        return -1
    }

    function _syncClients() {
        root._rebuildNameCounts()
        var target = _targetOrder()



        var sameSet = target.length === clientsModel.count
        for (var i = 0; sameSet && i < target.length; ++i)
            if (_indexOfId(target[i].id, 0) < 0) sameSet = false

        if (!sameSet) {
            clientsModel.clear()
            for (var k = 0; k < target.length; ++k)
                clientsModel.append({ client: target[k] })
            return
        }


        for (var pos = 0; pos < target.length; ++pos) {
            if (clientsModel.get(pos).client.id === target[pos].id) continue
            var from = _indexOfId(target[pos].id, pos + 1)
            if (from > pos) clientsModel.move(from, pos, 1)
        }
    }

    Connections {
        target: AppSettings
        function onFavouriteClientIdsChanged() { root._syncClients() }
    }

    RowLayout {
        anchors.fill: parent
        spacing: 18


        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 12



            RowLayout {
                Layout.fillWidth: true
                spacing: 12

                Text {
                    id: clientsTitle
                    Layout.alignment: Qt.AlignVCenter
                    text: root.tr("clients.title")
                    color: "#F1F4FA"
                    font.pixelSize: 18
                    font.bold: true
                }

                Rectangle {


                    Layout.alignment: Qt.AlignVCenter
                    Layout.preferredWidth: 240
                    Layout.preferredHeight: 30
                    radius: 8
                    color: searchField.activeFocus ? "#141E2C" : "#0E1725"
                    Behavior on color { ColorAnimation { duration: 140 } }



                    Canvas {
                        id: searchIcon
                        anchors.left: parent.left
                        anchors.leftMargin: 10
                        anchors.verticalCenter: parent.verticalCenter
                        width: 14
                        height: 14
                        onPaint: {
                            var ctx = getContext("2d")
                            ctx.reset()
                            ctx.strokeStyle = "#FFFFFF"
                            ctx.lineWidth = 1.5
                            ctx.lineCap = "round"
                            ctx.beginPath()
                            ctx.arc(6, 6, 4.2, 0, Math.PI * 2)
                            ctx.stroke()
                            ctx.beginPath()
                            ctx.moveTo(9.3, 9.3)
                            ctx.lineTo(13, 13)
                            ctx.stroke()
                        }
                    }

                    TextField {
                        id: searchField
                        anchors.left: searchIcon.right
                        anchors.right: clearSearch.left
                        anchors.verticalCenter: parent.verticalCenter
                        anchors.leftMargin: 8
                        anchors.rightMargin: 4
                        height: parent.height
                        padding: 0
                        color: "#F1F4FA"
                        font.pixelSize: 12
                        verticalAlignment: TextInput.AlignVCenter
                        selectByMouse: true
                        background: null
                        placeholderText: root.tr("clients.search")
                        placeholderTextColor: "#556275"
                        // Debounce: не пересобираем модель на КАЖДУЮ букву (при
                        // 64 клиентах clear()+rebuild с обложками лагает), а
                        // через короткую паузу после последнего ввода.
                        onTextChanged: {
                            searchDebounce.restart()
                        }
                        Timer {
                            id: searchDebounce
                            interval: 260
                            onTriggered: {
                                root.filter = searchField.text.trim()
                                root._syncClients()
                            }
                        }
                    }

                    Text {
                        id: clearSearch
                        anchors.right: parent.right
                        anchors.rightMargin: 10
                        anchors.verticalCenter: parent.verticalCenter
                        text: "×"
                        font.pixelSize: 16
                        color: clearMouse.containsMouse ? "#EAEFF7" : "#7C8899"
                        visible: searchField.text.length > 0
                        MouseArea {
                            id: clearMouse
                            anchors.fill: parent
                            anchors.margins: -6
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: searchField.text = ""
                        }
                    }
                }


                FilterDropdown {
                    Layout.alignment: Qt.AlignVCenter
                    Layout.preferredWidth: 140
                    visible: root.versionList.length > 1
                    model: [root.tr("clients.allVersions")].concat(root.versionList)
                    currentIndex: root.versionFilter.length === 0
                                  ? 0 : (root.versionList.indexOf(root.versionFilter) + 1)
                    onActivated: function(index) {
                        root.versionFilter = (index <= 0 ? "" : root.versionList[index - 1])
                    }
                }



                FilterDropdown {
                    Layout.alignment: Qt.AlignVCenter
                    Layout.preferredWidth: 140
                    visible: root.tagList.length > 0
                    model: [root.tr("clients.allTags")].concat(
                               root.tagList.map(function(t) { return root.tagName(t) }))
                    currentIndex: root.tagFilter.length === 0
                                  ? 0 : (root.tagList.indexOf(root.tagFilter) + 1)
                    onActivated: function(index) {
                        root.tagFilter = (index <= 0 ? "" : root.tagList[index - 1])
                    }
                }

                Item { Layout.fillWidth: true }
            }





            GridView {
                id: grid
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true

                property int spacingPx: 14
                property int cols: 3
                property int availableWidth: Math.max(300, width - 16)
                property int tileW: (availableWidth - (cols - 1) * spacingPx) / cols
                property int tileH: tileW
                cellWidth: tileW + spacingPx
                cellHeight: tileH + spacingPx











                cacheBuffer: root.searchActive ? cellHeight : cellHeight * 8
                boundsBehavior: Flickable.StopAtBounds
                model: clientsModel
                reuseItems: true
                flickDeceleration: 2500
                maximumFlickVelocity: 2200


                ScrollBar.vertical: ScrollBar { policy: ScrollBar.AlwaysOff }






                NumberAnimation {
                    id: wheelScroll
                    target: grid
                    property: "contentY"
                    duration: 260
                    easing.type: Easing.OutCubic
                }

                WheelHandler {
                    acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchPad
                    onWheel: function(event) {
                        const maxY = Math.max(0, grid.contentHeight - grid.height)


                        const from = wheelScroll.running ? wheelScroll.to : grid.contentY
                        const step = grid.cellHeight * 0.9
                        const delta = (event.angleDelta.y / 120) * step
                        const target = Math.max(0, Math.min(maxY, from - delta))
                        if (Math.abs(target - grid.contentY) < 0.5) return
                        wheelScroll.stop()
                        wheelScroll.from = grid.contentY
                        wheelScroll.to = target
                        wheelScroll.start()
                    }
                }

                Text {
                    anchors.centerIn: parent
                    text: {


                        if (root.filter.length > 0 || root.versionFilter.length > 0 || root.tagFilter.length > 0)
                            return root.tr("clients.notfound")
                        return ManifestManager.usingFallback ? root.tr("clients.offline")
                                                             : root.tr("clients.none")
                    }
                    color: "#556275"
                    font.pixelSize: 14
                    visible: clientsModel.count === 0
                }



                    moveDisplaced: Transition {
                        NumberAnimation { properties: "x,y"; duration: 260; easing.type: Easing.OutCubic }
                    }
                    move: Transition {
                        NumberAnimation { properties: "x,y"; duration: 260; easing.type: Easing.OutCubic }
                    }

                    delegate: Item {
                        id: tile
                        required property int index
                        required property var client
                        readonly property var modelData: client
                        width: grid.tileW
                        height: grid.tileH


                            RoundedImage {
                                anchors.fill: parent
                                radius: 18






                                source: {
                                    var u = modelData.coverUrl || ""
                                    var local = (PhotoStore.rev, PhotoStore.fileFor(u))
                                    return local !== "" ? local : u
                                }
                                fadeMs: 0
                                asyncLoad: true

                                Rectangle {
                                    anchors.fill: parent



                                    color: "#16202E"
                                }
                            }




                            Rectangle {
                                anchors.fill: parent
                                radius: 18
                                gradient: Gradient {
                                    GradientStop { position: 0.0; color: "#9E000000" }
                                    GradientStop { position: 0.5; color: "#82000000" }
                                    GradientStop { position: 1.0; color: "#AA000000" }
                                }
                            }




                            Column {
                                anchors.top: parent.top
                                anchors.left: parent.left
                                anchors.margins: 8
                                spacing: 4
                                z: 4

                                Repeater {
                                    model: modelData.tags || []
                                    delegate: Rectangle {
                                        required property string modelData
                                        height: 20
                                        width: tagLabel.implicitWidth + 14
                                        radius: 6
                                        color: modelData === "official" ? "#D01D7A4A"
                                               : (modelData === "awful" ? "#D0B03A46"
                                                                        : "#D06E4BC0")
                                        Text {
                                            id: tagLabel
                                            anchors.centerIn: parent
                                            text: root.tagName(modelData)
                                            color: "#FFFFFF"
                                            font.pixelSize: 9
                                            font.bold: true
                                            font.letterSpacing: 0.5
                                        }
                                    }
                                }
                            }



                            Text {
                                anchors.left: parent.left
                                anchors.right: parent.right
                                anchors.verticalCenter: parent.verticalCenter
                                anchors.leftMargin: 12
                                anchors.rightMargin: 12
                                horizontalAlignment: Text.AlignHCenter
                                text: {
                                    var nm = modelData.name || modelData.id

                                    return root._sameNameCount(nm) > 1
                                           ? nm + " " + (modelData.minecraft || "")
                                           : nm
                                }
                                color: "#FFFFFF"
                                font.pixelSize: 22
                                font.bold: true
                                elide: Text.ElideRight
                                style: Text.Outline
                                styleColor: "#B0060B12"
                            }


                            Rectangle {
                                anchors.fill: parent
                                color: "transparent"
                                radius: 18
                                border.width: root.viewedId === modelData.id ? 3 : 1


                                border.color: root.viewedId === modelData.id
                                                ? "#8A6E7A8E" : "#1B2635"
                                Behavior on border.color { ColorAnimation { duration: 140 } }
                            }



                            Row {
                                anchors.top: parent.top
                                anchors.right: parent.right
                                anchors.margins: 8
                                spacing: 6
                                z: 5

                                Rectangle {
                                    width: 28; height: 28; radius: 14
                                    color: trashMouse.containsMouse ? "#C07E2630" : "#70000000"
                                    visible: (InstalledStore.revision, InstalledStore.isInstalled)(modelData.id)
                                    Text {
                                        anchors.centerIn: parent
                                        text: "🗑"
                                        color: trashMouse.containsMouse ? "#FFD7DD" : "#EAEFF7"
                                        font.pixelSize: 13
                                    }
                                    MouseArea {
                                        id: trashMouse
                                        anchors.fill: parent
                                        hoverEnabled: true
                                        cursorShape: Qt.PointingHandCursor
                                        onClicked: root.confirmDelete(modelData)
                                    }
                                }

                                Rectangle {
                                    width: 28; height: 28; radius: 14
                                    color: favMouse.containsMouse ? "#B0000000" : "#70000000"
                                    Text {
                                        anchors.centerIn: parent
                                        text: (AppSettings.favouriteClientIds.indexOf(modelData.id) >= 0) ? "★" : "☆"
                                        color: (AppSettings.favouriteClientIds.indexOf(modelData.id) >= 0) ? "#F5C542" : "#EAEFF7"
                                        font.pixelSize: 16
                                        font.bold: true
                                    }
                                    MouseArea {
                                        id: favMouse
                                        anchors.fill: parent
                                        hoverEnabled: true
                                        cursorShape: Qt.PointingHandCursor
                                        onClicked: AppSettings.toggleFavourite(modelData.id)
                                    }
                                }
                            }

                            MouseArea {
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onClicked: {
                                    shineAnim.restart()


                                    root.viewedId = modelData.id
                                    // Выбрать можно ЛЮБОЙ клиент, в т.ч. не
                                    // скачанный — на главной будет кнопка «Скачать».
                                    AppSettings.selectedClientId = modelData.id
                                }
                                z: 1
                            }


                            Item {
                                id: shineClip
                                anchors.fill: parent
                                clip: true
                                z: 7
                                Rectangle {
                                    id: shine
                                    width: 46
                                    height: shineClip.height * 1.8
                                    y: -shineClip.height * 0.4
                                    x: -width - 40
                                    rotation: 18
                                    opacity: 0
                                    gradient: Gradient {
                                        orientation: Gradient.Horizontal
                                        GradientStop { position: 0.0; color: "#00FFFFFF" }
                                        GradientStop { position: 0.5; color: "#59FFFFFF" }
                                        GradientStop { position: 1.0; color: "#00FFFFFF" }
                                    }
                                }
                                SequentialAnimation {
                                    id: shineAnim
                                    PropertyAction { target: shine; property: "opacity"; value: 1 }
                                    NumberAnimation {
                                        target: shine; property: "x"
                                        from: -shine.width - 40; to: shineClip.width + 40
                                        duration: 520; easing.type: Easing.OutCubic
                                    }
                                    PropertyAction { target: shine; property: "opacity"; value: 0 }
                                }
                            }


                            Rectangle {
                                visible: AppSettings.selectedClientId === modelData.id
                                anchors.left: parent.left
                                anchors.bottom: parent.bottom
                                anchors.margins: 8
                                z: 6
                                height: 20
                                width: activeLbl.implicitWidth + 16
                                radius: 6
                                color: "#D01D7A4A"
                                Text {
                                    id: activeLbl
                                    anchors.centerIn: parent
                                    text: "● активный"
                                    color: "#FFFFFF"
                                    font.pixelSize: 9
                                    font.bold: true
                                }
                            }
                    }
            }
        }


        Rectangle {
            Layout.preferredWidth: 440
            Layout.fillHeight: true
            radius: 14
            color: "#B80F1622"
            border.width: 1
            border.color: "#1B2635"
            visible: ManifestManager.clients.length > 0

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 16
                spacing: 12


                Item {
                    id: galleryHost
                    Layout.fillWidth: true
                    Layout.preferredHeight: (parent.width - 32) / 1.65




                    property var picks: {
                        var arr = []
                        if (root.selected) {
                            if (root.selected.screenshots) {
                                for (var i = 0; i < root.selected.screenshots.length; ++i) {
                                    var s = root.selected.screenshots[i]
                                    if (s && s.length > 0) arr.push(s)
                                }
                            }
                        }
                        if (arr.length === 0) arr.push("")
                        return arr
                    }

                    readonly property var realPicks: picks.filter(function(u) { return u && u.length > 0 })


                    onPicksChanged: swipe.currentIndex = 0

                    SwipeView {
                        id: swipe
                        anchors.fill: parent
                        clip: true
                        interactive: galleryHost.picks.length > 1

                        Repeater {
                            model: galleryHost.picks
                            delegate: Item {
                                id: slide
                                required property int index
                                required property string modelData




                                MouseArea {
                                    anchors.fill: parent
                                    z: 3
                                    enabled: slide.modelData.length > 0
                                    hoverEnabled: true
                                    cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                                    onClicked: {
                                        var real = galleryHost.realPicks
                                        var at = real.indexOf(slide.modelData)
                                        root.viewImages(real, at < 0 ? 0 : at)
                                    }
                                }

                                RoundedImage {
                                    anchors.fill: parent
                                    radius: 14


                                    source: {
                                        var local = (PhotoStore.rev, PhotoStore.fileFor(modelData))
                                        return local !== "" ? local : modelData
                                    }

                                    Rectangle {
                                        anchors.fill: parent
                                        color: "#16202E"
                                    }
                                }
                            }
                        }
                    }


                    Rectangle {
                        anchors.left: parent.left
                        anchors.verticalCenter: parent.verticalCenter
                        anchors.leftMargin: 8
                        width: 32; height: 44
                        radius: 8
                        color: prevMouse.containsMouse ? "#B0000000" : "#70000000"
                        visible: galleryHost.picks.length > 1
                        Text { anchors.centerIn: parent; text: "‹"; color: "#F4F6FA"; font.pixelSize: 22; font.bold: true }
                        MouseArea {
                            id: prevMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: swipe.currentIndex = (swipe.currentIndex - 1 + galleryHost.picks.length) % galleryHost.picks.length
                        }
                    }

                    Rectangle {
                        anchors.right: parent.right
                        anchors.verticalCenter: parent.verticalCenter
                        anchors.rightMargin: 8
                        width: 32; height: 44
                        radius: 8
                        color: nextMouse.containsMouse ? "#B0000000" : "#70000000"
                        visible: galleryHost.picks.length > 1
                        Text { anchors.centerIn: parent; text: "›"; color: "#F4F6FA"; font.pixelSize: 22; font.bold: true }
                        MouseArea {
                            id: nextMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: swipe.currentIndex = (swipe.currentIndex + 1) % galleryHost.picks.length
                        }
                    }

                    Row {
                        anchors.horizontalCenter: parent.horizontalCenter
                        anchors.bottom: parent.bottom
                        anchors.bottomMargin: 8
                        spacing: 6
                        visible: galleryHost.picks.length > 1
                        Repeater {
                            model: galleryHost.picks.length
                            delegate: Rectangle {
                                required property int index
                                width: 8; height: 8; radius: 4
                                color: swipe.currentIndex === index ? AppSettings.accentColor : "#5A6474"
                                Behavior on color { ColorAnimation { duration: 120 } }
                            }
                        }
                    }
                }


                RowLayout {
                    Layout.fillWidth: true
                    spacing: 8
                    Text {
                        Layout.fillWidth: true
                        text: root.selected && root.selected.name ? root.selected.name : ""
                        color: "#F1F4FA"
                        font.pixelSize: 18
                        font.bold: true
                        elide: Text.ElideRight
                    }
                    Rectangle {
                        Layout.preferredWidth: 32
                        Layout.preferredHeight: 32
                        radius: 16
                        color: favDetailMouse.containsMouse ? "#1F2C40" : "transparent"
                        visible: !!root.selected
                        Text {
                            anchors.centerIn: parent
                            text: root.selected && (AppSettings.favouriteClientIds.indexOf(root.selected.id) >= 0) ? "★" : "☆"
                            color: root.selected && (AppSettings.favouriteClientIds.indexOf(root.selected.id) >= 0) ? "#F5C542" : "#B9C1CE"
                            font.pixelSize: 20
                            font.bold: true
                        }
                        MouseArea {
                            id: favDetailMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: if (root.selected) AppSettings.toggleFavourite(root.selected.id)
                        }
                    }
                }


                Text {
                    text: root.selected ? ("Minecraft " + (root.selected.minecraft || "?") + "  •  " + (root.selected.sizeText || "")) : ""
                    color: "#7C8899"
                    font.pixelSize: 11
                }


                Text {
                    Layout.fillWidth: true
                    text: root.selected && root.selected.description ? root.selected.description : ""
                    color: "#B9C1CE"
                    font.pixelSize: 12
                    wrapMode: Text.WordWrap
                }


                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 6
                    visible: DownloadManager.busy && root.selected && DownloadManager.currentClientId === root.selected.id

                    RowLayout {
                        Layout.fillWidth: true
                        Text {
                            Layout.fillWidth: true
                            text: DownloadManager.statusText
                            color: "#B9C1CE"
                            font.pixelSize: 11
                            elide: Text.ElideRight
                        }
                        Text {
                            text: Math.round(DownloadManager.progress * 100) + "%"
                            color: "#B9C1CE"
                            font.pixelSize: 11
                            font.bold: true
                        }
                    }
                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 6
                        radius: 3
                        color: "#1A2434"
                        Rectangle {
                            anchors.left: parent.left
                            anchors.top: parent.top
                            anchors.bottom: parent.bottom
                            width: parent.width * Math.max(0, Math.min(1, DownloadManager.progress))
                            radius: 3
                            color: AppSettings.accentColor
                            Behavior on width { NumberAnimation { duration: 180 } }
                        }
                    }
                    Text {
                        text: DownloadManager.speedText
                        color: "#7C8899"
                        font.pixelSize: 10
                    }
                }

                Item { Layout.fillHeight: true }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 12
                    visible: !!root.selected

                    Text {
                        text: "★ " + Number(root.selected ? (root.selected.rating || 0) : 0).toFixed(1)
                              + "  ·  " + Number(root.selected ? (root.selected.votes || 0) : 0) + " голос."
                        color: "#C7D0DE"
                        font.pixelSize: 12
                    }

                    Row {
                        id: clientRateRow
                        spacing: 2
                        visible: root.selected && (InstalledStore.revision, InstalledStore.isInstalled)(root.selected.id)
                        property bool locked: root.selected && root.ratingLockedId === root.selected.id
                        Repeater {
                            model: 5
                            delegate: Text {
                                required property int index
                                text: "★"
                                color: index < Number(root.selected ? (root.selected.userRating || 0) : 0) ? "#FFCC42" : "#57657D"
                                opacity: clientRateRow.locked ? 0.5 : 1.0
                                font.pixelSize: 19
                                MouseArea {
                                    anchors.fill: parent
                                    enabled: !clientRateRow.locked
                                    cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                                    onClicked: {
                                        if (!root.selected) return
                                        root.ratingLockedId = root.selected.id
                                        ratingLockTimer.restart()
                                        ManifestManager.rateClient(root.selected.id, index + 1)
                                    }
                                }
                            }
                        }
                    }

                    Text {
                        visible: root.selected && !(InstalledStore.revision, InstalledStore.isInstalled)(root.selected.id)
                        text: "оцените после скачивания"
                        color: "#6E7B90"
                        font.pixelSize: 11
                    }

                    Item { Layout.fillWidth: true }
                }


                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 48
                    radius: 10

                    property bool sel: !!root.selected
                    property bool inst: sel && (InstalledStore.revision, InstalledStore.isInstalled)(root.selected.id)
                    property bool needsUpdate: inst
                                               && ((InstalledStore.revision, InstalledStore.installedVersion)(root.selected.id) !== String(root.selected.version || "")
                                                   || (InstalledStore.revision, InstalledStore.needsUpdate)(root.selected.id, String(root.selected.sha256 || ""), String(root.selected.packageUrl || "")))
                    property bool isBusyMe: sel && DownloadManager.busy && DownloadManager.currentClientId === root.selected.id


                    property bool launching: GameLauncher.preparing

                    color: {
                        if (isBusyMe) return actMouse.containsMouse ? "#7E2630" : "#26141A"
                        if (DownloadManager.busy) return "#151E2B"
                        if (!sel) return "#151E2B"
                        return actMouse.containsMouse ? Qt.lighter(AppSettings.accentColor, 1.08)
                                      : AppSettings.accentColor
                    }
                    Behavior on color { ColorAnimation { duration: 120 } }
                    border.width: isBusyMe ? 1 : 0
                    border.color: "#71303D"

                    Text {
                        anchors.centerIn: parent
                        text: {
                            if (!parent.sel) return root.tr("clients.noclient")
                            if (parent.isBusyMe) return root.tr("clients.cancelDl")
                            if (DownloadManager.busy) return root.tr("clients.busyOther")


                            if (parent.needsUpdate) return "Обновить"
                            if (parent.inst) return root.tr("clients.launch")
                            return root.tr("clients.download")
                        }
                        color: {
                            if (parent.isBusyMe) return "#FFE5E9"
                            if (DownloadManager.busy || !parent.sel) return "#6A7688"
                            return "#08131F"
                        }
                        font.pixelSize: 14
                        font.bold: true
                        font.letterSpacing: 1
                    }

                    MouseArea {
                        id: actMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: (!parent.sel || (DownloadManager.busy && !parent.isBusyMe)) ? Qt.ArrowCursor : Qt.PointingHandCursor
                        onClicked: {
                            if (!parent.sel) return
                            if (parent.isBusyMe) { DownloadManager.cancel(); return }
                            if (DownloadManager.busy) return
                            if (parent.needsUpdate) {
                                DownloadManager.installClient(root.selected)
                                return
                            }
                            if (parent.inst) {
                                if (parent.launching) return
                                root.requestPlay(root.selected.id)
                                return
                            }
                            DownloadManager.installClient(root.selected)
                        }
                    }
                }
            }
        }
    }




    Item {
        anchors.fill: parent
        visible: !!root.pendingDelete
        z: 50

        Rectangle {
            anchors.fill: parent
            color: "#C0060912"
            MouseArea {
                anchors.fill: parent
                onClicked: root.pendingDelete = null
            }
        }

        Rectangle {
            anchors.centerIn: parent
            width: 420
            height: 190
            radius: 14
            color: "#F00F1622"
            border.width: 1
            border.color: "#26364A"

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 20
                spacing: 10

                Text {
                    text: root.tr("clients.deleteTitle")
                    color: "#F1F4FA"
                    font.pixelSize: 16
                    font.bold: true
                }
                Text {
                    Layout.fillWidth: true
                    text: root.pendingDelete
                          ? root.tr("clients.deleteAsk").arg(root.pendingDelete.name || root.pendingDelete.id)
                          : ""
                    color: "#B9C1CE"
                    font.pixelSize: 12
                    wrapMode: Text.WordWrap
                }

                Item { Layout.fillHeight: true }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 10
                    Item { Layout.fillWidth: true }

                    Rectangle {
                        Layout.preferredWidth: 120
                        Layout.preferredHeight: 38
                        radius: 10
                        color: keepMouse.containsMouse ? "#1B2434" : "#131B27"
                        border.width: 1
                        border.color: "#26364A"
                        Text {
                            anchors.centerIn: parent
                            text: root.tr("clients.deleteNo")
                            color: "#EAEFF7"
                            font.pixelSize: 12
                        }
                        MouseArea {
                            id: keepMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: root.pendingDelete = null
                        }
                    }

                    Rectangle {
                        Layout.preferredWidth: 120
                        Layout.preferredHeight: 38
                        radius: 10
                        color: dropMouse.containsMouse ? "#8E2C38" : "#7E2630"
                        Text {
                            anchors.centerIn: parent
                            text: root.tr("clients.deleteYes")
                            color: "#FFE5E9"
                            font.pixelSize: 12
                            font.bold: true
                        }
                        MouseArea {
                            id: dropMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: {
                                if (root.pendingDelete)
                                    DownloadManager.removeClient(root.pendingDelete.id)
                                root.pendingDelete = null
                            }
                        }
                    }
                }
            }
        }
    }
}



