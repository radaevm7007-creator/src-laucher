import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
Item {
    id: root


    function tr(key) { return (AppI18n.language, AppI18n.t(key)) }

    ColumnLayout {
        anchors.fill: parent
        spacing: 14

        Text {
            Layout.fillWidth: true
            text: root.tr("news.header")
            color: "#F1F4FA"
            font.pixelSize: 22
            font.bold: true
        }

        ListView {
            id: list
            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            spacing: 12




            model: (NewsModel.items, NewsModel.topN(20))
            boundsBehavior: Flickable.StopAtBounds

            Text {
                anchors.centerIn: parent
                text: root.tr("news.none")
                color: "#556275"
                font.pixelSize: 14
                visible: list.count === 0
            }

            ScrollBar.vertical: ScrollBar {
                policy: list.contentHeight > list.height ? ScrollBar.AlwaysOn : ScrollBar.AsNeeded
            }

            delegate: Rectangle {
                required property var modelData
                width: list.width - 12
                height: contentCol.implicitHeight + 26
                color: cardMouse.containsMouse ? "#C0131C29" : "#B80F1622"
                radius: 12
                border.width: 1
                border.color: "#1B2635"
                Behavior on color { ColorAnimation { duration: 120 } }

                ColumnLayout {
                    id: contentCol
                    anchors.fill: parent
                    anchors.margins: 14
                    spacing: 8

                    RowLayout {
                        Layout.fillWidth: true
                        Rectangle {
                            radius: 4
                            Layout.preferredHeight: 20
                            Layout.preferredWidth: tagT.implicitWidth + 14
                            color: modelData.tagColor
                            Text {
                                id: tagT
                                anchors.centerIn: parent
                                text: modelData.tag
                                color: "#0B0E15"
                                font.pixelSize: 10
                                font.bold: true
                                font.letterSpacing: 0.8
                            }
                        }
                        Item { Layout.fillWidth: true }
                        Text {
                            text: modelData.date
                            color: "#6E7A8C"
                            font.pixelSize: 11
                        }
                    }
                    Text {
                        Layout.fillWidth: true
                        text: modelData.title
                        color: "#EAEFF7"
                        font.pixelSize: 15
                        font.bold: true
                    }
                    Text {
                        Layout.fillWidth: true
                        text: modelData.description
                        color: "#8592A5"
                        font.pixelSize: 12
                        wrapMode: Text.WordWrap
                    }
                }

                MouseArea {
                    id: cardMouse
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                }
            }
        }
    }
}



