import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Effects
import "../components"

Item {
    id: root

    property string clientFilter: ""
    property string configFilter: ""
    property string selectedClientId: ""
    property string sortMode: "popular"

    // Лок оценки на уровне страницы (а не делегата), иначе он терялся при
    // rebuild модели после rateConfig и юзер успевал сменить звёзды несколько раз.
    property string ratingLockedKey: ""
    Timer { id: ratingLockTimer; interval: 5000; onTriggered: root.ratingLockedKey = "" }

    function tr(key) { return (AppI18n.language, AppI18n.t(key)) }

    function filteredClients() {
        var list = ConfigManager.clients || []
        var out = []
        var needle = clientFilter.toLowerCase()
        for (var i = 0; i < list.length; ++i) {
            var client = list[i]
            if (needle.length > 0
                    && String(client.name || "").toLowerCase().indexOf(needle) < 0
                    && String(client.id || "").toLowerCase().indexOf(needle) < 0)
                continue
            out.push(client)
        }
        return out
    }

    function ensureSelection() {
        var list = filteredClients()
        if (list.length === 0) {
            selectedClientId = ""
            return
        }
        for (var i = 0; i < list.length; ++i)
            if (list[i].id === selectedClientId)
                return
        selectedClientId = list[0].id
    }

    function currentClient() {
        var list = filteredClients()
        for (var i = 0; i < list.length; ++i)
            if (list[i].id === selectedClientId)
                return list[i]
        return list.length > 0 ? list[0] : ({})
    }

    function clientVersionLabel(client) {
        var name = String(client.name || client.id || "Клиент")
        var mc = String(client.minecraft || "")
        return mc.length > 0 ? (name + " · " + mc) : name
    }

    function sortedConfigs() {
        var client = currentClient()
        var configs = (client.configs || []).slice(0)
        var needle = configFilter.toLowerCase()
        if (needle.length > 0) {
            configs = configs.filter(function(cfg) {
                return String(cfg.name || "").toLowerCase().indexOf(needle) >= 0
                        || String(cfg.description || "").toLowerCase().indexOf(needle) >= 0
                        || String(cfg.id || "").toLowerCase().indexOf(needle) >= 0
            })
        }
        configs.sort(function(a, b) {
            if (sortMode === "name")
                return String(a.name || "").localeCompare(String(b.name || ""))
            if (sortMode === "new")
                return String(b.updatedAt || "").localeCompare(String(a.updatedAt || ""))
            if (sortMode === "rating")
                return Number(b.rating || 0) - Number(a.rating || 0)
            return Number(b.votes || 0) - Number(a.votes || 0)
        })
        return configs
    }

    function starColor(index, filled) {
        if (filled) return "#FFCC42"
        return index === 0 ? "#576276" : "#4A556A"
    }

    Component.onCompleted: ensureSelection()

    Connections {
        target: ConfigManager
        function onClientsChanged() { root.ensureSelection() }
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 18
        spacing: 14

        Rectangle {
            Layout.fillWidth: true
            Layout.preferredHeight: 82
            radius: 18
            color: "#B80F1622"
            border.width: 1
            border.color: "#1B2635"

            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: 20
                anchors.rightMargin: 20
                spacing: 18

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 2
                    Text {
                        text: "Конфиги"
                        color: "#F1F4FA"
                        font.pixelSize: 26
                        font.bold: true
                    }
                }

                ColumnLayout {
                    spacing: 2
                    Text {
                        text: ConfigManager.statusText
                        visible: text.length > 0
                        color: "#C8D0DD"
                        font.pixelSize: 12
                        horizontalAlignment: Text.AlignRight
                    }
                }
            }
        }

        RowLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 14

            Rectangle {
                Layout.preferredWidth: 280
                Layout.fillHeight: true
                radius: 18
                color: "#B80F1622"
                border.width: 1
                border.color: "#1B2635"

                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 16
                    spacing: 12

                    Text {
                        text: "Клиенты"
                        color: "#F1F4FA"
                        font.pixelSize: 15
                        font.bold: true
                    }

                    SearchBox {
                        Layout.fillWidth: true
                        placeholder: "Поиск клиента"
                        text: root.clientFilter
                        onEdited: function(value) {
                            root.clientFilter = value
                            root.ensureSelection()
                        }
                    }

                    ScrollView {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        clip: true

                        Column {
                            width: parent.width
                            spacing: 8

                            Repeater {
                                model: root.filteredClients()
                                delegate: Rectangle {
                                    required property var modelData
                                    width: parent.width
                                    height: 62
                                    radius: 14
                                    color: root.selectedClientId === modelData.id
                                           ? Qt.rgba(Qt.color(AppSettings.accentColor).r,
                                                     Qt.color(AppSettings.accentColor).g,
                                                     Qt.color(AppSettings.accentColor).b, 0.28)
                                           : (clientMouse.containsMouse ? "#131B28" : "#0F1622")
                                    border.width: 1
                                    border.color: root.selectedClientId === modelData.id ? AppSettings.accentColor : "#223044"

                                    RowLayout {
                                        anchors.fill: parent
                                        anchors.margins: 12
                                        spacing: 10

                                        Rectangle {
                                            Layout.preferredWidth: 44
                                            Layout.preferredHeight: 44
                                            radius: 13
                                            color: "#182334"
                                            border.width: 1
                                            border.color: root.selectedClientId === modelData.id
                                                          ? AppSettings.accentColor : "#26364A"
                                            clip: true
                                            RoundedImage {
                                                anchors.fill: parent
                                                anchors.margins: 1
                                                radius: 12
                                                fillMode: Image.PreserveAspectCrop
                                                fadeMs: 0
                                                source: {
                                                    var u = modelData.coverUrl || ""
                                                    var l = (PhotoStore.rev, PhotoStore.fileFor(u))
                                                    return l !== "" ? l : u
                                                }
                                                fallbackContent: Text {
                                                    anchors.centerIn: parent
                                                    text: String(modelData.name || modelData.id || "?").substring(0, 1).toUpperCase()
                                                    color: "#AEBAD0"
                                                    font.pixelSize: 18
                                                    font.bold: true
                                                }
                                            }
                                        }

                                        ColumnLayout {
                                            Layout.fillWidth: true
                                            spacing: 2
                                            Text {
                                                Layout.fillWidth: true
                                                text: root.clientVersionLabel(modelData)
                                                color: "#F1F4FA"
                                                font.pixelSize: 14
                                                font.bold: true
                                                elide: Text.ElideRight
                                            }
                                            Text {
                                                Layout.fillWidth: true
                                                text: (modelData.configCount || 0) + " конфигов"
                                                color: "#8894A7"
                                                font.pixelSize: 11
                                                elide: Text.ElideRight
                                            }
                                        }
                                    }

                                    MouseArea {
                                        id: clientMouse
                                        anchors.fill: parent
                                        hoverEnabled: true
                                        cursorShape: Qt.PointingHandCursor
                                        onClicked: root.selectedClientId = modelData.id
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Rectangle {
                Layout.fillWidth: true
                Layout.fillHeight: true
                radius: 18
                color: "#B80F1622"
                border.width: 1
                border.color: "#1B2635"

                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 16
                    spacing: 12

                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 12

                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 2
                            Text {
                                text: root.clientVersionLabel(root.currentClient())
                                color: "#F1F4FA"
                                font.pixelSize: 16
                                font.bold: true
                            }
                            Text {
                                text: "Доступно конфигов: " + ((root.currentClient().configs || []).length || 0)
                                color: "#8C98AB"
                                font.pixelSize: 12
                            }
                        }

                        SearchBox {
                            Layout.preferredWidth: 240
                            Layout.alignment: Qt.AlignVCenter
                            placeholder: "Поиск конфига"
                            text: root.configFilter
                            onEdited: function(value) { root.configFilter = value }
                        }

                        FilterDropdown {
                            id: sortBox
                            Layout.alignment: Qt.AlignVCenter
                            Layout.preferredWidth: 180
                            readonly property var _modes: ["popular", "rating", "new", "name"]
                            model: ["По популярности", "По рейтингу", "По дате", "По имени"]
                            currentIndex: Math.max(0, _modes.indexOf(root.sortMode))
                            onActivated: function(index) { root.sortMode = _modes[index] }
                        }
                    }

                    ScrollView {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        clip: true

                        Column {
                            width: parent.width
                            spacing: 12

                            Repeater {
                                model: root.sortedConfigs()
                                delegate: Rectangle {
                                    required property var modelData
                                    width: parent.width
                                    height: 200
                                    radius: 16
                                    color: "#111A28"
                                    border.width: 1
                                    border.color: "#26354A"
                                    clip: true

                                    RowLayout {
                                        anchors.fill: parent
                                        anchors.margins: 16
                                        spacing: 16

                                        Rectangle {
                                            Layout.preferredWidth: 142
                                            Layout.preferredHeight: 142
                                            radius: 14
                                            color: "#121B2B"
                                            border.width: 1
                                            border.color: "#233249"
                                            clip: true
                                            RoundedImage {
                                                anchors.fill: parent
                                                radius: 14
                                                fillMode: Image.PreserveAspectCrop
                                                source: {
                                                    var u = modelData.coverUrl || root.currentClient().coverUrl || ""
                                                    var l = (PhotoStore.rev, PhotoStore.fileFor(u))
                                                    return l !== "" ? l : u
                                                }
                                                fallbackContent: Text {
                                                    anchors.centerIn: parent
                                                    text: String(modelData.name || root.currentClient().name || "?").substring(0, 1).toUpperCase()
                                                    color: "#42506A"
                                                    font.pixelSize: 42
                                                    font.bold: true
                                                }
                                            }
                                            Rectangle {
                                                anchors.fill: parent
                                                radius: 14
                                                color: "#33060B14"
                                            }
                                            Rectangle {
                                                anchors.left: parent.left
                                                anchors.bottom: parent.bottom
                                                anchors.margins: 10
                                                width: statusText.implicitWidth + 16
                                                height: 24
                                                radius: 8
                                                color: modelData.installed ? "#CC1A3A2A" : "#CC162133"
                                                border.width: 1
                                                border.color: modelData.installed ? "#2E8F57" : "#2B3C52"
                                                Text {
                                                    id: statusText
                                                    anchors.centerIn: parent
                                                    text: modelData.installStatus
                                                    color: modelData.installed ? "#64D889" : "#BAC4D3"
                                                    font.pixelSize: 11
                                                    font.bold: true
                                                }
                                            }
                                        }

                                        ColumnLayout {
                                            Layout.fillWidth: true
                                            Layout.fillHeight: true
                                            spacing: 6

                                            RowLayout {
                                                Layout.fillWidth: true
                                                spacing: 8
                                                Text {
                                                    text: modelData.name || modelData.id
                                                    color: "#F4F7FB"
                                                    font.pixelSize: 19
                                                    font.bold: true
                                                    elide: Text.ElideRight
                                                    Layout.fillWidth: true
                                                }
                                            }

                                            Text {
                                                Layout.fillWidth: true
                                                text: modelData.description || "Без описания"
                                                color: "#8F9CB0"
                                                font.pixelSize: 12
                                                wrapMode: Text.WordWrap
                                                maximumLineCount: 2
                                                elide: Text.ElideRight
                                            }

                                            Flow {
                                                Layout.fillWidth: true
                                                spacing: 6
                                                visible: (modelData.tags || []).length > 0
                                                Repeater {
                                                    model: modelData.tags || []
                                                    delegate: Rectangle {
                                                        required property var modelData
                                                        height: 22
                                                        radius: 11
                                                        color: "#15243A"
                                                        border.width: 1
                                                        border.color: "#2D4665"
                                                        width: tagText.implicitWidth + 14
                                                        Text {
                                                            id: tagText
                                                            anchors.centerIn: parent
                                                            text: modelData
                                                            color: AppSettings.accentColor
                                                            font.pixelSize: 11
                                                        }
                                                    }
                                                }
                                            }

                                            RowLayout {
                                                Layout.fillWidth: true
                                                spacing: 8
                                                Rectangle {
                                                    visible: !!modelData.sizeText
                                                    radius: 8
                                                    color: "#151F30"
                                                    border.width: 1
                                                    border.color: "#25354A"
                                                    implicitWidth: sizeText.implicitWidth + 16
                                                    implicitHeight: 26
                                                    Text { id: sizeText; anchors.centerIn: parent; text: modelData.sizeText || ""; color: "#DCE2EE"; font.pixelSize: 12 }
                                                }
                                                Item { Layout.fillWidth: true }
                                            }

                                            Item { Layout.fillHeight: true }

                                            RowLayout {
                                                Layout.fillWidth: true
                                                spacing: 12

                                                // Средняя оценка (компактно)
                                                Text {
                                                    text: "★ " + Number(modelData.rating || 0).toFixed(1)
                                                          + "  ·  " + Number(modelData.votes || 0) + " голос."
                                                    color: "#C7D0DE"
                                                    font.pixelSize: 12
                                                }

                                                // Кликабельные звёзды — только когда оценка доступна
                                                // (после скачивания). Иначе показываем подсказку, а не
                                                // «сломанные» неактивные звёзды.
                                                Row {
                                                    id: rateRow
                                                    spacing: 2
                                                    visible: modelData.canRate
                                                    // После выставления оценки звёзды блокируются на 5 сек —
                                                    // защита от случайной/спамной смены. Лок в root.ratingLockedKey,
                                                    // поэтому переживает rebuild делегата.
                                                    property string rkey: root.currentClient().id + ":" + modelData.id
                                                    property bool locked: root.ratingLockedKey === rkey
                                                    Repeater {
                                                        model: 5
                                                        delegate: Text {
                                                            required property int index
                                                            text: "★"
                                                            color: index < Number(modelData.userRating || 0) ? "#FFCC42" : "#57657D"
                                                            opacity: rateRow.locked ? 0.5 : 1.0
                                                            font.pixelSize: 19
                                                            MouseArea {
                                                                anchors.fill: parent
                                                                enabled: !rateRow.locked
                                                                cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                                                                onClicked: {
                                                                    // Лок ставим ДО rateConfig (он вызовет rebuild).
                                                                    root.ratingLockedKey = rateRow.rkey
                                                                    ratingLockTimer.restart()
                                                                    ConfigManager.rateConfig(
                                                                        root.currentClient().id, modelData.id, index + 1)
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                Text {
                                                    visible: !modelData.canRate
                                                    text: "оцените после скачивания"
                                                    color: "#6E7B90"
                                                    font.pixelSize: 11
                                                }

                                                Item { Layout.fillWidth: true }

                                                Rectangle {
                                                    Layout.preferredWidth: 150
                                                    Layout.preferredHeight: 42
                                                    radius: 12
                                                    color: (!(modelData.canInstall === undefined ? modelData.clientInstalled : modelData.canInstall) || modelData.downloading)
                                                           ? "#243246"
                                                           : (cfgBtnMouse.containsMouse ? Qt.lighter(AppSettings.accentColor, 1.08) : AppSettings.accentColor)
                                                    border.width: 1
                                                    border.color: !(modelData.canInstall === undefined ? modelData.clientInstalled : modelData.canInstall) ? "#314255" : AppSettings.accentColor

                                                    Column {
                                                        anchors.centerIn: parent
                                                        spacing: 1
                                                        Text {
                                                            anchors.horizontalCenter: parent.horizontalCenter
                                                            text: modelData.downloading ? (modelData.stateText || "Загрузка") : modelData.actionText
                                                            color: (!(modelData.canInstall === undefined ? modelData.clientInstalled : modelData.canInstall) || modelData.downloading) ? "#B6C0D0" : "#08131F"
                                                            font.pixelSize: 12
                                                            font.bold: true
                                                        }
                                                        Text {
                                                            anchors.horizontalCenter: parent.horizontalCenter
                                                            visible: modelData.downloading
                                                            text: Math.round(Number(modelData.progress || 0) * 100) + "%"
                                                            color: "#DCE6F5"
                                                            font.pixelSize: 11
                                                        }
                                                    }

                                                    MouseArea {
                                                        id: cfgBtnMouse
                                                        anchors.fill: parent
                                                        enabled: (modelData.canInstall === undefined ? modelData.clientInstalled : modelData.canInstall) && !modelData.downloading && !ConfigManager.busy
                                                        hoverEnabled: enabled
                                                        cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                                                        onClicked: ConfigManager.downloadConfig(root.currentClient().id, modelData.id)
                                                    }
                                                }
                                            }

                                            Rectangle {
                                                Layout.fillWidth: true
                                                Layout.preferredHeight: modelData.downloading ? 6 : 0
                                                radius: 3
                                                color: "#162133"
                                                visible: modelData.downloading
                                                Rectangle {
                                                    width: parent.width * Number(modelData.progress || 0)
                                                    height: parent.height
                                                    radius: parent.radius
                                                    color: AppSettings.accentColor
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            Item {
                                width: parent.width
                                height: 36
                                visible: (root.sortedConfigs().length === 0)
                                Text {
                                    anchors.centerIn: parent
                                    text: "Конфиги не найдены"
                                    color: "#8391A6"
                                    font.pixelSize: 13
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}



