import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Effects
import "../components"

Item {
    id: root
    signal openNews()
    signal openClients()
    signal play()

    property bool showClientPicker: false


    function tr(key) { return (AppI18n.language, AppI18n.t(key)) }



    function _selectedName() {
        var id = AppSettings.selectedClientId
        var list = ManifestManager.clients
        for (var i = 0; i < list.length; ++i)
            if (list[i].id === id) return list[i].name || list[i].id
        if (list.length > 0) return list[0].name || list[0].id
        return ""
    }

    // Полная карточка выбранного клиента (для кнопки Играть/Скачать). Работает
    // и для НЕ скачанных клиентов — их тоже можно выбрать и скачать прямо тут.
    function _selectedClient() {
        var id = AppSettings.selectedClientId
        var list = ManifestManager.clients
        for (var i = 0; i < list.length; ++i)
            if (list[i].id === id) return list[i]
        if (list.length > 0) return list[0]
        return null
    }








    ListModel { id: menuModel; dynamicRoles: true }

    function _menuTargetOrder() {
        // Показываем ВСЕ клиенты каталога (включая не скачанные) — их тоже можно
        // выбрать и скачать с главной. Скачанные и избранные идут выше.
        var fav = [], installed = [], rest = []
        var list = ManifestManager.clients
        for (var i = 0; i < list.length; ++i) {
            var c = list[i]
            if (AppSettings.favouriteClientIds.indexOf(c.id) >= 0)
                fav.push(c)
            else if ((InstalledStore.revision, InstalledStore.isInstalled)(c.id))
                installed.push(c)
            else
                rest.push(c)
        }
        return fav.concat(installed).concat(rest)
    }

    function _menuIndexOfId(id, from) {
        for (var i = from; i < menuModel.count; ++i)
            if (menuModel.get(i).client.id === id) return i
        return -1
    }

    function _syncMenu() {
        var target = _menuTargetOrder()

        var sameSet = target.length === menuModel.count
        for (var i = 0; sameSet && i < target.length; ++i)
            if (_menuIndexOfId(target[i].id, 0) < 0) sameSet = false

        if (!sameSet) {
            menuModel.clear()
            for (var k = 0; k < target.length; ++k)
                menuModel.append({ client: target[k] })
            return
        }

        for (var pos = 0; pos < target.length; ++pos) {
            if (menuModel.get(pos).client.id === target[pos].id) continue
            var from = _menuIndexOfId(target[pos].id, pos + 1)
            if (from > pos) menuModel.move(from, pos, 1)
        }
    }

    Component.onCompleted: _syncMenu()
    Connections {
        target: ManifestManager
        function onClientsChanged() { root._syncMenu() }
    }
    Connections {
        target: AppSettings
        function onFavouriteClientIdsChanged() { root._syncMenu() }
    }
    Connections {

        target: InstalledStore
        function onChanged() { root._syncMenu() }
    }

    RowLayout {
        anchors.fill: parent
        spacing: 20


        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 16

            HeroBanner {
                Layout.fillWidth: true
                Layout.fillHeight: true
            }

            RowLayout {
                id: btnRow
                Layout.fillWidth: true
                Layout.preferredHeight: 58
                Layout.maximumHeight: 58
                spacing: 10




                Rectangle {
                    id: playBtn
                    Layout.preferredWidth: Math.floor((btnRow.width - btnRow.spacing) * 2 / 3)
                    Layout.preferredHeight: 58
                    Layout.maximumHeight: 58
                    radius: 12
                    border.width: 1
                    border.color: "#1B2635"
                    color: {
                        if (!playEnabled) return "#801A2230"
                        if (playMouse.pressed) return "#D8131C29"
                        if (playMouse.containsMouse) return "#C8131C29"
                        return "#B80F1622"
                    }
                    Behavior on color { ColorAnimation { duration: 120 } }



                    // Выбранный клиент и его статус. Если он НЕ скачан — кнопка
                    // становится «СКАЧАТЬ» и запускает загрузку, а не игру.
                    property var selClient: (ManifestManager.clients, AppSettings.selectedClientId, root._selectedClient())
                    property bool selInstalled: selClient ? (InstalledStore.revision, InstalledStore.isInstalled)(selClient.id) : false
                    property bool selNeedsUpdate: selInstalled && selClient
                                                  && ((InstalledStore.revision, InstalledStore.installedVersion)(selClient.id) !== String(selClient.version || "")
                                                      || (InstalledStore.revision, InstalledStore.needsUpdate)(selClient.id, String(selClient.sha256 || ""), String(selClient.packageUrl || "")))
                    property bool isBusyMe: selClient && DownloadManager.busy && DownloadManager.currentClientId === selClient.id
                    property bool playEnabled: !GameLauncher.preparing
                                               && ManifestManager.clients.length > 0
                                               && (!DownloadManager.busy || isBusyMe)

                    Text {
                        anchors.centerIn: parent
                        text: {
                            if (ManifestManager.clients.length === 0) return root.tr("play.noclients")
                            if (playBtn.isBusyMe) return "ОТМЕНА"
                            if (DownloadManager.busy) return "ЗАНЯТО"
                            if (!playBtn.selInstalled) return "СКАЧАТЬ"
                            if (playBtn.selNeedsUpdate) return "ОБНОВИТЬ"
                            return root.tr("play.play")
                        }
                        color: playBtn.playEnabled ? "#F1F4FA" : "#556275"
                        font.pixelSize: 16
                        font.bold: true
                        font.letterSpacing: 3
                    }

                    MouseArea {
                        id: playMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: playBtn.playEnabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                        onClicked: {
                            if (ManifestManager.clients.length === 0) return
                            if (playBtn.isBusyMe) { DownloadManager.cancel(); return }
                            if (DownloadManager.busy) return
                            if (playBtn.selNeedsUpdate) {
                                DownloadManager.installClient(playBtn.selClient)
                            } else if (playBtn.selInstalled) {
                                if (!GameLauncher.preparing) root.play()
                            } else if (playBtn.selClient) {
                                DownloadManager.installClient(playBtn.selClient)
                            }
                        }
                    }
                }


                Rectangle {
                    id: selectorBtn
                    Layout.fillWidth: true
                    Layout.preferredHeight: 58
                    Layout.maximumHeight: 58
                    radius: 12
                    border.width: 1
                    border.color: "#1B2635"
                    color: {
                        if (selMouse.pressed) return "#D8131C29"
                        if (selMouse.containsMouse) return "#C8131C29"
                        return "#B80F1622"
                    }
                    Behavior on color { ColorAnimation { duration: 120 } }

                    Column {
                        anchors.centerIn: parent
                        width: parent.width - 20
                        spacing: 2

                        Text {
                            anchors.horizontalCenter: parent.horizontalCenter
                            width: parent.width
                            horizontalAlignment: Text.AlignHCenter
                            elide: Text.ElideRight
                            text: root._selectedName() || root.tr("selector.none")
                            color: "#F1F4FA"
                            font.pixelSize: 14
                            font.bold: true
                            font.letterSpacing: 1
                        }
                        Text {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: root.tr("selector.hint")
                            color: "#7C8899"
                            font.pixelSize: 9
                            font.letterSpacing: 1
                        }
                    }

                    MouseArea {
                        id: selMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: root.showClientPicker = !root.showClientPicker
                    }
                }
            }
        }




        ColumnLayout {
            Layout.preferredWidth: 380
            Layout.maximumWidth: 380
            Layout.fillHeight: true
            spacing: 16

            Rectangle {
                Layout.fillWidth: true
                Layout.fillHeight: true
                color: "#B80F1622"
                border.width: 1
                border.color: "#1B2635"
                radius: 14
                clip: true

                Item {
                    anchors.fill: parent
                    anchors.margins: 18


                ColumnLayout {
                    id: newsView
                    anchors.fill: parent
                    spacing: 12
                    opacity: root.showClientPicker ? 0 : 1
                    visible: opacity > 0.01
                    enabled: !root.showClientPicker
                    Behavior on opacity { NumberAnimation { duration: 220; easing.type: Easing.InOutQuad } }

                    RowLayout {
                        Layout.fillWidth: true
                        Text {
                            Layout.fillWidth: true
                            text: root.tr("news.title")
                            color: "#F1F4FA"
                            font.pixelSize: 13
                            font.bold: true
                            font.letterSpacing: 1.6
                        }
                        Text {
                            text: root.tr("news.all")
                            color: AppSettings.accentColor
                            font.pixelSize: 11
                            font.bold: true
                            MouseArea {
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onClicked: root.openNews()
                            }
                        }
                    }

                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 6


                        Text {
                            Layout.fillWidth: true
                            Layout.topMargin: 24
                            text: root.tr("news.none")
                            color: "#556275"
                            font.pixelSize: 12
                            horizontalAlignment: Text.AlignHCenter
                            visible: NewsModel.top.length === 0
                        }

                        Repeater {
                            model: NewsModel.top

                            delegate: Rectangle {
                                required property var modelData
                                Layout.fillWidth: true
                                Layout.preferredHeight: 62
                                color: newsMouse.containsMouse ? "#131C29" : "transparent"
                                radius: 10
                                Behavior on color { ColorAnimation { duration: 120 } }

                                ColumnLayout {
                                    anchors.fill: parent
                                    anchors.leftMargin: 10
                                    anchors.rightMargin: 10
                                    anchors.topMargin: 8
                                    anchors.bottomMargin: 8
                                    spacing: 3

                                    RowLayout {
                                        Layout.fillWidth: true
                                        spacing: 6
                                        Rectangle {
                                            radius: 3
                                            Layout.preferredHeight: 15
                                            Layout.preferredWidth: tagText.implicitWidth + 10
                                            color: modelData.tagColor
                                            Text {
                                                id: tagText
                                                anchors.centerIn: parent
                                                text: modelData.tag
                                                color: "#0B0E15"
                                                font.pixelSize: 8
                                                font.bold: true
                                                font.letterSpacing: 0.6
                                            }
                                        }
                                        Item { Layout.fillWidth: true }
                                        Text {
                                            text: modelData.date
                                            color: "#6E7A8C"
                                            font.pixelSize: 9
                                        }
                                    }

                                    Text {
                                        Layout.fillWidth: true
                                        text: modelData.title
                                        color: "#EAEFF7"
                                        font.pixelSize: 12
                                        font.bold: true
                                        elide: Text.ElideRight
                                    }
                                    Text {
                                        Layout.fillWidth: true
                                        text: modelData.description
                                        color: "#7C8899"
                                        font.pixelSize: 9
                                        wrapMode: Text.NoWrap
                                        elide: Text.ElideRight
                                    }
                                }

                                MouseArea {
                                    id: newsMouse
                                    anchors.fill: parent
                                    hoverEnabled: true
                                    cursorShape: Qt.PointingHandCursor
                                    onClicked: root.openNews()
                                }
                            }
                        }
                    }

                    Item { Layout.fillHeight: true }
                }


                ColumnLayout {
                    id: pickerView
                    anchors.fill: parent
                    spacing: 12
                    opacity: root.showClientPicker ? 1 : 0
                    visible: opacity > 0.01
                    enabled: root.showClientPicker
                    Behavior on opacity { NumberAnimation { duration: 220; easing.type: Easing.InOutQuad } }

                    RowLayout {
                        Layout.fillWidth: true
                        Text {
                            Layout.fillWidth: true
                            text: root.tr("picker.title")
                            color: "#F1F4FA"
                            font.pixelSize: 13
                            font.bold: true
                            font.letterSpacing: 1.6
                        }
                        Rectangle {
                            Layout.preferredWidth: 26
                            Layout.preferredHeight: 26
                            radius: 13
                            color: closeMouse.containsMouse ? "#7E2630" : "transparent"
                            Text {
                                anchors.centerIn: parent
                                text: "×"
                                color: closeMouse.containsMouse ? "#FFE5E9" : "#B9C1CE"
                                font.pixelSize: 16
                                font.bold: true
                            }
                            MouseArea {
                                id: closeMouse
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onClicked: root.showClientPicker = false
                            }
                        }
                    }

                    ListView {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        clip: true
                        spacing: 8
                        model: menuModel
                        boundsBehavior: Flickable.StopAtBounds




                        move: Transition {
                            NumberAnimation { properties: "y"; duration: 260; easing.type: Easing.OutCubic }
                        }
                        displaced: Transition {
                            NumberAnimation { properties: "y"; duration: 260; easing.type: Easing.OutCubic }
                        }

                        delegate: Rectangle {
                            required property int index
                            required property var client
                            readonly property var modelData: client
                            width: ListView.view.width
                            height: 68
                            radius: 12
                            property bool active: AppSettings.selectedClientId === modelData.id
                            color: active ? Qt.rgba(AppSettings.accentColor.r, AppSettings.accentColor.g, AppSettings.accentColor.b, 0.18)
                                          : (rowMouse.containsMouse ? "#131C29" : "#0B131F")
                            border.width: active ? 1 : 0


                            border.color: Qt.rgba(AppSettings.accentColor.r, AppSettings.accentColor.g,
                                                  AppSettings.accentColor.b, 0.45)
                            Behavior on color { ColorAnimation { duration: 120 } }




                            Rectangle {
                                id: rowShape
                                anchors.fill: parent
                                radius: parent.radius
                                color: "white"
                                visible: false
                                layer.enabled: true
                            }






                            Item {
                                anchors.fill: parent
                                visible: rowBg.status === Image.Ready
                                clip: true

                                layer.enabled: true
                                layer.effect: MultiEffect {
                                    maskEnabled: true
                                    maskSource: rowShape
                                    maskThresholdMin: 0.5
                                    maskSpreadAtMin: 0.5
                                }

                                Image {
                                    id: rowBg
                                    property int attempt: 0
                                    readonly property string primarySource: (modelData.screenshots && modelData.screenshots.length > 0)
                                                                        ? modelData.screenshots[0]
                                                                        : (modelData.coverUrl || "")
                                    readonly property string fallbackSource: (PhotoStore && primarySource.length > 0)
                                                                            ? PhotoStore.fallbackUrlFor(primarySource) : ""
                                    anchors.centerIn: parent
                                    width: parent.width
                                    height: parent.height * 3
                                    source: {
                                        if (primarySource.length === 0) return ""
                                        if (primarySource.indexOf("image://") === 0)
                                            return primarySource
                                        var base = (attempt >= 2 && fallbackSource.length > 0)
                                                   ? fallbackSource : primarySource
                                        if (attempt === 0 || base.indexOf("image://") === 0) return base
                                        return base + (base.indexOf("?") >= 0 ? "&" : "?") + "r=" + attempt
                                    }
                                    fillMode: Image.PreserveAspectCrop
                                    asynchronous: true
                                    cache: true
                                    visible: false

                                    Timer {
                                        interval: rowBg.attempt < 4 ? 2500 : 15000
                                        running: rowBg.primarySource.length > 0 && rowBg.status === Image.Error
                                        repeat: true
                                        onTriggered: rowBg.attempt++
                                    }
                                }

                                MultiEffect {
                                    anchors.fill: rowBg
                                    source: rowBg
                                    blurEnabled: true
                                    blur: 0.85
                                    blurMax: 40




                                    brightness: 0.15
                                    saturation: 0.35
                                    contrast: 0.1
                                    opacity: 0.85
                                }




                                Rectangle {
                                    anchors.fill: parent
                                    color: "#4A0B131F"
                                }
                            }

                            RowLayout {
                                anchors.fill: parent
                                anchors.margins: 10
                                spacing: 10


                                RoundedImage {
                                    Layout.preferredWidth: 48
                                    Layout.preferredHeight: 48
                                    radius: 8



                                    source: modelData.coverUrl || ""

                                    Rectangle {
                                        anchors.fill: parent
                                        visible: !modelData.coverUrl || modelData.coverUrl.length === 0
                                        color: "#16202E"
                                    }
                                }

                                ColumnLayout {
                                    Layout.fillWidth: true
                                    spacing: 2
                                    Text {
                                        Layout.fillWidth: true
                                        text: modelData.name || modelData.id
                                        color: "#F1F4FA"
                                        font.pixelSize: 13
                                        font.bold: true
                                        elide: Text.ElideRight
                                    }
                                    Text {




                                        Layout.fillWidth: true
                                        text: modelData.minecraft ? "Minecraft " + modelData.minecraft : ""
                                        color: "#7C8899"
                                        font.pixelSize: 10
                                        visible: text.length > 0
                                    }
                                }


                                Rectangle {
                                    Layout.preferredWidth: 32
                                    Layout.preferredHeight: 32
                                    radius: 16
                                    color: favMouse2.containsMouse ? "#1F2C40" : "transparent"
                                    Text {
                                        anchors.centerIn: parent
                                        text: (AppSettings.favouriteClientIds.indexOf(modelData.id) >= 0) ? "★" : "☆"
                                        color: (AppSettings.favouriteClientIds.indexOf(modelData.id) >= 0) ? "#F5C542" : "#B9C1CE"
                                        font.pixelSize: 18
                                        font.bold: true
                                    }
                                    MouseArea {
                                        id: favMouse2
                                        anchors.fill: parent
                                        hoverEnabled: true
                                        cursorShape: Qt.PointingHandCursor
                                        onClicked: AppSettings.toggleFavourite(modelData.id)
                                    }
                                }
                            }

                            MouseArea {
                                id: rowMouse
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                z: -1
                                onClicked: {
                                    AppSettings.selectedClientId = modelData.id
                                    root.showClientPicker = false
                                }
                            }
                        }
                    }
                }
            }
            }


            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 58
                Layout.maximumHeight: 58
                radius: 14
                color: "#B80F1622"
                border.width: 1
                border.color: "#1B2635"

                Column {
                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    anchors.leftMargin: 16
                    anchors.rightMargin: 16
                    spacing: 2

                    Text {
                        text: root.tr("nick.label")
                        color: "#7C8899"
                        font.pixelSize: 9
                        font.bold: true
                        font.letterSpacing: 1.5
                    }

                    TextField {
                        id: nickHomeField
                        width: parent.width
                        height: 26
                        padding: 0
                        text: AppSettings.nickname
                        color: "#F1F4FA"
                        selectByMouse: true
                        font.pixelSize: 14
                        font.bold: true
                        verticalAlignment: TextInput.AlignVCenter



                        maximumLength: 16
                        validator: RegularExpressionValidator {
                            regularExpression: /[A-Za-z0-9_]*/
                        }
                        onTextChanged: {
                            const clean = AppSettings.sanitizeNickname(text)
                            if (clean !== text) {
                                const at = Math.max(0, cursorPosition - (text.length - clean.length))
                                text = clean
                                cursorPosition = Math.min(at, clean.length)
                            }
                            if (AppSettings.nickname !== text)
                                AppSettings.nickname = text
                        }
                        onEditingFinished: AppSettings.nickname = text
                        background: null
                    }
                }
            }
        }
    }
}



