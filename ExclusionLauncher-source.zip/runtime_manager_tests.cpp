#include <QtTest/QtTest>

#include "core/RuntimeManager.hpp"

class RuntimeManagerTests final : public QObject
{
    Q_OBJECT

private slots:
    void fallbackManifestContainsCompatibilityIds()
    {
        RuntimeManager manager;

        const QVariantMap jdk25 = manager.runtimeSpec(QStringLiteral("jdk25"));
        QVERIFY2(!jdk25.isEmpty(), "jdk25 must be available from fallback runtimes");
        QCOMPARE(jdk25.value(QStringLiteral("javaExe")).toString(),
                 QStringLiteral("jdk-25.0.4+7/bin/javaw.exe"));

        const QVariantMap java25 = manager.runtimeSpec(QStringLiteral("java25"));
        QVERIFY2(!java25.isEmpty(), "java25 compatibility id must be available");
        QCOMPARE(java25.value(QStringLiteral("javaExe")).toString(),
                 QStringLiteral("jdk-21.0.3.9-hotspot/bin/javaw.exe"));

        const QVariantMap mc1165 = manager.runtimeSpec(QStringLiteral("mc1.16.5"));
        QVERIFY2(!mc1165.isEmpty(), "mc1.16.5 must be available");
        QCOMPARE(mc1165.value(QStringLiteral("sha256")).toString(),
                 QStringLiteral("0110c0295314c53b0ce8f596fb83047d67aaa64de0fba2f1fa0924b68defd902"));

        const QVariantMap typoAlias = manager.runtimeSpec(QStringLiteral("m1.16.5"));
        QVERIFY2(!typoAlias.isEmpty(), "m1.16.5 typo alias must be available");
        QCOMPARE(typoAlias.value(QStringLiteral("url")).toString(),
                 mc1165.value(QStringLiteral("url")).toString());
    }
};

QTEST_MAIN(RuntimeManagerTests)

#include "runtime_manager_tests.moc"
