; Inno Setup — мастер-установщик Exclusion Launcher (как у ULauncher на скрине).
; Ставит лаунчер (сборку app-stage) в {app}\app, делает ярлыки, запускает,
; создаёт деинсталлятор. Страница «для всех / только для меня» — встроенная
; (PrivilegesRequiredOverridesAllowed=dialog). Себя лаунчер потом обновляет сам.

#define AppName    "Exclusion Launcher"
#define AppVersion "0.1.42"
#define AppExe     "ExclusionLauncher.exe"
#define AppPublisher "Exclusion"
#define StageDir   "..\build\app-stage"
#define IconFile   "..\data\icon.ico"

[Setup]
AppId={{7E1C5A42-3B9D-4C8E-9A21-EXCLUSION0142}}
AppName={#AppName}
AppVersion={#AppVersion}
; Версию в мастере не показываем — только имя (AppVerName без номера).
AppVerName={#AppName}
AppPublisher={#AppPublisher}
DefaultDirName={autopf}\Exclusion Launcher
DefaultGroupName=Exclusion Launcher
DisableProgramGroupPage=yes
DisableWelcomePage=no
UninstallDisplayName={#AppName}
UninstallDisplayIcon={app}\app\{#AppExe}
OutputDir=..\dist\inno
OutputBaseFilename=ExclusionInstaller
SetupIconFile={#IconFile}
WizardStyle=modern
; Полные метаданные exe (в свойствах файла) — чтобы установщик выглядел как
; нормальный продукт. В мастере версия по-прежнему не показывается.
VersionInfoVersion={#AppVersion}
VersionInfoProductVersion={#AppVersion}
VersionInfoProductName={#AppName}
VersionInfoDescription={#AppName} Setup
VersionInfoCompany={#AppPublisher}
VersionInfoCopyright={#AppPublisher}
Compression=lzma2/max
SolidCompression=yes
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce

[Files]
Source: "{#StageDir}\*"; DestDir: "{app}\app"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\app\{#AppExe}"; WorkingDir: "{app}\app"; IconFilename: "{app}\app\icon.ico"
Name: "{group}\Удалить {#AppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\app\{#AppExe}"; WorkingDir: "{app}\app"; IconFilename: "{app}\app\icon.ico"; Tasks: desktopicon

[Run]
Filename: "{app}\app\{#AppExe}"; Description: "{cm:LaunchProgram,{#AppName}}"; WorkingDir: "{app}\app"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
; Лаунчер докачивает рантаймы/обновления рядом — чистим весь каталог установки.
Type: filesandordirs; Name: "{app}\app"
Type: filesandordirs; Name: "{app}\app-new"
