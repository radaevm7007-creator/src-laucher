#!/usr/bin/env python3
"""Собирает setup.exe — маленький нативный установщик лаунчера.

Без Qt: чистый WinAPI + WinHTTP + системный tar.exe. Отдаётся людям как один
файл; он качает лаунчер с сервера, ставит и удаляется.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = ROOT / "dist" / "ExclusionSetup.exe"

VS = Path(r"C:\Program Files\Microsoft Visual Studio\2022")
VCVARS = next(VS.glob("*/VC/Auxiliary/Build/vcvars64.bat"), None)


def main():
    if VCVARS is None:
        raise SystemExit("[fatal] не найден vcvars64.bat")
    OUT.parent.mkdir(parents=True, exist_ok=True)
    obj = HERE / "obj"
    obj.mkdir(exist_ok=True)

    # Всё пишем в .bat и запускаем его — вложенные кавычки в `cmd /c "…"`
    # ломаются, а через файл путь с пробелами в vcvars отрабатывает штатно.
    bat = obj / "build.bat"
    bat.write_text(
        '@echo off\r\n'
        f'call "{VCVARS}" >nul\r\n'
        f'rc /nologo /fo "{obj}\\setup.res" "{HERE / "setup.rc"}"\r\n'
        f'if errorlevel 1 exit /b 1\r\n'
        f'cl /nologo /std:c++17 /EHsc /O1 /MT /DUNICODE /D_UNICODE '
        f'"{HERE / "setup.cpp"}" "{obj}\\setup.res" '
        f'/Fo"{obj}\\\\" /link /SUBSYSTEM:CONSOLE /OUT:"{OUT}" '
        f'user32.lib\r\n',
        encoding="ascii")

    r = subprocess.run(["cmd", "/c", str(bat)], capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    if r.returncode != 0 or not OUT.is_file():
        # Ошибки MSVC — в stdout; печатаем без падения на кодировке.
        out = (r.stdout or "") + (r.stderr or "")
        print(out.encode("ascii", "replace").decode("ascii")[-3000:])
        raise SystemExit(f"[fatal] сборка setup не удалась (код {r.returncode})")

    print(f"готово: {OUT}")
    print(f"размер: {OUT.stat().st_size / 1024:.0f} КБ")


if __name__ == "__main__":
    main()
